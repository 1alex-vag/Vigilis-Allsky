# VIGILIS AllSky 1.0.0 Beta 4.8

Visual-only Liquid Glass refinement.

- Glass panels are now almost fully transparent.
- Background blur is reduced so the star-field background remains clearly visible.
- Border highlight and shadow are lighter and more subtle.
- Buttons and status pills were reduced in opacity to match the new glass style.

No camera, capture, transition, processing, gallery, sensor, Telegram or hardware logic was changed.
