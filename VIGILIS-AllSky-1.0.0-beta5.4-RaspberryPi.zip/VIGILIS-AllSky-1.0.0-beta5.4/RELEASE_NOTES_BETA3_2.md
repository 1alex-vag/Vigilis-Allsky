# VIGILIS AllSky 1.0.0 Beta 3.2

Overlay editor polish release.

- Unicode-capable overlay text rendering using a system Sans font (Pillow), fixing German umlauts such as Ä/Ö/Ü/ß.
- Per-element font weight: Normal or Bold.
- Cleaner compass preset: larger scalable ring, N/S/W/O labels outside the ring, no centre crosshair.
- Optional editor grid (10x10 / 20x20) with optional snap-to-grid.
- Only the currently selected overlay element displays a small drag handle; the large white marker circles/labels are removed.
- Numeric values are shown next to font size, image/preset size and opacity sliders for repeatable layouts.
- Existing Beta 3.1 overlay, Quick Capture, camera, Telegram, cover, heater and processing configuration remains compatible.
