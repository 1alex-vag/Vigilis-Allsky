# VIGILIS AllSky 1.0.0 Beta 3.6

## Capture / transition stability
- Calibration and test frames are never archived.
- After large exposure/gain changes, queued Picamera2 requests are discarded until request metadata matches the new controls.
- Transition mode rejects only obvious near-black glitch frames and performs a one-time recovery calibration before saving.
- Normal night frames are never brightness-filtered.
- Existing one-time evening/morning transition calibration behavior is preserved.

## Global save feedback
- All settings saves now use a top-layer Liquid Glass confirmation toast.
- The active Save button briefly changes to `Saved ✓`.
- Save failures show a red `Failed ✕` button state and an error toast.
- Toasts render above the background and all Web UI panels.
