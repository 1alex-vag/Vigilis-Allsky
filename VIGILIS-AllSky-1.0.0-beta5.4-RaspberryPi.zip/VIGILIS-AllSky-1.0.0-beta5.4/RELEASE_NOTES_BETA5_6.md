# VIGILIS Meteor 1.0.0 Beta 5.6

## Climate History Upgrade

- Added selectable history ranges: 1 Day, 7 Days, 30 Days, 2 Months, 6 Months and 1 Year.
- Added a custom From/To date range (maximum 367 days).
- Temperature and humidity charts now share the selected range and update immediately.
- Added minimum, average and maximum statistics for dome and outdoor sensors.
- Added average dome/outdoor difference for temperature and humidity.
- PNG exports now use the selected range and descriptive filenames.
- Long ranges are automatically averaged into chart buckets while statistics still use every raw sample.
- Existing one-day API and PNG links remain backward compatible.

## Climate history layout refinement

- Temperature and humidity are now shown together in one Climate History panel.
- One shared range selector controls both diagrams.
- Custom From/To dates reload automatically; the Load button was removed.
- Temperature and humidity statistics are grouped below both charts.
- Separate PNG download buttons remain available for each diagram.
