# VIGILIS AllSky 1.0.0 Beta 1.1

- Restored complete Lens Cover configuration in System.
- Added editable GPIO assignment for DHT22, Hall sensors, A4988 STEP/DIR/ENABLE and heater MOSFET.
- Added save-and-restart workflow for hardware settings.
- Default wiring: GPIO4 DHT22, GPIO5 Hall OPEN, GPIO6 Hall CLOSED, GPIO17 STEP, GPIO22 ENABLE, GPIO24 heater, GPIO27 DIR.
