#!/usr/bin/env python3
"""Best-effort migration from a VIGILIS/meteorcam v0.6.x config.yaml."""
from pathlib import Path
import argparse, shutil, yaml

parser=argparse.ArgumentParser()
parser.add_argument('old_config',type=Path)
parser.add_argument('--target',type=Path,default=Path(__file__).resolve().parent/'config.yaml')
a=parser.parse_args()
old=yaml.safe_load(a.old_config.read_text(encoding='utf-8')) or {}
new=yaml.safe_load(a.target.read_text(encoding='utf-8')) or {}
for section in ('location','camera','detection','telegram','heater','storage','ui'):
    if isinstance(old.get(section),dict): new.setdefault(section,{}).update(old[section])
# Translate legacy names while preserving the v0.7 reference GPIO assignment.
if 'nightmode' in old:
    mode=old['nightmode'].get('mode','auto')
    new['observation']['mode']={'auto':'sun','always_on':'always'}.get(mode,'sun')
new['gpio'].update({'dht_pin':4,'hall_open_pin':5,'hall_closed_pin':6,'step_pin':17,'enable_pin':22,'heater_pin':24,'dir_pin':27})
backup=a.target.with_suffix('.yaml.before-migration')
shutil.copy2(a.target,backup)
a.target.write_text(yaml.safe_dump(new,allow_unicode=True,sort_keys=False),encoding='utf-8')
print(f'Migrated settings to {a.target}; backup: {backup}')
