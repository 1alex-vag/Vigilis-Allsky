# VIGILIS AllSky 1.0.0 Beta 1.9

## Environment / Heater
- Restored the Environment configuration panel from the stable VIGILIS Meteor 1.0.0 Beta 5.7 Climate Layout.
- Dome DHT22 enable/disable and GPIO configuration.
- Outdoor DHT22 enable/disable and GPIO configuration.
- Heater modes Off / On / Automatic.
- Time-window and PWM regulation selection.
- Target temperature, humidity trigger, fixed output slider and window time.
- Live Temperature, Humidity, Heater and Output status cards.
- Save Environment now persists sensor, GPIO and heater configuration through the existing AllSky settings API.
- Sensor GPIO changes offer an immediate VIGILIS service restart, matching Meteor behavior.

Lens Cover and AllSky capture logic are unchanged from Beta 1.8.
