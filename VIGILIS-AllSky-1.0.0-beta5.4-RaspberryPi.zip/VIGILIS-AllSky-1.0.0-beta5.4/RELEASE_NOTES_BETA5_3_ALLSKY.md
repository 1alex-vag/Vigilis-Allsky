# VIGILIS AllSky 1.0.0 Beta 5.3

Small UI hotfix based on Beta 5.2.

- Fixes the legacy mobile CSS rule that forced the third Home status item onto a second row.
- Camera / Status / Sun altitude now stay in three equal columns on mobile.
- Gallery layout from Beta 5.2 remains unchanged.
- No capture, camera, sensor, heater, lightning, Telegram, processing or hardware logic changed.
