# VIGILIS AllSky 1.0.0 Beta 1.6

Lens Cover subsystem rebuild based on the known-good VIGILIS Meteor 1.0.0 Beta 5.7 Climate Layout implementation.

- Meteor Beta 5.7 `cover.py` is used unchanged as the low-level hardware controller.
- Added an AllSky LensCoverService facade; AllSky code never touches Hall/STEP/DIR/ENABLE GPIOs directly.
- Manual Home Open/Close/Stop and automatic Day/Transition/Night requests now share one serialized controller.
- Added a five-second hardware initialization grace period before AllSky automation may command the cover.
- GPIO and cover configuration are recreated from Meteor Beta 5.7 defaults during installation/update.
- Existing user AllSky settings are migrated, but stale GPIO/cover sections are deliberately not preserved.
- Installer now makes a fast configuration-only backup instead of copying the whole application tree.
- Recordings, AllSky archives, data, logs and external-storage content are preserved in place.

Reference GPIO mapping:
- GPIO4 DHT22 DATA
- GPIO5 Hall OPEN
- GPIO6 Hall CLOSED
- GPIO17 A4988 STEP
- GPIO22 A4988 ENABLE
- GPIO24 Heater MOSFET gate
- GPIO27 A4988 DIR
