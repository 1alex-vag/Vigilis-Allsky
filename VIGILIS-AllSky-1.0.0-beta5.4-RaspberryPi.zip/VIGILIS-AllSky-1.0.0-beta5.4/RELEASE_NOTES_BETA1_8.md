# VIGILIS AllSky 1.0.0 Beta 1.8

- No-IR-cut colour handling: Auto WB now switches to a sensor-aware full-spectrum preset when UV/IR Cut is not installed.
- UV/IR and white-balance changes are applied immediately without requiring a service restart.
- IMX477 No-IR preset added; Custom WB remains available for exact tuning.
- Home AllSky preview now displays the complete sensor frame without cropping.
- Day exposure calibration now exposes structured progress/status data.
- Home shows a large calibration banner with step, exposure, gain and brightness while calibration is running.
- Lens Cover controller and GPIO behaviour are unchanged from Beta 1.7.
