# VIGILIS AllSky 1.0.0 Beta 2.9

- Capture cadence: event-driven fresh-frame waiting; duplicate-frame protection retained; user delay is no longer combined with exposure time.
- Separate Sun-altitude thresholds for Night start and Night end.
- Transition interval presets 1/2/3/4/5 minutes plus Custom.
- Modular Overlay Editor: every field can be positioned independently; smaller fonts; left/center/right alignment.
- Custom transparent PNG overlay asset upload/library.
- Compass and VIGILIS logo presets, individually movable/scalable.
- Existing Beta 2.8 persistent user configuration remains preserved and is merged with new defaults.
