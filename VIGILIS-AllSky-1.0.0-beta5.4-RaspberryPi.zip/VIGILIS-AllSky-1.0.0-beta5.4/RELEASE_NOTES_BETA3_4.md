# VIGILIS AllSky 1.0.0 Beta 3.4

## Capture cadence fix
- Camera acquisition now publishes each completed exposure immediately.
- Full-resolution Vision Engine processing moved out of the camera acquisition thread and into the archive worker, so processing overlaps the next sensor exposure.
- This fixes the observed ~64-66 s cadence with a 30 s exposure by removing CPU processing from the sequence-ID critical path.
- Duplicate-frame protection remains enabled.
- Added `archive_processing_seconds` diagnostics.

## Transition calibration
- Evening/morning transition is calibrated once when entering transition mode.
- Calibration test frames are discarded.
- Subsequent transition frames continue from the calibrated exposure using normal AE tracking instead of re-running a multi-frame calibration before every transition image.
