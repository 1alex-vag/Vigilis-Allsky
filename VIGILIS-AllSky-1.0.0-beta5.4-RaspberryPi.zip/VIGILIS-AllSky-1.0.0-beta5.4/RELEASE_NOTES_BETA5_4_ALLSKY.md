# VIGILIS AllSky 1.0.0 Beta 5.4

Reliability fix for automatic night-product generation.

- Automatic night processing no longer starts during the evening transition.
- After-period processing waits until the morning transition is fully finished.
- Night products now use the complete sunset-to-sunrise session, including frames physically stored after midnight.
- Completion markers now store the processed frame count.
- If more frames appear than recorded, products are regenerated instead of remaining falsely complete.
- Legacy pre-5.4 completion markers are regenerated once, repairing nights that were processed too early.
- Timelapse, Keogram, Clean Startrail, Full Startrail and Clean Startrail Video use the same completed-session frame set.
- No camera capture timing, GPIO, lens-cover, sensor, heater or lightning detection logic changed.
