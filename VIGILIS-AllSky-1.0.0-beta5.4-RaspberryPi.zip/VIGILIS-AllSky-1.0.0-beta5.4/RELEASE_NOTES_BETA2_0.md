# VIGILIS AllSky 1.0.0 Beta 2.0

## Environment / Heater reliability

- HeaterController is copied unchanged from the known-good VIGILIS Meteor Beta 5.7 Climate Layout.
- SensorReader is copied unchanged from the same Meteor reference.
- GPIO24 remains the heater MOSFET gate output.
- Heater regulation now runs continuously in its own background worker and no longer depends on the WebUI polling `/api/status`.
- Saving Environment settings applies the heater state immediately.
- Switching Heater to Auto applies automatic regulation immediately.
- Home heater status now reads the actual controller `state` field.
- Environment UI, save payload and heater API remain compatible with the Meteor implementation.

## Preserved

- Existing user configuration is preserved during update.
- Lens Cover subsystem is unchanged from Beta 1.9.
- AllSky capture, day calibration, camera handling, gallery and processing are unchanged.
