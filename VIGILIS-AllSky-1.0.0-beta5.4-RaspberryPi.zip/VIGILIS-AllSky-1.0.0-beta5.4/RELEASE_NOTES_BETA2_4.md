# VIGILIS AllSky 1.0.0 Beta 2.4

- Gallery image viewer now uses cached, downscaled JPEG previews for reliable and fast display on iOS/Safari. Full-resolution originals remain available.
- Gallery thumbnails also use cached previews instead of decoding every 4056x3040 image in the browser.
- Delete individual images from the integrated viewer.
- Delete generated products (timelapse, keogram, startrail image/video) independently.
- Delete a complete observing-night session across midnight.
- Home now shows product-processing activity with job name, frame count and progress bar.
- Reprocess status is visible immediately on Home.
- Keogram includes a time axis derived from capture metadata.
- Product generation is gentler on Raspberry Pi CPU: OpenCV uses one thread, inter-frame pauses are increased, and ffmpeg is pinned to one CPU core when taskset is available.
- Existing capture, lens-cover, heater and Telegram settings are preserved by config migration.
