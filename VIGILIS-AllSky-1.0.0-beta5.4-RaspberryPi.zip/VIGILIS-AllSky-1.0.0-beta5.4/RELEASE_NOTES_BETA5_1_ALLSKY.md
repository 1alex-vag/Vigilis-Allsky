# VIGILIS AllSky 1.0.0 Beta 5.1

- Home capture panel redesigned: centered title, live image, compact Camera/Status/Sun row, Pictures today + Next capture merged into the same glass card.
- Lightning status added to Home Environment.
- Navigation reordered to Home / Gallery / Diagnostics / Settings.
- Header logo reduced by 30%.
- Quick Capture duplicate lower “Ready” removed.
- Gallery Pictures row aligned with Timelapse / Keogram / Startrail.
- Diagnostics 24h chart fits the full mobile width without horizontal swiping.
- Outdoor control redesigned as a compact range-sized button.
- Environment stats now show Current / Min / Max.
- New Dew Protection heater mode with configurable dew-margin hysteresis and calculated dew point.
- Lightning Detection preparation: AS3935 via SAMD21/UART config, history/status API, diagnostics chart, Telegram immediate alerts, distance threshold, cooldown and closer-strike override.
- Lightning sensor remains disabled by default until hardware is connected.
