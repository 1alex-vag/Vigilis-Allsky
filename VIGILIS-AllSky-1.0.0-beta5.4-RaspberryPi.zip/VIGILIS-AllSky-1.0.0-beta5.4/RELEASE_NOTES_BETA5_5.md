# VIGILIS 1.0.0 Beta 5.5 — Diagnostics Update

## Added
- Humidity history chart alongside temperature history.
- Downloadable humidity PNG chart.
- Live CPU load and CPU-temperature diagnostics.
- Live RAM usage with used and total memory.
- Internal SD usage with used and total capacity.
- Active recording-storage usage for SD or external SSD.
- Responsive diagnostics cards for desktop and mobile.

## Changed
- Diagnostics loads temperature and humidity history together for the selected day.
- System information API now includes RAM and internal-storage totals.

## Notes
- Climate history continues to use the existing once-per-minute DHT22 history.
- Recording storage is shown separately from the internal system volume.
- Telegram chart attachments are not enabled in this build; Beta 5.5 first validates the Diagnostics charts on Raspberry Pi hardware.
