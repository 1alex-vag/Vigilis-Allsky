# VIGILIS AllSky 1.0.0 Beta 3.5

## Long-exposure capture pipeline

- CSI/Picamera2 acquisition is now driven by completed libcamera requests via `post_callback`.
- `capture_array()` is no longer used as a second consumer in the camera-manager loop.
- The still pipeline uses three buffers so the next long exposure can be queued immediately after a completed request.
- Every completed request is published exactly once with its matching libcamera metadata.
- Exposure, gain, frame duration and Lux now come from the exact completed request.
- The long-exposure frame-duration margin was reduced from 8% to a small bounded readout margin. A 30 s exposure is therefore requested at about 30.45 s sensor cadence before user delay.
- Existing duplicate-frame protection remains active.
- Archive/Vision/overlay processing stays outside the CSI acquisition path.

## Version reporting

- Fixed the stale internal version constant that made Beta 3.4 report itself as Beta 3.3.

## Update behaviour

- Existing persistent user configuration remains in `data/user_config.yaml` and is not intentionally reset by this update.
