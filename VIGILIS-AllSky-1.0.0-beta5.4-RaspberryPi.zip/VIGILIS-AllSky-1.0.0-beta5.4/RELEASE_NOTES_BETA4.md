# VIGILIS Meteor 1.0 Beta 4

## Changes

- Redesigned four-item navigation with balanced mobile proportions.
- Hardware Reference moved into Settings.
- Optional second DHT22 for outdoor temperature and humidity.
- Daily dome/outdoor climate history with interactive chart and PNG export.
- Event Stack now extracts temporal motion trails instead of stacking only one representative point per event.
- Clean and green-overlay Event Stacks remain available.
- Asynchronous Event Stack rendering with live stage, event count and percentage progress.
- High CPU usage during stacking is explicitly reported as normal; detection remains operational.
