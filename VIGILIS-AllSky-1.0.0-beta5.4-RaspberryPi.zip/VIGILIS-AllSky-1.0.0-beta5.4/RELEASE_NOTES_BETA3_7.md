# VIGILIS AllSky 1.0.0 Beta 3.7

- Lens Cover settings are applied live; normal cover parameter changes no longer request a service restart.
- Restart is requested only when GPIO pin assignments actually change (unchanged GPIO values do not count).
- New Liquid Glass restart modal: **GPIO pins changed – restart VIGILIS?** with **Restart VIGILIS** and **Later** actions.
- Choosing **Later** leaves a persistent **Restart pending** indicator until VIGILIS is restarted.
- Environment GPIO changes use the same restart workflow.
- Existing camera-backend changes that genuinely require reinitialisation still request a restart.
