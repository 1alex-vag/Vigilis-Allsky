# VIGILIS AllSky 1.0.0 Beta 1.4

Hardware-control reset to the known-good VIGILIS Meteor Beta 5.7 implementation.

- Lens Cover controller copied byte-for-byte from Meteor Beta 5.7.
- Heater controller copied byte-for-byte from Meteor Beta 5.7.
- DHT22 sensor controller copied byte-for-byte from Meteor Beta 5.7.
- GPIO and Lens Cover configuration normalized to the Meteor Beta 5.7 defaults during installation.
- GPIO mapping: DHT22 GPIO4, Hall OPEN GPIO5, Hall CLOSED GPIO6, STEP GPIO17, ENABLE GPIO22, Heater GPIO24, DIR GPIO27.
- Hardware controllers initialize before AllSky camera/capture services.
- AllSky capture contains no direct GPIO or Hall-sensor access; it only requests movements through the Meteor CoverController.
- No new Lens Cover settings were added.
