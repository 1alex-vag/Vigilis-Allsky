# VIGILIS AllSky 1.0.0 Beta 1.5

Installer hotfix based on Beta 1.4.

## Fixed
- The Meteor hardware configuration synchronization tool is no longer executed before Python dependencies are installed.
- `sync_meteor_hardware_config.py` is now executed with the VIGILIS virtual-environment Python after `requirements.txt` has been installed, ensuring `PyYAML` is available.
- This fixes installation aborting with `ModuleNotFoundError: No module named 'yaml'`.

## Hardware behavior
No Lens Cover, GPIO, Heater, DHT22, Hall sensor, or AllSky runtime behavior was changed from Beta 1.4.
