# VIGILIS Meteor 1.0.0 Beta 5.7 — Climate Layout

## Changes

- Combines temperature and humidity history in one Climate History panel.
- Uses one shared range selector for both charts:
  - 1 Day
  - 7 Days
  - 30 Days
  - 2 Months
  - 6 Months
  - 1 Year
  - Custom
- Removes the Load button for preset ranges.
- Updates both charts immediately when a preset is selected.
- Shows clearly labelled Temperature and Humidity charts.
- Places minimum, average and maximum statistics below the charts.
- Preserves existing `config.yaml`, recordings, events, climate data, logs and backups during updates.
- Installer now refuses to run as root to prevent accidental installation under `/root/vigilis`.

## Installation

Run the installer as the normal Raspberry Pi user, without `sudo`:

```bash
chmod +x install.sh
./install.sh
```

The installer uses `sudo` internally only where system changes are required.
