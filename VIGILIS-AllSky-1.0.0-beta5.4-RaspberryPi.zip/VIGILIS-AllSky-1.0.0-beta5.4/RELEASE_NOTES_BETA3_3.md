# VIGILIS AllSky 1.0.0 Beta 3.3

- Fixes long-exposure cadence: Picamera2/ZWO blocking reads are no longer followed by a second artificial frame-period sleep. A 30 s exposure + 1 s user delay should now be close to ~31 s between completed captures rather than ~60+ s.
- Keeps duplicate-frame sequence protection.
- Evening and morning transition captures now perform a fast exposure calibration before the archived frame; calibration frames are discarded.
- First night capture is fast-calibrated before it is archived, avoiding nearly-black startup frames.
- Morning transition correctly inherits the last night exposure instead of resetting to the daylight millisecond state.
- Home calibration status reports evening/morning/night calibration progress.
