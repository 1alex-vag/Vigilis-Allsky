from __future__ import annotations

import os
import ctypes
from pathlib import Path
from typing import Any

import numpy as np


class ZwoCameraBackend:
    """ZWO ASI backend using the official SDK through python-zwoasi.

    The SDK remains optional. The backend reports capabilities and only opens
    the selected ASI camera when Camera Source is set to ZWO.
    """

    def __init__(self, config: dict[str, Any], logger):
        self.config = config
        self.logger = logger
        self.asi = None
        self.camera = None
        self.info: dict[str, Any] | None = None
        self.controls: dict[str, Any] = {}
        self.width = 0
        self.height = 0
        self.image_type = None
        self.pixel_format = "RAW8"

    @staticmethod
    def _library_candidates() -> list[str]:
        candidates: list[Path] = []
        env = os.environ.get("ZWO_ASI_LIB")
        if env:
            candidates.append(Path(env).expanduser())
        candidates.extend(
            Path(p)
            for p in (
                "/usr/local/lib/libASICamera2.so",
                "/usr/lib/libASICamera2.so",
                "/usr/lib/aarch64-linux-gnu/libASICamera2.so",
                "/usr/lib/arm-linux-gnueabihf/libASICamera2.so",
            )
        )
        home = Path.home()
        # Support all current/future SDK folder versions, including V1.41.
        candidates.extend(sorted(home.glob("ASI_linux_mac_SDK*/lib/armv8/libASICamera2.so"), reverse=True))
        candidates.extend(sorted(home.glob("ASI_linux_mac_SDK*/lib/armv7/libASICamera2.so"), reverse=True))
        seen: set[str] = set()
        result: list[str] = []
        for candidate in candidates:
            text = str(candidate)
            if candidate.exists() and text not in seen:
                seen.add(text)
                result.append(text)
        return result

    @classmethod
    def _init_sdk(cls):
        libs = cls._library_candidates()
        if not libs:
            raise RuntimeError("ZWO SDK library libASICamera2.so not found")
        import zwoasi as asi

        try:
            asi.init(libs[0])
        except Exception as exc:
            # python-zwoasi raises when init is repeated in the same process on
            # some releases. If enumeration already works, the SDK is usable.
            try:
                asi.get_num_cameras()
            except Exception:
                raise RuntimeError(f"Could not initialise ZWO SDK: {exc}") from exc
        return asi, libs[0]

    @staticmethod
    def _camera_summary(cam, index: int) -> dict[str, Any]:
        prop = cam.get_camera_property()
        controls = cam.get_controls() or {}
        return {
            "index": index,
            "name": prop.get("Name", f"ZWO ASI #{index}"),
            "camera_id": prop.get("CameraID", index),
            "max_width": prop.get("MaxWidth"),
            "max_height": prop.get("MaxHeight"),
            "color": bool(prop.get("IsColorCam")),
            "bayer_pattern": prop.get("BayerPattern"),
            "bins": [int(v) for v in prop.get("SupportedBins", []) if int(v) > 0],
            "usb3": bool(prop.get("IsUSB3Camera")),
            "temperature_supported": "Temperature" in controls,
            "controls": {
                name: {
                    "min": value.get("MinValue"),
                    "max": value.get("MaxValue"),
                    "default": value.get("DefaultValue"),
                    "auto": bool(value.get("IsAutoSupported")),
                    "writable": bool(value.get("IsWritable", True)),
                }
                for name, value in controls.items()
                if name in {"Gain", "Exposure", "BandWidth", "Temperature", "Gamma", "Brightness"}
            },
        }


    @classmethod
    def _ctypes_discover(cls) -> dict[str, Any]:
        """Enumerate cameras with the official C ABI.

        This is intentionally independent of python-zwoasi because some
        aarch64 combinations initialise the wrapper successfully but report
        zero cameras. The C SDK remains the source of truth.
        """
        result = {"sdk_available": False, "library": "", "cameras": [], "error": ""}
        libs = cls._library_candidates()
        if not libs:
            result["error"] = "ZWO SDK library libASICamera2.so not found"
            return result

        class ASICameraInfo(ctypes.Structure):
            _fields_ = [
                ("Name", ctypes.c_char * 64),
                ("CameraID", ctypes.c_int),
                ("MaxHeight", ctypes.c_long),
                ("MaxWidth", ctypes.c_long),
                ("IsColorCam", ctypes.c_int),
                ("BayerPattern", ctypes.c_int),
                ("SupportedBins", ctypes.c_int * 16),
                ("SupportedVideoFormat", ctypes.c_int * 8),
                ("PixelSize", ctypes.c_double),
                ("MechanicalShutter", ctypes.c_int),
                ("ST4Port", ctypes.c_int),
                ("IsCoolerCam", ctypes.c_int),
                ("IsUSB3Host", ctypes.c_int),
                ("IsUSB3Camera", ctypes.c_int),
                ("ElecPerADU", ctypes.c_float),
                ("BitDepth", ctypes.c_int),
                ("IsTriggerCam", ctypes.c_int),
                ("Unused", ctypes.c_char * 16),
            ]

        try:
            lib = ctypes.CDLL(libs[0])
            lib.ASIGetNumOfConnectedCameras.restype = ctypes.c_int
            lib.ASIGetCameraProperty.argtypes = [ctypes.POINTER(ASICameraInfo), ctypes.c_int]
            lib.ASIGetCameraProperty.restype = ctypes.c_int
            count = max(0, int(lib.ASIGetNumOfConnectedCameras()))
            result["sdk_available"] = True
            result["library"] = libs[0]
            result["raw_count"] = count
            for index in range(count):
                info = ASICameraInfo()
                code = int(lib.ASIGetCameraProperty(ctypes.byref(info), index))
                if code != 0:
                    result["cameras"].append({"index": index, "name": f"ZWO ASI #{index}", "error_code": code})
                    continue
                name = bytes(info.Name).split(b"\0", 1)[0].decode("utf-8", errors="replace")
                bins = [int(v) for v in info.SupportedBins if int(v) > 0]
                result["cameras"].append({
                    "index": index,
                    "name": name or f"ZWO ASI #{index}",
                    "camera_id": int(info.CameraID),
                    "max_width": int(info.MaxWidth),
                    "max_height": int(info.MaxHeight),
                    "color": bool(info.IsColorCam),
                    "bayer_pattern": int(info.BayerPattern),
                    "bins": bins,
                    "usb3": bool(info.IsUSB3Camera),
                    "pixel_size_um": float(info.PixelSize),
                    "bit_depth": int(info.BitDepth),
                    "source": "official-c-sdk",
                })
        except Exception as exc:
            result["error"] = str(exc)
        return result

    @classmethod
    def discover(cls) -> dict[str, Any]:
        # Use the official C SDK for enumeration. It has already been verified
        # on the target Pi and avoids false zero-camera results from wrappers.
        result = cls._ctypes_discover()
        if result.get("cameras"):
            return result
        # Keep wrapper diagnostics as supplementary information only.
        try:
            asi, library = cls._init_sdk()
            result["sdk_available"] = True
            result["library"] = result.get("library") or library
            result["wrapper_count"] = int(asi.get_num_cameras())
            if not result.get("error") and result["wrapper_count"] == 0:
                result["error"] = "SDK loaded but no camera was enumerated"
        except Exception as exc:
            if not result.get("error"):
                result["error"] = str(exc)
        return result

    def open(self) -> dict[str, Any]:
        asi, library = self._init_sdk()
        index = max(0, int(self.config.get("zwo_camera_index", 0)))
        direct = self._ctypes_discover()
        count = len(direct.get("cameras", []))
        if count <= index:
            wrapper_count = int(asi.get_num_cameras())
            count = max(count, wrapper_count)
        if count <= index:
            raise RuntimeError(f"ZWO camera index {index} is unavailable; connected cameras: {count}")

        # Camera(index) is still used for frame capture, but enumeration is
        # validated against the official C SDK above.
        cam = asi.Camera(index)
        try:
            info = cam.get_camera_property()
            controls = cam.get_controls() or {}
            supported_bins = [int(v) for v in info.get("SupportedBins", [1]) if int(v) > 0] or [1]
            requested_bin = max(1, int(self.config.get("zwo_bin", 1)))
            binning = requested_bin if requested_bin in supported_bins else supported_bins[0]

            max_width = int(info["MaxWidth"])
            max_height = int(info["MaxHeight"])
            requested_width = int(self.config.get("zwo_width", 0) or 0)
            requested_height = int(self.config.get("zwo_height", 0) or 0)
            width = requested_width or (max_width // binning)
            height = requested_height or (max_height // binning)
            width = max(8, min(width, max_width // binning))
            height = max(2, min(height, max_height // binning))
            # ASI SDK ROI dimensions generally need even values.
            width -= width % 8
            height -= height % 2

            pixel = str(self.config.get("zwo_pixel_format", "RAW8")).upper()
            image_type = {
                "RAW8": asi.ASI_IMG_RAW8,
                "RGB24": asi.ASI_IMG_RGB24,
                "RAW16": asi.ASI_IMG_RAW16,
            }.get(pixel, asi.ASI_IMG_RAW8)
            cam.set_roi_format(width, height, binning, image_type)

            auto_exposure = bool(self.config.get("zwo_auto_exposure", True))
            auto_gain = bool(self.config.get("zwo_auto_gain", True))
            exposure = int(self.config.get("zwo_exposure_us", 20000))
            gain = int(self.config.get("zwo_gain", 100))
            cam.set_control_value(asi.ASI_EXPOSURE, exposure, auto=auto_exposure)
            cam.set_control_value(asi.ASI_GAIN, gain, auto=auto_gain)
            try:
                cam.set_control_value(
                    asi.ASI_BANDWIDTHOVERLOAD,
                    int(self.config.get("zwo_usb_bandwidth", 40)),
                    auto=False,
                )
            except Exception as exc:
                self.logger.debug("ZWO USB bandwidth control unavailable: %s", exc)
            cam.start_video_capture()
        except Exception:
            try:
                cam.close()
            except Exception:
                pass
            raise

        self.asi = asi
        self.camera = cam
        self.info = info
        self.controls = controls
        self.width = width
        self.height = height
        self.image_type = image_type
        self.pixel_format = pixel
        return {
            "backend": "zwoasi",
            "name": info.get("Name", "ZWO ASI"),
            "pixel_format": pixel,
            "width": width,
            "height": height,
            "bin": binning,
            "library": library,
            "auto_exposure": auto_exposure,
            "auto_gain": auto_gain,
        }

    def read(self):
        if self.camera is None or self.asi is None:
            return False, None
        exposure_ms = max(1, int(self.config.get('zwo_exposure_us', 5000000)) // 1000)
        timeout = max(exposure_ms + 2000, int(self.config.get("zwo_timeout_ms", exposure_ms + 2000)))
        try:
            data = self.camera.capture_video_frame(timeout=timeout)
        except Exception as exc:
            self.logger.warning("ZWO frame timeout/read error: %s", exc)
            return False, None

        width, height, _binning, image_type = self.camera.get_roi_format()
        if image_type == self.asi.ASI_IMG_RGB24:
            # SDK RGB24 is RGB byte order; OpenCV uses BGR.
            rgb = np.frombuffer(data, dtype=np.uint8).reshape((height, width, 3))
            frame = rgb[:, :, ::-1].copy()
        elif image_type == self.asi.ASI_IMG_RAW16:
            raw = np.frombuffer(data, dtype=np.uint16).reshape((height, width))
            frame8 = np.right_shift(raw, 8).astype(np.uint8)
            frame = self._debayer_or_gray(frame8)
        else:
            raw = np.frombuffer(data, dtype=np.uint8).reshape((height, width))
            frame = self._debayer_or_gray(raw)
        return True, frame

    def _debayer_or_gray(self, raw: np.ndarray) -> np.ndarray:
        if self.info and self.info.get("IsColorCam"):
            import cv2

            pattern = int(self.info.get("BayerPattern", 0))
            override = str(self.config.get("zwo_bayer_mode", "auto")).lower()
            named = {"rggb": 0, "bggr": 1, "grbg": 2, "gbrg": 3}
            if override in named:
                pattern = named[override]
            codes = {
                0: cv2.COLOR_BAYER_RG2BGR,
                1: cv2.COLOR_BAYER_BG2BGR,
                2: cv2.COLOR_BAYER_GR2BGR,
                3: cv2.COLOR_BAYER_GB2BGR,
            }
            return cv2.cvtColor(raw, codes.get(pattern, cv2.COLOR_BAYER_RG2BGR))
        return np.repeat(raw[:, :, None], 3, axis=2)

    def metadata(self) -> dict[str, Any]:
        if self.camera is None or self.asi is None:
            return {}
        result: dict[str, Any] = {}
        for key, constant in (
            ("zwo_exposure_us_actual", self.asi.ASI_EXPOSURE),
            ("zwo_gain_actual", self.asi.ASI_GAIN),
        ):
            try:
                value, auto = self.camera.get_control_value(constant)
                result[key] = value
                result[f"{key}_auto"] = bool(auto)
            except Exception:
                pass
        try:
            value, _auto = self.camera.get_control_value(self.asi.ASI_TEMPERATURE)
            result["camera_temperature_c"] = round(float(value) / 10.0, 1)
        except Exception:
            pass
        return result

    def close(self):
        if self.camera is not None:
            try:
                self.camera.stop_video_capture()
            except Exception:
                pass
            try:
                self.camera.close()
            except Exception:
                pass
        self.camera = None
        self.asi = None
