from __future__ import annotations

import cv2
import numpy as np


class ExposureController:
    """Camera-independent AllSky exposure controller with separate day/night state.

    Day calibration is intentionally fast: it starts at minimum gain and a
    millisecond-range exposure, then converges over a handful of completed
    frames.  Night/transition exposure is stored independently so a bright day
    image can never reset the next night to a millisecond exposure.
    """

    def __init__(self, config, camera, logger):
        self.config = config
        self.camera = camera
        self.logger = logger
        capture = config.get('capture', {})
        camera_cfg = config.get('camera', {})
        night_initial = float(capture.get('initial_exposure_seconds', 0.1))
        gain = float(camera_cfg.get('gain', 8.0))
        min_gain = float(camera_cfg.get('min_gain', 1.0))
        self.states = {
            'day': {'exposure': 0.001, 'gain': min_gain},
            'transition': {'exposure': max(0.002, min(0.05, night_initial)), 'gain': min_gain},
            'night': {'exposure': night_initial, 'gain': gain},
        }
        self.mode = 'night'
        self.current = self.states['night']['exposure']
        self.current_gain = self.states['night']['gain']
        self.status = {
            'enabled': False,
            'mode': self.mode,
            'auto_gain': bool(camera_cfg.get('auto_gain', False)),
            'current_seconds': self.current,
            'current_gain': self.current_gain,
            'day_seconds': self.states['day']['exposure'],
            'night_seconds': self.states['night']['exposure'],
            'max_gain': float(camera_cfg.get('max_gain', 31.62)),
            'target_percentile': 45.0,
            'measured_percentile': None,
            'change_factor': 1.0,
        }

    def _limits(self, mode):
        cfg = self.config.get('capture', {})
        if mode == 'day':
            # Use the real libcamera/sensor minimum whenever it is available.
            # The previous hard 100 us application floor was too long for an
            # IMX477 + fisheye in direct midday sun and could never converge.
            minimum = 0.00002
            try:
                if hasattr(self.camera, '_exposure_time_limits_us'):
                    minimum = max(0.000001, float(self.camera._exposure_time_limits_us()[0]) / 1_000_000.0)
            except Exception:
                pass
            return minimum, min(0.5, max(0.005, float(cfg.get('day_max_exposure_seconds', 0.25))))
        return (
            max(.0001, float(cfg.get('min_exposure_seconds', .001))),
            max(.01, float(cfg.get('max_exposure_seconds', 30.0))),
        )

    def enter_mode(self, mode):
        mode = mode if mode in self.states else 'night'
        previous = self.mode
        # Transition must inherit from the direction we are coming from. Evening
        # starts from the last daylight exposure, while morning starts from the
        # last night exposure. The old behaviour always copied the day state and
        # could therefore reset a morning transition to millisecond exposures.
        if mode == 'transition':
            source = 'night' if previous == 'night' else 'day'
            self.states['transition'] = dict(self.states[source])
        elif mode == 'night' and previous == 'transition':
            self.states['night'] = dict(self.states['transition'])
        elif mode == 'day' and previous == 'transition':
            self.states['day'] = dict(self.states['transition'])
        self.mode = mode
        self.current = float(self.states[mode]['exposure'])
        self.current_gain = float(self.states[mode]['gain'])
        self.status.update(mode=mode, current_seconds=self.current, current_gain=self.current_gain)
        return self.current

    def prepare_day(self):
        """Put the camera into a safe daylight starting point before calibration."""
        self.enter_mode('day')
        cam_cfg = self.config.get('camera', {})
        minimum, maximum = self._limits('day')
        # Never begin a new daytime calibration with a stale multi-second night
        # exposure. Re-use a known-good day value only if it is in the day range.
        exp = float(self.states['day'].get('exposure', 0.001))
        exp = max(minimum, min(maximum, exp))
        gain = max(1.0, float(cam_cfg.get('min_gain', 1.0)))
        self.current, self.current_gain = exp, gain
        self.states['day'] = {'exposure': exp, 'gain': gain}
        applied = self.camera.apply_capture_controls(exp, gain)
        if applied is not None:
            exp = float(applied)
            self.current = exp
            self.states['day']['exposure'] = exp
        self.status.update(mode='day', enabled=True, current_seconds=exp, current_gain=gain)
        return exp

    def update(self, frame, mode=None, fast=False):
        mode = mode or self.mode
        if mode not in self.states:
            mode = 'night'
        if mode != self.mode:
            self.enter_mode(mode)

        cfg = self.config.get('capture', {})
        cam_cfg = self.config.get('camera', {})
        enabled = bool(cfg.get('auto_exposure', True))
        auto_gain = bool(cam_cfg.get('auto_gain', False)) and mode != 'day'
        minimum, maximum = self._limits(mode)
        manual_gain = max(1.0, float(cam_cfg.get('gain', 8.0)))
        max_gain = max(1.0, float(cam_cfg.get('max_gain', 31.62)))
        min_gain = max(1.0, float(cam_cfg.get('min_gain', 1.0)))
        self.status.update(enabled=enabled, auto_gain=auto_gain, max_gain=max_gain, mode=mode)

        if not enabled:
            if mode == 'day':
                self.current = max(minimum, min(maximum, self.current))
                self.current_gain = min_gain
            else:
                self.current = min(maximum, max(minimum, float(cfg.get('manual_exposure_seconds', self.current))))
                self.current_gain = manual_gain
            applied = self.camera.apply_capture_controls(self.current, self.current_gain)
            if applied is not None:
                self.current = float(applied)
            self.states[mode] = {'exposure': self.current, 'gain': self.current_gain}
            self._publish(mode, None, 1.0)
            return self.current

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
        sample = cv2.resize(gray, (320, 180), interpolation=cv2.INTER_AREA)
        if mode == 'day':
            # Daylight is highlight-limited: expose from the bright end of the
            # histogram so sunlit clouds remain structured instead of clipping.
            measured = float(np.percentile(sample, 98))
            clipped = float(np.count_nonzero(sample >= 250)) / float(sample.size) * 100.0
            target = float(cfg.get('day_highlight_target', 205.0))
        else:
            measured = float(np.percentile(sample, 70))
            clipped = float(np.count_nonzero(sample >= 250)) / float(sample.size) * 100.0
            target = float(cfg.get('exposure_target', 75))
        ratio = target / max(1.0, measured)

        previous_exposure = self.current
        if mode == 'day':
            # Day calibration must converge in seconds, not minutes. Saturated
            # frames get an aggressive reduction; otherwise use a damped ratio.
            if clipped > 2.0:
                proposed = self.current * 0.18
            elif clipped > 0.50:
                proposed = self.current * 0.35
            elif clipped > 0.15 or measured > 235.0:
                proposed = self.current * 0.62
            else:
                proposed = self.current * (max(0.20, min(3.0, ratio)) ** 0.90)
            self.current = max(minimum, min(maximum, proposed))
            self.current_gain = min_gain
        else:
            if fast:
                # Transition/night calibration is deliberately much more
                # aggressive than normal tracking. This is used only for
                # discarded test frames, so the first archived frame can already
                # be sensibly exposed instead of spending minutes climbing from
                # milliseconds to seconds.
                ratio = max(.12, min(8.0, ratio))
                proposed = self.current * (ratio ** .82)
                step = max(1.5, float(cfg.get('calibration_max_exposure_step_factor', 6.0)))
            else:
                ratio = max(.35, min(2.5, ratio))
                alpha = max(.02, min(.5, float(cfg.get('exposure_smoothing', .18))))
                proposed = self.current * (ratio ** alpha)
                step = max(1.01, float(cfg.get('max_exposure_step_factor', 1.35)))
            proposed = max(self.current / step, min(self.current * step, proposed))
            self.current = max(minimum, min(maximum, proposed))
            if auto_gain:
                gain_alpha = max(.02, min(.35, float(cam_cfg.get('gain_smoothing', .10))))
                gain_step = max(1.01, float(cam_cfg.get('max_gain_step_factor', 1.18)))
                desired_gain = self.current_gain
                if measured < target * 0.88 and self.current >= maximum * 0.92:
                    desired_gain = self.current_gain * (ratio ** gain_alpha)
                elif measured > target * 1.12:
                    desired_gain = self.current_gain / ((max(1.0, measured / max(target, 1.0))) ** gain_alpha)
                desired_gain = max(self.current_gain / gain_step, min(self.current_gain * gain_step, desired_gain))
                self.current_gain = max(min_gain, min(max_gain, desired_gain))
            else:
                self.current_gain = manual_gain

        applied = self.camera.apply_capture_controls(self.current, self.current_gain)
        if applied is not None:
            self.current = float(applied)
        self.states[mode] = {'exposure': self.current, 'gain': self.current_gain}
        self._publish(mode, measured, self.current / max(.000001, previous_exposure), clipped, target)
        return self.current

    def _publish(self, mode, measured, factor, clipped=0.0, target=None):
        self.status.update(
            mode=mode,
            current_seconds=round(self.current, 6),
            current_gain=round(self.current_gain, 3),
            day_seconds=round(float(self.states['day']['exposure']), 6),
            night_seconds=round(float(self.states['night']['exposure']), 6),
            target_percentile=target if target is not None else self.status.get('target_percentile'),
            measured_percentile=round(measured, 2) if measured is not None else None,
            clipped_percent=round(clipped, 2),
            change_factor=round(factor, 3),
        )
