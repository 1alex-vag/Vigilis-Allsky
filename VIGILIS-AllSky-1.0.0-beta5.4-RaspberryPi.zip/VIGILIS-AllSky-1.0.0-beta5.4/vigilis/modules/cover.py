from __future__ import annotations
import threading
import time


class CoverController:
    """Minimal A4988 cover controller.

    OPEN: move in one direction until Hall OPEN becomes active.
    CLOSED: move in the opposite direction until Hall CLOSED becomes active.
    The opposite Hall sensor is never used as a stop condition.
    """

    FAILSAFE_SECONDS = 600.0

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.available = False
        self.error = ''
        self.state = 'unknown'
        self.moving = False
        self._thread = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._motion = {'target': None, 'steps': 0, 'elapsed_seconds': 0.0, 'reason': 'idle', 'hall_detected': False, 'offset_steps': 0, 'offset_progress': 0}
        self._init_gpio()

    def _active_low(self):
        return bool(self.config.get('cover', {}).get('hall_active_low', True))

    def _raw_level(self, sensor):
        # gpiozero's .value/.is_active are logical values that already account
        # for pull_up and active_state. For diagnostics and explicit active-low
        # handling we read the underlying physical pin level instead.
        try:
            return 1 if bool(sensor.pin.state) else 0
        except Exception:
            # With pull_up=True, is_active is True when the physical pin is LOW.
            return 0 if bool(sensor.is_active) else 1

    def _triggered(self, sensor):
        raw = self._raw_level(sensor)
        return raw == 0 if self._active_low() else raw == 1

    def _init_gpio(self):
        if not self.config.get('gpio', {}).get('enabled', True) or not self.config.get('cover', {}).get('installed', True):
            self.error = 'disabled'
            return
        try:
            from gpiozero import DigitalInputDevice, OutputDevice
            g = self.config['gpio']
            active_low_enable = bool(self.config.get('cover', {}).get('active_low_enable', True))
            self.step = OutputDevice(int(g['step_pin']), initial_value=False)
            self.direction = OutputDevice(int(g['dir_pin']), initial_value=False)
            self.enable = OutputDevice(int(g['enable_pin']), active_high=not active_low_enable, initial_value=False)
            self.hall_open = DigitalInputDevice(int(g['hall_open_pin']), pull_up=True)
            self.hall_closed = DigitalInputDevice(int(g['hall_closed_pin']), pull_up=True)
            self.available = True
            self.disable_driver()
            self._refresh_idle_state()
        except Exception as exc:
            self.error = str(exc)
            self.logger.exception('Cover GPIO init failed')

    def _refresh_idle_state(self):
        if not self.available or self.moving:
            return self.state
        opened = self._triggered(self.hall_open)
        closed = self._triggered(self.hall_closed)
        if opened and closed:
            self.state = 'fault'
            self.error = 'both Hall sensors active'
        elif opened:
            self.state = 'open'
        elif closed:
            self.state = 'closed'
        else:
            self.state = 'between'
        return self.state

    def enable_driver(self):
        self.enable.on()

    def disable_driver(self):
        self.enable.off()

    def _direction_for_target(self, target):
        normal = str(self.config.get('cover', {}).get('direction', 'normal')).lower() != 'inverted'
        open_level = bool(normal)
        return open_level if target == 'open' else not open_level

    def _target_sensor(self, target):
        return self.hall_open if target == 'open' else self.hall_closed

    def _pulse(self, half_delay):
        self.step.on()
        time.sleep(half_delay)
        self.step.off()
        time.sleep(half_delay)

    def _run_move(self, target):
        target_sensor = self._target_sensor(target)
        steps_per_minute = max(60.0, float(self.config.get('cover', {}).get('speed_steps_per_minute', 12000)))
        half_delay = 30.0 / steps_per_minute
        started = time.monotonic()
        steps = 0
        self.error = ''
        self.state = 'opening' if target == 'open' else 'closing'
        self.moving = True
        self._stop_event.clear()
        offset_steps = max(0, int(self.config.get('cover', {}).get(f'{target}_offset_steps', 0)))
        timeout_key = 'opening_timeout_seconds' if target == 'open' else 'closing_timeout_seconds'
        motion_timeout = max(5.0, float(self.config.get('cover', {}).get(timeout_key, 20)))
        confirm_seconds = max(0.0, float(self.config.get('cover', {}).get('hall_confirm_ms', 25))) / 1000.0
        hall_since = None
        offset_progress = 0
        hall_confirmed = False
        self._motion = {'target': target, 'steps': 0, 'elapsed_seconds': 0.0, 'reason': 'moving', 'hall_detected': False, 'offset_steps': offset_steps, 'offset_progress': 0}
        try:
            self.direction.value = self._direction_for_target(target)

            # If the requested target is already active, no movement is necessary.
            if self._triggered(target_sensor):
                self.state = target
                self._motion['reason'] = 'target Hall already active'
                return

            self.enable_driver()
            while not self._stop_event.is_set():
                elapsed = time.monotonic() - started
                self._motion.update(steps=steps, elapsed_seconds=round(elapsed, 3))

                # Only the requested target sensor participates in the stop logic.
                # Confirm the Hall signal briefly, then optionally continue a
                # configurable number of steps so the magnet can move from the
                # sensor fringe to the desired mechanical end position.
                if not hall_confirmed:
                    if self._triggered(target_sensor):
                        if hall_since is None:
                            hall_since = time.monotonic()
                        if time.monotonic() - hall_since >= confirm_seconds:
                            hall_confirmed = True
                            self._motion['hall_detected'] = True
                            self._motion['reason'] = f'Hall {target.upper()} detected; applying offset' if offset_steps else f'Hall {target.upper()} reached'
                            if offset_steps == 0:
                                self.state = target
                                self.logger.info('Lens cover reached %s after %d steps in %.3f s', target, steps, elapsed)
                                return
                    else:
                        hall_since = None
                else:
                    if offset_progress >= offset_steps:
                        self.state = target
                        self._motion['reason'] = f'Hall {target.upper()} reached + {offset_steps} offset steps'
                        self.logger.info('Lens cover reached %s after %d steps plus %d offset steps in %.3f s', target, steps, offset_steps, elapsed)
                        return

                if not hall_confirmed and elapsed >= motion_timeout:
                    self.state = 'fault'
                    self.error = f'{target} timeout after {motion_timeout:.0f} seconds'
                    self._motion['reason'] = self.error
                    self.logger.error('Lens cover %s timeout after %d steps / %.1f s', target, steps, elapsed)
                    return

                # Fixed emergency failsafe remains as an additional hard stop.
                if elapsed >= self.FAILSAFE_SECONDS:
                    self.state = 'fault'
                    self.error = '600-second emergency failsafe'
                    self._motion['reason'] = self.error
                    self.logger.error('Lens cover %s emergency failsafe after %d steps / %.1f s', target, steps, elapsed)
                    return

                self._pulse(half_delay)
                steps += 1
                if hall_confirmed:
                    offset_progress += 1
                    self._motion['offset_progress'] = offset_progress

            self.state = 'stopped'
            self._motion['reason'] = 'stopped by user'
        except Exception as exc:
            self.state = 'fault'
            self.error = str(exc)
            self._motion['reason'] = f'exception: {exc}'
            self.logger.exception('Lens cover %s movement failed', target)
        finally:
            self.moving = False
            self.disable_driver()

    def move_to(self, target):
        if target not in {'open', 'closed'}:
            return {'ok': False, 'error': 'invalid target'}
        if not self.available:
            return {'ok': False, 'error': self.error or 'GPIO unavailable'}
        with self._lock:
            if self._thread and self._thread.is_alive():
                return {'ok': False, 'error': 'lens cover is already moving'}
            self._thread = threading.Thread(target=self._run_move, args=(target,), daemon=True, name=f'cover-{target}')
            self._thread.start()
        return {'ok': True, 'state': 'opening' if target == 'open' else 'closing', 'reason': 'movement started'}

    def stop(self):
        self._stop_event.set()
        try:
            self.disable_driver()
        except Exception:
            pass
        return {'ok': True, 'state': 'stopping'}

    def status(self):
        state = self.state if self.moving else self._refresh_idle_state()
        cfg = self.config.get('cover', {})
        return {
            'installed': bool(cfg.get('installed', True)),
            'available': self.available,
            'error': self.error,
            'state': state,
            'moving': self.moving,
            'hall_open': self._triggered(self.hall_open) if self.available else False,
            'hall_closed': self._triggered(self.hall_closed) if self.available else False,
            'hall_open_raw': self._raw_level(self.hall_open) if self.available else None,
            'hall_closed_raw': self._raw_level(self.hall_closed) if self.available else None,
            'hall_active_low': self._active_low(),
            'mode': cfg.get('mode', 'automatic'),
            'direction': cfg.get('direction', 'normal'),
            'speed_steps_per_minute': cfg.get('speed_steps_per_minute', 12000),
            'open_offset_steps': cfg.get('open_offset_steps', 0),
            'closed_offset_steps': cfg.get('closed_offset_steps', 0),
            'hall_confirm_ms': cfg.get('hall_confirm_ms', 25),
            'open_before_detection_deg': cfg.get('open_before_detection_deg', 0.5),
            'stabilization_seconds': cfg.get('stabilization_seconds', 5),
            'opening_timeout_seconds': cfg.get('opening_timeout_seconds', 20),
            'closing_timeout_seconds': cfg.get('closing_timeout_seconds', 20),
            'motion': dict(self._motion),
        }
