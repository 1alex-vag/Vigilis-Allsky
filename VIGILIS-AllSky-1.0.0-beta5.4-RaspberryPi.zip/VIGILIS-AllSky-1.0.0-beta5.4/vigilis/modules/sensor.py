from __future__ import annotations
from pathlib import Path
import datetime as dt
import json
import threading
import time
import re


class SensorReader:
    """Read DHT22 sensors and/or a SHT31 forwarded by a RP2040 over UART."""
    def __init__(self, config, logger):
        self.config=config; self.logger=logger; self.stop_event=threading.Event(); self.thread=None
        self.latest={
            'ok':False,'status':'initializing','temperature_c':None,'humidity':None,
            'dome':self._empty('initializing'),'outdoor':self._empty('disabled'),
            'error':'not started','updated_at':None,'last_valid_at':None,'consecutive_failures':0,
        }
        self.history_root=Path(__file__).resolve().parents[2]/'data'/'environment_history'
        self.history_root.mkdir(parents=True,exist_ok=True)
        self._last_history=0.0

    @staticmethod
    def _empty(status='initializing'):
        return {'ok':False,'status':status,'temperature_c':None,'humidity':None,'error':'','updated_at':None,'last_valid_at':None,'consecutive_failures':0}

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,daemon=True,name='environment-sensors'); self.thread.start()

    def _open_sensor(self, enabled, pin_no, name):
        if not enabled: return None
        try:
            import board, adafruit_dht
            pin=getattr(board,f'D{int(pin_no)}')
            return adafruit_dht.DHT22(pin,use_pulseio=False)
        except Exception as exc:
            self.logger.warning('%s DHT22 unavailable: %s',name,exc)
            return None


    def _open_uart_sensor(self, enabled, port, baud, name):
        if not enabled:
            return None
        try:
            import serial
            dev=serial.Serial(str(port), int(baud), timeout=0.35)
            dev.reset_input_buffer()
            self.logger.info('%s SHT31/RP2040 UART opened on %s @ %s baud', name, port, baud)
            return dev
        except Exception as exc:
            self.logger.warning('%s SHT31/RP2040 UART unavailable on %s: %s', name, port, exc)
            return None

    def _read_uart(self, device, previous, name, warning_after, fault_after, stale_after):
        now=time.time()
        if device is None:
            state=dict(previous); state.update(ok=False,status='fault',error='UART unavailable',updated_at=now)
            return state
        try:
            # The RP2040 firmware sends: VIGILIS,T=18.42,H=76.31\n
            # Drain stale buffered lines and use the newest complete valid packet.
            deadline=time.monotonic()+0.8
            latest=None
            while time.monotonic() < deadline:
                raw=device.readline()
                if not raw:
                    if latest is not None: break
                    continue
                line=raw.decode('utf-8',errors='ignore').strip()
                m=re.search(r'VIGILIS\s*,\s*T\s*=\s*(-?\d+(?:\.\d+)?)\s*,\s*H\s*=\s*(\d+(?:\.\d+)?)',line,re.I)
                if m:
                    latest=(float(m.group(1)),float(m.group(2)))
                    # Keep draining immediately available bytes so the UI gets the freshest packet.
                    if getattr(device,'in_waiting',0) <= 0: break
            if latest is None:
                raise RuntimeError('no valid VIGILIS SHT31 packet')
            t,h=latest
            if not (-50 <= t <= 100) or not (0 <= h <= 100):
                raise RuntimeError('invalid sensor value')
            return {'ok':True,'status':'ok','temperature_c':round(t,1),'humidity':round(h,1),'error':'','updated_at':now,'last_valid_at':now,'consecutive_failures':0,'source':'sht31_rp2040_uart'}
        except Exception as exc:
            failures=int(previous.get('consecutive_failures',0))+1
            last_valid=previous.get('last_valid_at'); age=(now-last_valid) if last_valid else None
            if failures >= fault_after or (age is not None and age > stale_after): status='fault'; ok=False
            elif failures >= warning_after: status='warning'; ok=True
            else: status='ok'; ok=True
            state=dict(previous); state.update(ok=ok,status=status,error=str(exc),updated_at=now,consecutive_failures=failures,source='sht31_rp2040_uart')
            if failures in {warning_after,fault_after}: self.logger.warning('%s SHT31/RP2040 UART read failure (%d): %s',name,failures,exc)
            return state

    def _read_one(self, device, previous, name, warning_after, fault_after, stale_after):
        now=time.time()
        if device is None:
            state=dict(previous); state.update(ok=False,status='disabled',updated_at=now)
            return state
        try:
            t=device.temperature; h=device.humidity
            if t is None or h is None or not (-50 <= float(t) <= 100) or not (0 <= float(h) <= 100):
                raise RuntimeError('invalid sensor value')
            return {'ok':True,'status':'ok','temperature_c':round(float(t),1),'humidity':round(float(h),1),'error':'','updated_at':now,'last_valid_at':now,'consecutive_failures':0}
        except Exception as exc:
            failures=int(previous.get('consecutive_failures',0))+1
            last_valid=previous.get('last_valid_at'); age=(now-last_valid) if last_valid else None
            if failures >= fault_after or (age is not None and age > stale_after): status='fault'; ok=False
            elif failures >= warning_after: status='warning'; ok=True
            else: status='ok'; ok=True
            state=dict(previous); state.update(ok=ok,status=status,error=str(exc),updated_at=now,consecutive_failures=failures)
            if failures in {warning_after,fault_after}: self.logger.warning('%s DHT22 read failure (%d): %s',name,failures,exc)
            return state

    def _write_history(self, now):
        interval=max(30,float(self.config.get('sensor',{}).get('history_interval_seconds',60)))
        if now-self._last_history < interval: return
        self._last_history=now
        record={'timestamp':now,'iso':dt.datetime.fromtimestamp(now).isoformat(timespec='seconds'),'dome':self.latest.get('dome',{}),'outdoor':self.latest.get('outdoor',{})}
        path=self.history_root/f'{dt.date.today().isoformat()}.jsonl'
        with path.open('a',encoding='utf-8') as f: f.write(json.dumps(record,separators=(',',':'))+'\n')

    def history(self, day):
        path=self.history_root/f'{day}.jsonl'; out=[]
        if not path.exists(): return out
        for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
            try: out.append(json.loads(line))
            except Exception: pass
        return out

    def available_days(self):
        return sorted((p.stem for p in self.history_root.glob('*.jsonl')),reverse=True)

    def history_range(self, start, end, max_points=1800):
        """Load an inclusive local-date range and aggregate it for chart display.

        Statistics are calculated from all valid raw samples, while the returned
        chart samples are averaged into time buckets when the selected range is
        large. This keeps one-year charts responsive on Raspberry Pi.
        """
        if isinstance(start, str): start=dt.date.fromisoformat(start)
        if isinstance(end, str): end=dt.date.fromisoformat(end)
        if end < start: start,end=end,start
        raw=[]; day=start
        while day <= end:
            raw.extend(self.history(day.isoformat()))
            day += dt.timedelta(days=1)
        raw.sort(key=lambda item: float(item.get('timestamp',0) or 0))
        stats={}; fields=('temperature_c','humidity')
        for key in ('dome','outdoor'):
            stats[key]={}
            for field in fields:
                values=[]
                for item in raw:
                    value=(item.get(key) or {}).get(field)
                    if isinstance(value,(int,float)): values.append(float(value))
                stats[key][field]={
                    'min':round(min(values),2) if values else None,
                    'avg':round(sum(values)/len(values),2) if values else None,
                    'max':round(max(values),2) if values else None,
                    'count':len(values),
                }
        if not raw or len(raw) <= max_points:
            return raw,stats,len(raw)
        first=float(raw[0].get('timestamp',0) or 0); last=float(raw[-1].get('timestamp',first) or first)
        span=max(1.0,last-first); bucket_seconds=max(60.0,span/max_points)
        buckets={}
        for item in raw:
            timestamp=float(item.get('timestamp',0) or 0)
            bucket=int((timestamp-first)//bucket_seconds)
            acc=buckets.setdefault(bucket,{'timestamp_sum':0.0,'timestamp_count':0,'values':{}})
            acc['timestamp_sum']+=timestamp; acc['timestamp_count']+=1
            for key in ('dome','outdoor'):
                for field in fields:
                    value=(item.get(key) or {}).get(field)
                    if isinstance(value,(int,float)):
                        slot=acc['values'].setdefault((key,field),[0.0,0])
                        slot[0]+=float(value); slot[1]+=1
        samples=[]
        for bucket in sorted(buckets):
            acc=buckets[bucket]; timestamp=acc['timestamp_sum']/max(1,acc['timestamp_count'])
            record={'timestamp':timestamp,'iso':dt.datetime.fromtimestamp(timestamp).isoformat(timespec='seconds'),'dome':{},'outdoor':{}}
            for (key,field),(total,count) in acc['values'].items(): record[key][field]=round(total/count,2)
            samples.append(record)
        return samples,stats,len(raw)

    def _run(self):
        scfg=self.config.get('sensor',{}); gcfg=self.config.get('gpio',{})
        # Beta 4.3 exposed SHT31/RP2040 only as an Outdoor sensor. For backward
        # compatibility, an unconfigured Dome inherits that UART setup when the
        # Outdoor channel itself is disabled.
        legacy_indoor_sht=(not scfg.get('dome_sensor_type') and str(scfg.get('outdoor_sensor_type','')).lower() in {'sht31_uart','sht31_rp2040','uart_sht31'} and not bool(scfg.get('outdoor_sensor_enabled',scfg.get('outdoor_dht22_enabled',False))))
        dome_enabled=bool(scfg.get('dome_sensor_enabled', True if legacy_indoor_sht else scfg.get('dht22_enabled',True)))
        dome_type=str(scfg.get('dome_sensor_type','sht31_uart' if legacy_indoor_sht else 'dht22')).lower()
        dome_uart_port=scfg.get('dome_uart_port',scfg.get('outdoor_uart_port','/dev/ttyAMA4') if legacy_indoor_sht else '/dev/ttyAMA4')
        dome_uart_baud=scfg.get('dome_uart_baud',scfg.get('outdoor_uart_baud',9600) if legacy_indoor_sht else 9600)
        dome_dht=self._open_sensor(dome_enabled and dome_type=='dht22',gcfg.get('dht_pin',4),'Dome')
        dome_uart=self._open_uart_sensor(dome_enabled and dome_type in {'sht31_uart','sht31_rp2040','uart_sht31'},dome_uart_port,dome_uart_baud,'Dome')
        outdoor_type=str(scfg.get('outdoor_sensor_type','dht22')).lower()
        outdoor_enabled=bool(scfg.get('outdoor_sensor_enabled',scfg.get('outdoor_dht22_enabled',False)))
        outdoor_dht=self._open_sensor(outdoor_enabled and outdoor_type=='dht22',gcfg.get('outdoor_dht_pin',18),'Outdoor')
        outdoor_uart=self._open_uart_sensor(outdoor_enabled and outdoor_type in {'sht31_uart','sht31_rp2040','uart_sht31'},scfg.get('outdoor_uart_port','/dev/ttyAMA4'),scfg.get('outdoor_uart_baud',9600),'Outdoor')
        interval=max(3.0,float(scfg.get('read_interval_seconds',10)))
        warning_after=max(1,int(scfg.get('warning_after_failures',2))); fault_after=max(warning_after+1,int(scfg.get('fault_after_failures',5)))
        stale_after=max(interval*2,float(scfg.get('stale_after_seconds',60)))
        while not self.stop_event.is_set():
            if not dome_enabled:
                self.latest['dome']=self._empty('disabled')
            elif dome_type == 'dht22':
                self.latest['dome']=self._read_one(dome_dht,self.latest.get('dome',self._empty()),'Dome',warning_after,fault_after,stale_after)
            elif dome_type in {'sht31_uart','sht31_rp2040','uart_sht31'}:
                self.latest['dome']=self._read_uart(dome_uart,self.latest.get('dome',self._empty()),'Dome',warning_after,fault_after,stale_after)
            else:
                self.latest['dome']=self._empty('disabled')
            # DHT22 sensors need some quiet time between reads. UART does not.
            if outdoor_type == 'dht22':
                if outdoor_dht is not None: time.sleep(2.1)
                self.latest['outdoor']=self._read_one(outdoor_dht,self.latest.get('outdoor',self._empty('disabled')),'Outdoor',warning_after,fault_after,stale_after)
            elif outdoor_type in {'sht31_uart','sht31_rp2040','uart_sht31'}:
                self.latest['outdoor']=self._read_uart(outdoor_uart,self.latest.get('outdoor',self._empty()),'Outdoor',warning_after,fault_after,stale_after)
            else:
                self.latest['outdoor']=self._empty('disabled')
            d=self.latest['dome']; self.latest.update({
                'ok':d.get('ok',False),'status':d.get('status','fault'),'temperature_c':d.get('temperature_c'),'humidity':d.get('humidity'),
                'error':d.get('error',''),'updated_at':d.get('updated_at'),'last_valid_at':d.get('last_valid_at'),'consecutive_failures':d.get('consecutive_failures',0),
            })
            self._write_history(time.time())
            self.stop_event.wait(interval)
