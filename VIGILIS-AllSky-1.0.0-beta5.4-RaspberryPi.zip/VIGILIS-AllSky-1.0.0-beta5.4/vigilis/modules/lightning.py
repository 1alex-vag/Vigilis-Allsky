from __future__ import annotations
from pathlib import Path
import json, re, threading, time

class LightningDetector:
    """Optional AS3935 bridge over SAMD21 UART.

    Expected event line:
      VIGILIS_LIGHTNING,D=14,E=18423
    D is AS3935 estimated distance in km, E is the chip's relative energy value.
    The module remains completely idle while disabled.
    """
    EVENT_RE = re.compile(r'VIGILIS_LIGHTNING(?:,D=(?P<distance>\d+(?:\.\d+)?|NA))?(?:,E=(?P<energy>\d+))?', re.I)

    def __init__(self, config, root: Path, logger):
        self.config=config; self.root=Path(root); self.logger=logger
        self.stop_event=threading.Event(); self.thread=None; self.serial=None
        self.history_root=self.root/'data'/'lightning_history'; self.history_root.mkdir(parents=True,exist_ok=True)
        self.latest={'configured':False,'online':False,'status':'not_configured','last_strike_at':None,
                     'distance_km':None,'relative_energy':None,'closest_today_km':None,'strikes_today':0,
                     'event_id':0,'error':''}

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,daemon=True,name='lightning-detector'); self.thread.start()

    def _cfg(self): return self.config.get('lightning',{}) or {}

    def _append(self,event):
        ts=float(event['timestamp']); day=time.strftime('%Y-%m-%d',time.localtime(ts))
        p=self.history_root/f'{day}.jsonl'
        with p.open('a',encoding='utf-8') as f: f.write(json.dumps(event,separators=(',',':'))+'\n')

    def record_event(self,distance_km=None,relative_energy=None,timestamp=None):
        ts=float(timestamp or time.time()); eid=int(self.latest.get('event_id') or 0)+1
        distance=None if distance_km is None else float(distance_km)
        energy=None if relative_energy is None else int(relative_energy)
        event={'timestamp':ts,'distance_km':distance,'relative_energy':energy,'event_id':eid}
        self._append(event)
        today=time.strftime('%Y-%m-%d',time.localtime(ts))
        events=self.history_range('24h')['events']
        today_events=[e for e in events if time.strftime('%Y-%m-%d',time.localtime(e['timestamp']))==today]
        distances=[e['distance_km'] for e in today_events if e.get('distance_km') is not None]
        self.latest.update({'configured':True,'online':True,'status':'active','last_strike_at':ts,
                            'distance_km':distance,'relative_energy':energy,'closest_today_km':min(distances) if distances else distance,
                            'strikes_today':len(today_events),'event_id':eid,'error':''})
        return event

    def _run(self):
        while not self.stop_event.is_set():
            cfg=self._cfg(); enabled=bool(cfg.get('enabled',False))
            self.latest['configured']=enabled
            if not enabled:
                self.latest.update(online=False,status='not_configured',error='')
                if self.serial:
                    try:self.serial.close()
                    except Exception:pass
                    self.serial=None
                self.stop_event.wait(1.0); continue
            if self.serial is None:
                try:
                    import serial
                    self.serial=serial.Serial(str(cfg.get('uart_port','/dev/ttyAMA3')),int(cfg.get('uart_baud',9600)),timeout=.5)
                    self.serial.reset_input_buffer(); self.latest.update(online=True,status='ready',error='')
                except Exception as exc:
                    self.latest.update(online=False,status='offline',error=str(exc))
                    self.stop_event.wait(3.0); continue
            try:
                line=self.serial.readline().decode('utf-8','ignore').strip()
                if not line: continue
                m=self.EVENT_RE.search(line)
                if not m: continue
                d=m.group('distance'); e=m.group('energy')
                self.record_event(None if not d or d.upper()=='NA' else float(d), None if e is None else int(e))
            except Exception as exc:
                self.latest.update(online=False,status='offline',error=str(exc))
                try:self.serial.close()
                except Exception:pass
                self.serial=None; self.stop_event.wait(1.0)

    def history_range(self,range_key='24h'):
        now=time.time(); seconds={'24h':86400,'7d':7*86400,'30d':30*86400,'6m':183*86400,'1y':365*86400}.get(str(range_key),86400)
        cutoff=now-seconds; events=[]
        for p in sorted(self.history_root.glob('*.jsonl')):
            try:
                for line in p.read_text(encoding='utf-8').splitlines():
                    e=json.loads(line)
                    if float(e.get('timestamp',0))>=cutoff: events.append(e)
            except Exception: continue
        events.sort(key=lambda x:float(x.get('timestamp',0)))
        ds=[float(e['distance_km']) for e in events if e.get('distance_km') is not None]
        return {'ok':True,'range':range_key,'events':events,'count':len(events),
                'closest_km':min(ds) if ds else None,'last':events[-1] if events else None}
