from __future__ import annotations
from pathlib import Path
import math
import cv2
import numpy as np

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:  # Pillow is installed by requirements, OpenCV fallback stays available
    Image = ImageDraw = ImageFont = None


def _clamp(v, lo, hi): return max(lo, min(hi, v))


def _legacy_elements(cfg):
    """Convert the pre-2.9 single block in memory without rewriting user config."""
    fields = cfg.get('fields', {}) or {}
    x = float(cfg.get('x', .03)); y = float(cfg.get('y', .90)); fs = float(cfg.get('font_scale', .75)); bg = float(cfg.get('background_opacity', .35))
    result = {}
    order = ['date', 'time', 'location', 'temperature', 'humidity', 'sun_altitude', 'exposure', 'gain', 'custom_text']
    for i, key in enumerate(order):
        result[key] = {
            'enabled': bool(fields.get(key, key in {'date', 'time'})),
            'x': x, 'y': _clamp(y + i * .035, 0, 1),
            'font_size_percent': max(.4, min(8.0, fs * 2.5)),
            'font_weight': 'normal', 'align': 'left', 'background_opacity': bg,
        }
    return result


def _text_for(key, config, now, schedule, exposure_controller, camera, sensor, cfg, capture_metadata=None):
    if key == 'date': return now.strftime('%d.%m.%Y')
    if key == 'time': return now.strftime('%H:%M:%S')
    if key == 'location': return str(config.get('location', {}).get('name', '')).strip()
    if key == 'temperature' and sensor is not None:
        v = (sensor.latest or {}).get('temperature_c'); return '' if v is None else f'{float(v):.1f} °C'
    if key == 'humidity' and sensor is not None:
        v = (sensor.latest or {}).get('humidity'); return '' if v is None else f'{float(v):.1f} % RH'
    if key == 'sun_altitude':
        v = schedule.sun_altitude(); return '' if v is None else f'Sun {float(v):+.1f}°'
    if key == 'exposure':
        meta=capture_metadata or {}
        raw=meta.get('ExposureTime')
        if raw is not None:
            try: seconds=float(raw)/1_000_000.0
            except Exception: seconds=None
        else:
            seconds=float(exposure_controller.current) if exposure_controller is not None else None
        if seconds is None: return ''
        unit=str((cfg or {}).get('exposure_unit','s')).lower()
        if unit in {'us','µs'}: return f'Exp {seconds*1_000_000:.0f} µs'
        if unit == 'ms': return f'Exp {seconds*1000:.3f} ms'
        if unit == 'auto':
            if seconds < .001: return f'Exp {seconds*1_000_000:.0f} µs'
            if seconds < 1.0: return f'Exp {seconds*1000:.3f} ms'
            return f'Exp {seconds:.3f} s'
        # Default is intentionally seconds so Day / Transition / Night keep a
        # visually stable unit in timelapses and archived images.
        return f'Exp {seconds:.6f} s' if seconds < .01 else f'Exp {seconds:.3f} s'
    if key == 'gain':
        meta=capture_metadata or {}
        v=meta.get('AnalogueGain')
        if v is None and camera is not None: v=camera.status.get('analogue_gain')
        return '' if v is None else f'Gain {float(v):.2f}'
    if key == 'custom_text': return str(cfg.get('custom_text', '')).strip()
    return ''


def _font_path(weight='normal'):
    bold = str(weight).lower() == 'bold'
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',
        '/usr/share/fonts/opentype/noto/NotoSans-Bold.ttf' if bold else '/usr/share/fonts/opentype/noto/NotoSans-Regular.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ]
    for p in candidates:
        if Path(p).exists(): return p
    return None


def _draw_text(frame, text, spec):
    """Unicode-safe text renderer with normalized position and image-relative size."""
    if not text: return
    h, w = frame.shape[:2]
    pct = spec.get('font_size_percent')
    if pct is None:
        pct = max(.2, min(8.0, float(spec.get('font_scale', .34)) * 4.5))
    pct = _clamp(float(pct), .2, 8.0)
    px = max(6, int(round(h * pct / 100.0)))
    anchor_x = float(_clamp(float(spec.get('x', .5)), 0, 1)) * w
    anchor_y = float(_clamp(float(spec.get('y', .5)), 0, 1)) * h
    align = str(spec.get('align', 'center'))
    weight = str(spec.get('font_weight', 'normal'))
    bg = _clamp(float(spec.get('background_opacity', 0)), 0, 1)

    if Image is not None:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb)
        draw = ImageDraw.Draw(pil, 'RGBA')
        font_path = _font_path(weight)
        try:
            font = ImageFont.truetype(font_path, px) if font_path else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), text, font=font, stroke_width=0)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        if align == 'left': x = anchor_x
        elif align == 'right': x = anchor_x - tw
        else: x = anchor_x - tw / 2
        y = anchor_y - th / 2 - bbox[1]
        pad = max(2, int(px * .22))
        x = max(pad, min(w - tw - pad, x)); y = max(pad - bbox[1], min(h - th - pad - bbox[1], y))
        if bg > 0:
            draw.rounded_rectangle((x-pad, y+bbox[1]-pad, x+tw+pad, y+bbox[3]+pad), radius=max(2, pad), fill=(0, 0, 0, int(255*bg)))
        draw.text((x, y), text, font=font, fill=(255,255,255,255))
        frame[:] = cv2.cvtColor(np.asarray(pil), cv2.COLOR_RGB2BGR)
        return

    # Last-resort fallback for environments where Pillow is unavailable.
    thick = 2 if weight == 'bold' else 1
    (_, unit_h), unit_base = cv2.getTextSize('Ag', cv2.FONT_HERSHEY_SIMPLEX, 1.0, thick)
    scale = max(.08, px / max(1.0, float(unit_h)))
    (tw, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, thick)
    x = anchor_x if align == 'left' else anchor_x - tw if align == 'right' else anchor_x - tw/2
    y = anchor_y + (th-base)/2
    x = int(max(4, min(w-tw-4, x))); y = int(max(th+5, min(h-base-5, y)))
    cv2.putText(frame, text, (x,y), cv2.FONT_HERSHEY_SIMPLEX, scale, (255,255,255), thick, cv2.LINE_AA)


def _alpha_blend(frame, rgba, cx, cy, target_w, opacity=1.0):
    if rgba is None or rgba.size == 0: return
    h, w = frame.shape[:2]; target_w = max(8, min(w, int(target_w))); ratio = target_w / rgba.shape[1]; target_h = max(1, int(rgba.shape[0] * ratio))
    rgba = cv2.resize(rgba, (target_w, target_h), interpolation=cv2.INTER_AREA)
    if rgba.shape[2] == 3:
        alpha = np.full((target_h, target_w, 1), 255, dtype=np.uint8); rgba = np.concatenate([rgba, alpha], axis=2)
    x0 = int(cx-target_w/2); y0 = int(cy-target_h/2); x1 = x0+target_w; y1 = y0+target_h
    sx0=max(0,-x0); sy0=max(0,-y0); sx1=target_w-max(0,x1-w); sy1=target_h-max(0,y1-h)
    x0=max(0,x0); y0=max(0,y0); x1=min(w,x1); y1=min(h,y1)
    if x1<=x0 or y1<=y0:return
    src=rgba[sy0:sy1,sx0:sx1,:3].astype(np.float32); a=(rgba[sy0:sy1,sx0:sx1,3:4].astype(np.float32)/255.0)*_clamp(float(opacity),0,1)
    dst=frame[y0:y1,x0:x1].astype(np.float32); frame[y0:y1,x0:x1]=(src*a+dst*(1-a)).astype(np.uint8)


def _compass_rgba(size=768, rotation=0):
    """Clean compass: large ring, external N/S/W/O labels, no crosshair."""
    im = np.zeros((size, size, 4), np.uint8); c = size // 2
    ring_r = int(size * .34); label_r = int(size * .455)
    stroke = max(3, size // 120)
    cv2.circle(im, (c, c), ring_r, (255,255,255,225), stroke, cv2.LINE_AA)
    # German-style cardinal labels requested by the user: N / S / W / O.
    for text, ang in [('N', -90), ('O', 0), ('S', 90), ('W', 180)]:
        a = math.radians(ang + rotation)
        x = int(c + math.cos(a) * label_r); y = int(c + math.sin(a) * label_r)
        fs = size / 430.0; thk = max(2, size // 180)
        (tw, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, fs, thk)
        cv2.putText(im, text, (x - tw//2, y + (th-base)//2), cv2.FONT_HERSHEY_SIMPLEX, fs, (255,255,255,245), thk, cv2.LINE_AA)
    return im


def _vigilis_rgba(size=1200):
    path = Path(__file__).resolve().parents[1] / 'static' / 'logo.png'
    if path.exists():
        im = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if im is not None and im.ndim == 3:
            if im.shape[2] == 3:
                alpha=np.full((im.shape[0],im.shape[1],1),255,dtype=np.uint8); im=np.concatenate([im,alpha],axis=2)
            return im
    im=np.zeros((260,size,4),np.uint8); text='VIGILIS  ALLSKY'; fs=3.0; th=5
    (tw,hh),_=cv2.getTextSize(text,cv2.FONT_HERSHEY_SIMPLEX,fs,th); x=max(0,(size-tw)//2); y=150
    cv2.putText(im,text,(x,y),cv2.FONT_HERSHEY_SIMPLEX,fs,(255,255,255,235),th,cv2.LINE_AA)
    return im


def apply_overlay(frame, config, now, schedule, exposure_controller=None, camera=None, sensor=None, capture_metadata=None):
    cfg = config.get('overlay', {}) or {}
    if not cfg.get('enabled', False): return frame
    elements = cfg.get('elements') or _legacy_elements(cfg)
    for key in ['date','time','location','temperature','humidity','sun_altitude','exposure','gain','custom_text']:
        spec = elements.get(key,{}) or {}
        if spec.get('enabled',False): _draw_text(frame,_text_for(key,config,now,schedule,exposure_controller,camera,sensor,cfg,capture_metadata),spec)
    h,w=frame.shape[:2]
    spec=elements.get('compass',{}) or {}
    if spec.get('enabled'):
        _alpha_blend(frame,_compass_rgba(rotation=float(spec.get('rotation_deg',0))),float(spec.get('x',.1))*w,float(spec.get('y',.12))*h,float(spec.get('scale',.12))*w,spec.get('opacity',.9))
    spec=elements.get('vigilis_logo',{}) or {}
    if spec.get('enabled'):
        _alpha_blend(frame,_vigilis_rgba(),float(spec.get('x',.5))*w,float(spec.get('y',.08))*h,float(spec.get('scale',.18))*w,spec.get('opacity',.9))
    spec=elements.get('custom_image',{}) or {}; asset=str(cfg.get('asset','')).strip()
    if spec.get('enabled') and asset:
        path=Path(__file__).resolve().parents[2]/'data'/'overlay_assets'/Path(asset).name
        if path.exists():
            rgba=cv2.imread(str(path),cv2.IMREAD_UNCHANGED)
            if rgba is not None:
                _alpha_blend(frame,rgba,float(spec.get('x',.82))*w,float(spec.get('y',.10))*h,float(spec.get('scale',.16))*w,spec.get('opacity',1.0))
    return frame
