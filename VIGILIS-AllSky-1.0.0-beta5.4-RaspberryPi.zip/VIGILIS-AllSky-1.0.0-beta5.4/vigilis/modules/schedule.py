from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from astral import Observer
from astral.sun import elevation

class SkySchedule:
    def __init__(self, config): self.config=config
    def now(self):
        tz=str(self.config.get('location',{}).get('timezone','UTC'))
        try: return datetime.now(ZoneInfo(tz))
        except Exception: return datetime.now().astimezone()
    def sun_altitude(self):
        loc=self.config['location']; obs=Observer(float(loc['latitude']),float(loc['longitude']),float(loc.get('elevation_m',0) or 0))
        try: return round(float(elevation(obs,self.now())),2)
        except Exception: return None
    def time_window_active(self,start,stop):
        now=self.now().strftime('%H:%M'); return (start<=now or now<stop) if start>stop else start<=now<stop
    def status(self):
        sun=self.sun_altitude(); cfg=self.config.get('capture',{}); mode=str(cfg.get('schedule_mode','always'))
        if mode=='disabled': active,label=False,'Nachtaufnahme deaktiviert'
        elif mode=='custom':
            active=self.time_window_active(str(cfg.get('custom_start','20:00')),str(cfg.get('custom_stop','06:00'))); label='AllSky-Nachtaufnahme aktiv' if active else 'Tagbetrieb'
        elif mode=='sun':
            threshold=float(cfg.get('start_sun_altitude',-4.0)); active=sun is not None and sun<=threshold; label='AllSky-Nachtaufnahme aktiv' if active else 'Tagbetrieb'
        else: active,label=True,'AllSky-Aufnahme aktiv'
        return {'active':active,'night_active':active,'label':label,'mode':mode,'sun_altitude':sun,'local_time':self.now().isoformat(),'timezone':str(self.config.get('location',{}).get('timezone','UTC'))}
