from pathlib import Path
import os, shutil, time
import psutil

def _cpu_temp():
    for p in (Path('/sys/class/thermal/thermal_zone0/temp'),):
        try: return round(float(p.read_text().strip())/1000,1)
        except Exception: pass
    return None

def get_system_info(root: Path) -> dict:
    du=shutil.disk_usage(root)
    vm=psutil.virtual_memory()
    return {
        'cpu_percent': psutil.cpu_percent(interval=None),
        'cpu_temp_c': _cpu_temp(),
        'ram_percent': vm.percent,
        'ram_available_mb': round(vm.available/1024/1024),
        'disk_free_gb': round(du.free/1024**3,1),
        'disk_percent': round((du.used/du.total)*100,1),
        'uptime_seconds': int(time.time()-psutil.boot_time()),
    }
