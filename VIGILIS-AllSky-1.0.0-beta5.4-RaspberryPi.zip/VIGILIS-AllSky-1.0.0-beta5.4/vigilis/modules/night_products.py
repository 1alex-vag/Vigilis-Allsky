from __future__ import annotations
from datetime import datetime, timedelta
from pathlib import Path
import gc, json, os, shutil, subprocess, tempfile, threading, time, math
import cv2
import numpy as np


class NightProducts:
    """Create timelapse/startrail/keogram products with bounded RAM use.

    Beta 2.1 kept one-pixel NumPy *views* from every source frame for the
    keogram.  A view keeps the complete 4056x3040 source allocation alive, so
    roughly one hundred IMX477 frames were enough to consume ~3.7 GB and make
    Linux's OOM killer terminate VIGILIS.  Beta 2.2 never retains source
    frames: every frame is read, consumed and released before the next one.
    """

    def __init__(self, config, root: Path, schedule, logger):
        self.config=config; self.root=root; self.schedule=schedule; self.logger=logger
        self.stop_event=threading.Event(); self.thread=None
        self.process_lock=threading.Lock()
        self.status={'running':False,'last_processed_night':None,'last_processed_day':None,
                     'last_error':'','current_job':None,'job_label':None,'progress_percent':0,
                     'processed_frames':0,'total_frames':0,'memory_safe':True}

    def start(self):
        if not self.thread or not self.thread.is_alive():
            self.thread=threading.Thread(target=self._run,daemon=True,name='night-products'); self.thread.start()
    def stop(self): self.stop_event.set()

    def _period_dir(self, day, period):
        return self.root/str(self.config.get('capture',{}).get('archive_path','allsky'))/day.strftime('%Y/%m/%d')/period
    def _night_dir(self, day): return self._period_dir(day,'Nacht')
    @staticmethod
    def _image_dir(d: Path):
        p=d/'images'
        return p if p.exists() else d
    @staticmethod
    def _product_dir(d: Path):
        p=d/'products'; p.mkdir(parents=True,exist_ok=True); return p
    def _frames(self,d):
        src=self._image_dir(Path(d))
        excluded={'startrails.jpg','startrail.jpg','keogram.jpg'}
        return sorted([p for p in [*src.glob('*.jpg'),*src.glob('*.jpeg'),*src.glob('*.png')]
                       if p.name not in excluded])

    @staticmethod
    def _captured_at(path: Path) -> str:
        side=Path(path).with_suffix('.json')
        try:
            value=json.loads(side.read_text()).get('captured_at')
            if value:
                return str(value)
        except Exception:
            pass
        try:
            return datetime.fromtimestamp(Path(path).stat().st_mtime).astimezone().isoformat()
        except Exception:
            return ''

    @staticmethod
    def _night_anchor(captured_at: str, fallback_day):
        try:
            stamp=datetime.fromisoformat(str(captured_at))
            return stamp.date()-timedelta(days=1) if stamp.hour<12 else stamp.date()
        except Exception:
            return fallback_day

    def _night_session_frames(self, anchor_day):
        """Collect one complete sunset→sunrise session, including frames after midnight."""
        base=self.root/str(self.config.get('capture',{}).get('archive_path','allsky'))
        out=[]
        if not base.exists():
            return out
        for folder in base.glob('*/*/*/Nacht'):
            try:
                fallback=datetime.strptime('/'.join(folder.parts[-4:-1]),'%Y/%m/%d').date()
            except Exception:
                continue
            src=self._image_dir(folder)
            for frame in [*src.glob('*.jpg'),*src.glob('*.jpeg'),*src.glob('*.png')]:
                if frame.name in {'startrails.jpg','startrail.jpg','keogram.jpg'}:
                    continue
                captured=self._captured_at(frame)
                if self._night_anchor(captured,fallback)==anchor_day:
                    out.append(frame)
        def key(path):
            captured=self._captured_at(path)
            try:
                return datetime.fromisoformat(captured).timestamp()
            except Exception:
                try:
                    return Path(path).stat().st_mtime
                except Exception:
                    return 0
        return sorted(out,key=key)

    @staticmethod
    def _marker_frame_count(marker: Path):
        """Return recorded frame count, or None for legacy/pre-5.4 markers."""
        try:
            raw=json.loads(marker.read_text())
            value=raw.get('frames')
            return int(value) if value is not None else None
        except Exception:
            return None

    @staticmethod
    def _write_marker(marker: Path, now, frame_count: int):
        marker.write_text(json.dumps({
            'completed_at': now.isoformat(),
            'frames': int(frame_count),
            'format': 2,
        },separators=(',',':')))

    @staticmethod
    def _available_memory_mb():
        try:
            for line in Path('/proc/meminfo').read_text().splitlines():
                if line.startswith('MemAvailable:'):
                    return int(line.split()[1])//1024
        except Exception:
            pass
        return None

    def _run(self):
        while not self.stop_event.wait(30):
            try:
                cfg=self.config.get('processing',{}); mode=str(cfg.get('auto_mode','after_period'))
                if mode=='off' or self.status['running']: continue
                now=self.schedule.now()
                if mode=='fixed_time':
                    hh,mm=[int(x) for x in str(cfg.get('fixed_time','07:00')).split(':',1)]
                    if (now.hour,now.minute)!=(hh,mm): continue
                elif self.schedule.status().get('active'):
                    continue
                # Beta 5.4 reliability rule:
                # Never process the *current* observing night during the evening
                # transition.  "after_period" is allowed only after the morning
                # transition has finished.  In the afternoon/evening the newest
                # completed observing night is therefore yesterday's anchor.
                sun=self.schedule.sun_altitude()
                morning_end=float(self.config.get('capture',{}).get('morning_transition_end_sun_altitude',0))
                if mode=='after_period':
                    if sun is not None and sun <= morning_end:
                        continue
                    if now.hour < 12:
                        night_day=(now-timedelta(hours=12)).date()
                    else:
                        night_day=now.date()-timedelta(days=1)
                    # A Tag archive must also be fully closed before automatic
                    # processing; use the previous calendar day.
                    day_day=now.date()-timedelta(days=1)
                else:
                    # fixed_time keeps the existing noon-anchor behaviour.
                    night_day=(now-timedelta(hours=12)).date()
                    day_day=night_day

                for period,day,keyname,enabled in (
                    ('Nacht',night_day,'last_processed_night',bool(cfg.get('process_night',True))),
                    ('Tag',day_day,'last_processed_day',bool(cfg.get('process_day',True))),
                ):
                    if not enabled:
                        continue
                    marker=self.root/'data'/'products'/f'{day.isoformat()}-{period.lower()}.done'
                    marker.parent.mkdir(parents=True,exist_ok=True)

                    if period=='Nacht':
                        # Build products from the complete sunset→sunrise session,
                        # even when files are physically split across midnight.
                        frames=self._night_session_frames(day)
                        d=self._night_dir(day)
                    else:
                        d=self._period_dir(day,period)
                        frames=self._frames(d)

                    if len(frames)<2:
                        continue

                    recorded=self._marker_frame_count(marker) if marker.exists() else None
                    # A JSON marker with the exact same frame count is complete.
                    # Legacy markers (pre-5.4) are deliberately regenerated once,
                    # which also repairs nights that were marked done too early.
                    if recorded is not None and recorded==len(frames):
                        continue

                    if self.process(d,frames):
                        self._write_marker(marker,now,len(frames))
                        self.status[keyname]=day.isoformat()
            except Exception as exc:
                self.status.update(running=False,current_job=None,job_label=None,last_error=str(exc)); self.logger.exception('Automatic product generation failed')

    @staticmethod
    def _fit_size(w,h,resolution):
        max_w=2560 if str(resolution).lower()=='2k' else 1920
        if w<=max_w:
            ow=w
        else:
            ow=max_w
        oh=max(2,int(round(h*(ow/w))))
        ow-=ow%2; oh-=oh%2
        return max(2,ow),max(2,oh)

    @staticmethod
    def _keogram_column(img, angle_deg=0.0, sample_width=9, center_x_percent=50.0, center_y_percent=50.0):
        """Sample a movable/rotatable sky line for the keogram.

        Beta 2.7 allows the sampling line to be moved away from roofs, cables
        and the enclosure.  The line is intersected with the image borders and
        resampled to the source image height so every frame contributes exactly
        one fixed-size keogram column.  A narrow perpendicular band is averaged
        to suppress hot columns/pixels without retaining the source frame.
        """
        h,w=img.shape[:2]
        length=h
        cx=(w-1)*max(0.0,min(100.0,float(center_x_percent)))/100.0
        cy=(h-1)*max(0.0,min(100.0,float(center_y_percent)))/100.0
        a=math.radians(float(angle_deg)%360.0)
        dx=math.sin(a); dy=math.cos(a)  # 0° vertical, 90° horizontal
        px=math.cos(a); py=-math.sin(a)

        # Find the full segment of the selected line that lies inside the frame.
        bounds=[]
        eps=1e-9
        if abs(dx)>eps:
            bounds.extend([(0-cx)/dx, ((w-1)-cx)/dx])
        if abs(dy)>eps:
            bounds.extend([(0-cy)/dy, ((h-1)-cy)/dy])
        neg=[t for t in bounds if t<=0]; pos=[t for t in bounds if t>=0]
        t0=max(neg) if neg else -min(h,w)/2.0
        t1=min(pos) if pos else min(h,w)/2.0
        if t1<=t0:
            t0,t1=-(length-1)/2.0,(length-1)/2.0
        t=np.linspace(t0,t1,length,dtype=np.float32)

        offsets=np.linspace(-(sample_width-1)/2.0,(sample_width-1)/2.0,max(1,int(sample_width)),dtype=np.float32)
        accum=np.zeros((length,3),dtype=np.float32)
        valid=np.zeros((length,1),dtype=np.float32)
        for off in offsets:
            xs=cx+t*dx+off*px; ys=cy+t*dy+off*py
            mask=(xs>=0)&(xs<=w-1)&(ys>=0)&(ys<=h-1)
            mapx=np.clip(xs,0,w-1).reshape(-1,1).astype(np.float32)
            mapy=np.clip(ys,0,h-1).reshape(-1,1).astype(np.float32)
            sampled=cv2.remap(img,mapx,mapy,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).reshape(length,3)
            accum[mask]+=sampled[mask]
            valid[mask]+=1.0
        valid=np.maximum(valid,1.0)
        return np.clip(accum/valid,0,255).astype(np.uint8)

    def process(self,d,frames=None,only=None):
        """Generate one or more night products without loading the archive into RAM.

        ``only`` may be one of: timelapse, keogram, startrail_clean, startrail_full, startrail_video.
        When omitted the enabled automatic products are generated, preserving the
        pre-Beta-2.5 behaviour for scheduled processing.
        """
        d=Path(d); frames=list(frames or self._frames(d))
        if len(frames)<2: return False
        if not self.process_lock.acquire(blocking=False):
            self.status['last_error']='Processing is already running'
            return False
        cfg=self.config.get('processing',{}); products=self._product_dir(d)
        valid={'timelapse','keogram','startrail','startrail_clean','startrail_full','startrail_video'}
        only=str(only or '').strip().lower() or None
        if only and only not in valid:
            self.process_lock.release(); raise ValueError(f'Unknown processing job: {only}')
        want_timelapse=(only=='timelapse') if only else bool(cfg.get('timelapse_enabled',True))
        want_keogram=(only=='keogram') if only else bool(cfg.get('keogram_enabled',True))
        want_clean=(only in {'startrail','startrail_clean'}) if only else bool(cfg.get('startrails_enabled',True))
        want_full=(only=='startrail_full') if only else bool(cfg.get('startrails_enabled',True))
        want_trail_video=(only=='startrail_video') if only else bool(cfg.get('startrail_video_enabled',True))
        want_startrail=want_clean or want_full
        trail_frames=products/'.startrail_frames'
        shutil.rmtree(trail_frames,ignore_errors=True)
        if want_trail_video: trail_frames.mkdir(parents=True,exist_ok=True)
        label={'timelapse':'Generating timelapse','keogram':'Generating keogram','startrail':'Generating clean startrail','startrail_clean':'Generating clean startrail','startrail_full':'Generating full startrail','startrail_video':'Generating clean startrail video'}.get(only,'Preparing night products')
        self.status.update(running=True,current_job=str(d),job_label=label,last_error='',progress_percent=0,processed_frames=0,total_frames=len(frames),memory_safe=True)
        try:
            avail=self._available_memory_mb(); minimum=int(cfg.get('minimum_free_memory_mb',384))
            if avail is not None and avail<minimum:
                raise RuntimeError(f'Processing postponed: only {avail} MB RAM available (minimum {minimum} MB)')

            # Beta 2.5: allow two OpenCV worker threads by default.  This is a
            # useful middle ground on Pi 4: substantially faster than Beta 2.4,
            # while still leaving CPU time for capture, GPIO and the WebUI.
            try: cv2.setNumThreads(max(1,min(2,int(cfg.get('image_threads',2)))))
            except Exception: pass

            # Timelapse does not need a full-resolution Python decode pass.
            if want_timelapse:
                fps=max(1,int(cfg.get('timelapse_fps',cfg.get('video_fps',25))))
                self.status.update(current_job=f'{d} · timelapse',job_label='Generating timelapse',progress_percent=0,processed_frames=0,total_frames=len(frames))
                self._ffmpeg_frames(frames,products/'timelapse.mp4',fps,str(cfg.get('timelapse_resolution',cfg.get('startrail_video_resolution','1080p'))))

            # Startrail/keogram use one streaming decode pass.  If only one was
            # requested, the other allocation/work is completely skipped.
            if want_keogram or want_startrail or want_trail_video:
                first=cv2.imread(str(frames[0]),cv2.IMREAD_COLOR)
                if first is None: raise RuntimeError('First archive frame cannot be read')
                h,w=first.shape[:2]
                clean_stack=np.zeros((h,w,3),dtype=np.uint8) if (want_clean or want_trail_video) else None
                full_stack=np.zeros((h,w,3),dtype=np.uint8) if want_full else None
                clean_accepted=0; clean_rejected=0
                sample_width=max(1,min(31,int(cfg.get('keogram_sample_width',9))))
                if sample_width%2==0: sample_width+=1
                keogram=np.empty((h,len(frames),3),dtype=np.uint8) if want_keogram else None
                video_res=str(cfg.get('startrail_video_resolution','1080p'))
                trail_w,trail_h=self._fit_size(w,h,video_res)
                stride=max(1,len(frames)//300)
                if only:
                    self.status['job_label']=label
                else:
                    names=[]
                    if want_clean: names.append('clean startrail')
                    if want_full: names.append('full startrail')
                    if want_keogram: names.append('keogram')
                    if want_trail_video: names.append('startrail video')
                    self.status['job_label']='Generating '+ ' / '.join(names)
                self.status.update(progress_percent=0,processed_frames=0,total_frames=len(frames))

                for i,pth in enumerate(frames):
                    if self.stop_event.is_set(): raise RuntimeError('Processing stopped')
                    img=cv2.imread(str(pth),cv2.IMREAD_COLOR)
                    if img is None: continue
                    if img.shape[:2]!=(h,w): img=cv2.resize(img,(w,h),interpolation=cv2.INTER_AREA)
                    # Full startrail is documentary: every valid frame contributes.
                    if full_stack is not None: np.maximum(full_stack,img,out=full_stack)
                    # Clean startrail rejects only globally blown-out frames. A bright
                    # meteor occupies too little area to trip these conservative gates.
                    clean_ok=True
                    if clean_stack is not None:
                        sample=img
                        if max(h,w)>900:
                            scale=900.0/max(h,w); sample=cv2.resize(img,(max(2,int(w*scale)),max(2,int(h*scale))),interpolation=cv2.INTER_AREA)
                        gray=cv2.cvtColor(sample,cv2.COLOR_BGR2GRAY)
                        saturated=float(np.count_nonzero(gray>=248))/float(gray.size)
                        median=float(np.median(gray))
                        mean=float(np.mean(gray))
                        sat_limit=float(cfg.get('clean_startrail_saturated_fraction',0.16))
                        median_limit=float(cfg.get('clean_startrail_median_limit',175))
                        mean_limit=float(cfg.get('clean_startrail_mean_limit',190))
                        clean_ok=(saturated < sat_limit and median < median_limit and mean < mean_limit)
                        if clean_ok:
                            np.maximum(clean_stack,img,out=clean_stack); clean_accepted+=1
                        else:
                            clean_rejected+=1
                    if keogram is not None:
                        # Sample a true diameter through the fisheye. Rotation is
                        # configurable so roofs/mounts do not have to occupy the
                        # upper part of every keogram. No whole-frame rotation is
                        # performed, avoiding interpolation blocks/edge artefacts.
                        angle=float(cfg.get('keogram_rotation_deg',90))
                        center_x=float(cfg.get('keogram_center_x_percent',50.0))
                        center_y=float(cfg.get('keogram_center_y_percent',50.0))
                        keogram[:,i,:]=self._keogram_column(img,angle,sample_width,center_x,center_y)
                    if want_trail_video and clean_ok and i%stride==0 and clean_stack is not None:
                        out_frame=clean_stack if (trail_w,trail_h)==(w,h) else cv2.resize(clean_stack,(trail_w,trail_h),interpolation=cv2.INTER_AREA)
                        cv2.imwrite(str(trail_frames/f'{i//stride:06d}.jpg'),out_frame,[cv2.IMWRITE_JPEG_QUALITY,90])
                        if out_frame is not clean_stack: del out_frame
                    del img
                    self.status.update(processed_frames=i+1,progress_percent=round((i+1)*100/len(frames),1))
                    if i%50==0: gc.collect()
                    # Beta 2.4 deliberately slept >=60 ms/frame.  2.5 defaults
                    # to 20 ms, still yielding regularly but cutting long jobs.
                    pause_ms=max(0,int(cfg.get('frame_pause_ms',20)))
                    if pause_ms: time.sleep(pause_ms/1000.0)

                if want_clean and clean_stack is not None and clean_accepted:
                    cv2.imwrite(str(products/'startrail_clean.jpg'),clean_stack,[cv2.IMWRITE_JPEG_QUALITY,95])
                    # Legacy filename intentionally points to the clean result.
                    cv2.imwrite(str(products/'startrail.jpg'),clean_stack,[cv2.IMWRITE_JPEG_QUALITY,95])
                if want_full and full_stack is not None:
                    cv2.imwrite(str(products/'startrail_full.jpg'),full_stack,[cv2.IMWRITE_JPEG_QUALITY,95])
                self.status['clean_startrail']={'accepted':clean_accepted,'rejected':clean_rejected}
                if want_keogram and keogram is not None:
                    keogram=self._annotate_keogram(keogram,frames,1)
                    cv2.imwrite(str(products/'keogram.jpg'),keogram,[cv2.IMWRITE_JPEG_QUALITY,95])
                del first, clean_stack, full_stack, keogram
                gc.collect()

                if want_trail_video:
                    fps=max(1,int(cfg.get('startrail_video_fps',cfg.get('video_fps',25))))
                    self.status.update(current_job=f'{d} · startrail video',job_label='Generating startrail video',progress_percent=0,processed_frames=0)
                    trail=sorted(trail_frames.glob('*.jpg')); self.status['total_frames']=len(trail)
                    if len(trail)>=2: self._ffmpeg_frames(trail,products/'startrail.mp4',fps,video_res)

            shutil.rmtree(trail_frames,ignore_errors=True)
            self.status.update(running=False,current_job=None,job_label='Finished',progress_percent=100)
            return True
        except Exception as exc:
            self.status.update(running=False,current_job=None,job_label=None,last_error=str(exc)); self.logger.exception('Product generation failed for %s',d)
            return False
        finally:
            shutil.rmtree(trail_frames,ignore_errors=True)
            gc.collect(); self.process_lock.release()

    @staticmethod
    def _frame_time(path):
        side=Path(path).with_suffix('.json')
        try:
            raw=json.loads(side.read_text()).get('captured_at')
            if raw: return raw
        except Exception:
            pass
        try: return time.strftime('%Y-%m-%dT%H:%M:%S',time.localtime(Path(path).stat().st_mtime))
        except Exception: return ''

    def _annotate_keogram(self,keogram,frames,strip):
        """Add a readable time axis without retaining any source frames."""
        if keogram is None or not frames: return keogram
        h,w=keogram.shape[:2]; margin=64
        canvas=np.zeros((h+margin,w,3),dtype=np.uint8); canvas[:h]=keogram
        count=min(6,len(frames)); indexes=sorted(set(int(round(i*(len(frames)-1)/max(1,count-1))) for i in range(count)))
        font=cv2.FONT_HERSHEY_SIMPLEX
        for idx in indexes:
            raw=self._frame_time(frames[idx])
            try: label=raw[11:16] if 'T' in raw else raw[-8:-3]
            except Exception: label=''
            x=min(w-1,max(0,idx*strip));
            cv2.line(canvas,(x,h),(x,h+10),(150,150,150),1,cv2.LINE_AA)
            (tw,th),_=cv2.getTextSize(label,font,.55,1)
            tx=max(2,min(w-tw-2,x-tw//2))
            cv2.putText(canvas,label,(tx,h+38),font,.55,(235,235,235),1,cv2.LINE_AA)
        return canvas

    def _ffmpeg_frames(self,frames,out,fps,resolution):
        if len(frames)<2: return
        out=Path(out); out.parent.mkdir(parents=True,exist_ok=True)
        max_w='2560' if str(resolution).lower()=='2k' else '1920'
        fd,listing=tempfile.mkstemp(prefix='vigilis-frames-',suffix='.txt')
        try:
            with os.fdopen(fd,'w') as f:
                for p in frames:
                    # concat demuxer handles JPG/PNG together and preserves our sorted order.
                    safe=str(Path(p).resolve()).replace("'","'\\''")
                    f.write(f"file '{safe}'\n")
                    f.write(f"duration {1.0/fps:.8f}\n")
                safe=str(Path(frames[-1]).resolve()).replace("'","'\\''")
                f.write(f"file '{safe}'\n")
            pcfg=self.config.get('processing',{})
            codec=str(pcfg.get('video_codec','libx264'))
            threads=max(1,min(4,int(pcfg.get('video_threads',2))))
            nice=max(0,min(19,int(pcfg.get('process_nice',5))))
            cmd=['nice','-n',str(nice)]
            if shutil.which('taskset') and bool(pcfg.get('pin_video_cpus',True)):
                # Two cores by default: faster than Beta 2.4 but leaves half the Pi 4 free.
                cmd += ['taskset','-c',str(pcfg.get('video_cpu_cores','2,3'))]
            cmd += ['ffmpeg','-y','-loglevel','error','-nostats','-progress','pipe:1','-threads',str(threads),
                 '-filter_threads',str(max(1,min(2,threads))),'-f','concat','-safe','0','-i',listing,
                 '-vf',f'scale={max_w}:-2:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2',
                 '-r',str(fps),'-c:v',codec,'-threads',str(threads)]
            if codec=='libx265':
                cmd += ['-preset',str(pcfg.get('video_preset','fast')),'-x265-params',f'pools={threads}:frame-threads={threads}','-tag:v','hvc1']
            elif codec in {'hevc','hevc_v4l2m2m'}:
                cmd += ['-tag:v','hvc1']
            elif codec=='libx264':
                # H.264 + yuv420p + faststart is broadly playable inline in
                # Safari/iOS, Chrome, Edge and Firefox.
                cmd += ['-preset',str(pcfg.get('video_preset','fast')),'-profile:v','high','-level','4.1']
            cmd += ['-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
            total=max(1,len(frames))
            try:
                for line in proc.stdout:
                    if line.startswith('frame='):
                        try:
                            done=min(total,max(0,int(line.split('=',1)[1].strip())))
                            self.status.update(processed_frames=done,total_frames=total,progress_percent=round(done*100/total,1))
                        except Exception: pass
                err=proc.stderr.read() if proc.stderr else ''
                rc=proc.wait(timeout=14400)
                if rc!=0: raise RuntimeError(err.strip() or f'ffmpeg exited with code {rc}')
            finally:
                if proc.poll() is None: proc.kill()
        finally:
            try: os.unlink(listing)
            except OSError: pass
