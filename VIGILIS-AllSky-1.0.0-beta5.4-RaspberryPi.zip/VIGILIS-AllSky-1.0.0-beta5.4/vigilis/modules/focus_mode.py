from __future__ import annotations
import threading
import time
import cv2
import numpy as np


class FocusModeService:
    """Temporary live-focus session with exclusive control of the camera."""
    def __init__(self, config, camera, capture, exposure, logger):
        self.config=config; self.camera=camera; self.capture=capture; self.exposure=exposure; self.logger=logger
        self.lock=threading.RLock(); self.active=False; self.last_heartbeat=0.0; self.started_at=0.0
        self.timeout_seconds=int(config.get('focus',{}).get('timeout_seconds',600))
        self.saved={}; self.focus_exposure_ms=1000.0; self.focus_gain=8.0
        self.status={'active':False,'sharpness':0.0,'timeout_seconds':self.timeout_seconds,'remaining_seconds':0,'exposure_ms':1000.0,'gain':8.0,'last_error':''}
        threading.Thread(target=self._watchdog,daemon=True,name='focus-watchdog').start()

    def start(self, exposure_ms=1000.0, gain=None):
        with self.lock:
            if self.active:
                self.heartbeat(); return self.status
            cam=self.config.setdefault('camera',{})
            self.saved={k:cam.get(k) for k in ('fps','exposure_us','zwo_exposure_us','gain','zwo_gain')}
            self.focus_exposure_ms=max(100.0,min(10000.0,float(exposure_ms)))
            self.focus_gain=float(gain if gain is not None else cam.get('gain',8.0))
            self.capture.pause(); self.active=True; self.started_at=self.last_heartbeat=time.monotonic()
            cam['fps']=max(0.1,min(2.0,1000.0/self.focus_exposure_ms))
            self.camera.apply_capture_controls(self.focus_exposure_ms/1000.0,self.focus_gain)
            self.status.update(active=True,exposure_ms=self.focus_exposure_ms,gain=self.focus_gain,last_error='')
            return dict(self.status)

    def update(self, exposure_ms=None, gain=None):
        with self.lock:
            if not self.active: raise RuntimeError('Fokusmodus ist nicht aktiv')
            if exposure_ms is not None: self.focus_exposure_ms=max(100.0,min(10000.0,float(exposure_ms)))
            if gain is not None: self.focus_gain=max(0.0,float(gain))
            self.config['camera']['fps']=max(0.1,min(2.0,1000.0/self.focus_exposure_ms))
            self.camera.apply_capture_controls(self.focus_exposure_ms/1000.0,self.focus_gain)
            self.heartbeat(); self.status.update(exposure_ms=self.focus_exposure_ms,gain=self.focus_gain)
            return dict(self.status)

    def heartbeat(self):
        self.last_heartbeat=time.monotonic()

    def stop(self, reason='user'):
        with self.lock:
            if not self.active: return dict(self.status)
            self.active=False
            cam=self.config.setdefault('camera',{})
            for k,v in self.saved.items():
                if v is not None: cam[k]=v
            try:
                gain=float(cam.get('gain',8.0)); exp=float(self.exposure.current if self.exposure else cam.get('exposure_us',1000000)/1e6)
                self.camera.apply_capture_controls(exp,gain)
            except Exception as exc:
                self.logger.exception('Fokusmodus konnte Kameraeinstellungen nicht wiederherstellen')
                self.status['last_error']=str(exc)
            self.capture.resume(); self.status.update(active=False,remaining_seconds=0)
            self.logger.info('Fokusmodus beendet: %s',reason)
            return dict(self.status)

    def frame_jpeg(self,height=720,zoom=1.0,crosshair=False):
        if not self.active: return None
        self.heartbeat(); frame,_=self.camera.get_frame()
        if frame is None: return None
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        self.status['sharpness']=round(float(cv2.Laplacian(gray,cv2.CV_64F).var()),1)
        zoom=max(1.0,min(4.0,float(zoom)))
        if zoom>1.0:
            h,w=frame.shape[:2]; nw,nh=int(w/zoom),int(h/zoom); x=(w-nw)//2; y=(h-nh)//2
            frame=cv2.resize(frame[y:y+nh,x:x+nw],(w,h),interpolation=cv2.INTER_LINEAR)
        if crosshair:
            h,w=frame.shape[:2]; cv2.line(frame,(w//2,0),(w//2,h),(255,255,255),1); cv2.line(frame,(0,h//2),(w,h//2),(255,255,255),1)
        if height and frame.shape[0]!=height:
            w=int(frame.shape[1]*(height/frame.shape[0])); frame=cv2.resize(frame,(w,height),interpolation=cv2.INTER_AREA)
        ok,b=cv2.imencode('.jpg',frame,[int(cv2.IMWRITE_JPEG_QUALITY),85]); return b.tobytes() if ok else None

    def snapshot(self):
        remaining=max(0,int(self.timeout_seconds-(time.monotonic()-self.last_heartbeat))) if self.active else 0
        self.status.update(active=self.active,remaining_seconds=remaining,timeout_seconds=self.timeout_seconds)
        return dict(self.status)

    def _watchdog(self):
        while True:
            time.sleep(1)
            if self.active and time.monotonic()-self.last_heartbeat>self.timeout_seconds:
                self.stop('timeout')
