from __future__ import annotations

import threading
import time
from collections import deque

import cv2
import numpy as np


class CameraManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.lock = threading.Lock()
        self.frame_condition = threading.Condition(self.lock)
        self.frame = None
        self.frame_metadata = {}
        self.seq = 0
        self.status = {
            'running': False,
            'camera_ok': False,
            'fps': 0.0,
            'frames': 0,
            'dropped': 0,
            'last_error': '',
            'backend': 'none',
            'last_frame_at': None,
            'pixel_format': '',
            'profile': '',
            'tuning_profile': 'standard',
            'tuning_file': '',
            'target_fps': None,
            'exposure_mode': '',
            'camera_name': '',
            'camera_temperature_c': None,
            'exposure_us': None,
            'analogue_gain': None,
            'frame_duration_us': None,
            'lux': None,
            'preset': '',
            'image_enhancement': 'natural',
            'vision_engine': 'off',
            'vision_gamma': 1.0,
            'vision_low': 0.0,
            'vision_high': 255.0,
            'vision_mean': 0.0,
            'vision_median': 0.0,
            'vision_clipped_percent': 0.0,
            'vision_tnr': 'off',
            'vision_bright_points': 0,
            'vision_background': 0.0,
        }
        self.stop_event = threading.Event()
        self.thread = None
        self.picam = None
        self.cap = None
        self.zwo = None
        self._tnr_accumulator = None
        self._tnr_prev_gray = None
        self.runtime_target_fps = None

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, daemon=True, name='camera-manager')
        self.thread.start()

    def _camera_controls(self, cam, sensor_name=''):
        """Build controls from the selected observatory preset.

        Presets keep the everyday UI simple. Expert mode exposes the manual
        exposure and analogue gain values. Automatic presets leave AEC/AGC to
        libcamera and only constrain the frame duration through the target FPS.
        """
        preset = str(cam.get('preset', 'allsky_night')).lower()
        preset_defaults = {
            'allsky_night': {'fps': 0.2, 'profile': 'manual'},
            'allsky_twilight': {'fps': 1.0, 'profile': 'manual'},
            'allsky_day': {'fps': 5.0, 'profile': 'automatic'},
            'expert': {'fps': float(cam.get('fps', 0.2)), 'profile': 'manual'},
        }
        defaults = preset_defaults.get(preset, preset_defaults['allsky_night'])
        target_fps = max(0.01, float(cam.get('fps', defaults['fps'])))
        # Presets are authoritative. This also migrates older installations
        # that may still have profile: manual saved from alpha12.
        profile = defaults['profile']

        frame_us = max(1000, int(round(1_000_000 / target_fps)))
        wb_mode=str(cam.get('white_balance_mode','auto')).lower()
        uv_ir_filter = bool(cam.get('uv_ir_filter', True))
        # A colour camera without an IR-cut filter cannot be corrected reliably
        # by libcamera AWB alone: the CFA channels all receive additional NIR.
        # For the simple UI, 'Auto' therefore means normal AWB when an IR-cut
        # filter is installed, and a sensor-aware No-IR preset when it is not.
        if wb_mode == 'custom':
            awb = False
            red_gain = max(0.1, float(cam.get('white_balance_red_gain', 1.0)))
            blue_gain = max(0.1, float(cam.get('white_balance_blue_gain', 1.0)))
            effective_wb = 'custom'
        elif not uv_ir_filter:
            awb = False
            sensor = str(sensor_name or '').lower()
            # Conservative defaults for full-spectrum Raspberry colour sensors.
            # Lowering red and blue relative to green removes the strong magenta
            # cast while leaving Custom WB available for exact user tuning.
            presets = {
                'imx477': (0.58, 0.76),
                'imx462': (0.52, 0.72),
                'imx219': (0.62, 0.82),
            }
            red_gain, blue_gain = next((v for k,v in presets.items() if k in sensor), (0.60, 0.80))
            effective_wb = 'no_ir_cut_auto'
        else:
            awb = bool(cam.get('awb_enabled', True))
            red_gain = max(0.1, float(cam.get('white_balance_red_gain', 1.0)))
            blue_gain = max(0.1, float(cam.get('white_balance_blue_gain', 1.0)))
            effective_wb = 'auto' if awb else 'custom'
        controls = {'AwbEnable': awb, 'FrameDurationLimits': (frame_us, frame_us)}
        if not awb:
            controls['ColourGains']=(red_gain, blue_gain)
        self._effective_white_balance = {'mode': effective_wb, 'red_gain': red_gain, 'blue_gain': blue_gain, 'awb': awb}

        if profile == 'manual':
            exposure_us = max(100, int(cam.get('exposure_us', frame_us)))
            frame_us = max(frame_us, exposure_us)
            controls['FrameDurationLimits'] = (frame_us, frame_us)
            controls.update({
                'AeEnable': False,
                'ExposureTime': exposure_us,
                'AnalogueGain': max(1.0, min(31.62, float(cam.get('gain', 8.0)))),
            })
            exposure_mode = 'manual'
        else:
            controls['AeEnable'] = True
            controls['ExposureValue'] = float(cam.get('exposure_compensation', 0.0))
            exposure_mode = 'auto'

        return controls, profile, preset, target_fps, exposure_mode

    def _open(self):
        cam = self.config['camera']
        mode = cam.get('mode', 'auto')
        if mode == 'zwo':
            try:
                from .zwo_camera import ZwoCameraBackend
                z = ZwoCameraBackend(cam, self.logger)
                info = z.open()
                self.zwo = z
                self.status.update(camera_ok=True, backend='zwoasi', pixel_format=info.get('pixel_format','RAW8'), profile='zwo', preset=str(cam.get('preset','allsky_night')), target_fps=float(cam.get('fps',0.2)), last_error='', camera_name=info.get('name','ZWO ASI'), exposure_mode='auto' if info.get('auto_exposure') else 'manual', exposure_us=int(cam.get('zwo_exposure_us',20000)), analogue_gain=int(cam.get('zwo_gain',100)), frame_duration_us=None)
                self.logger.info('ZWO camera opened: %s', info)
                return True
            except Exception as exc:
                self.status['last_error'] = f'ZWO camera unavailable: {exc}'
                self.logger.warning(self.status['last_error'])
                return False
        if mode in ('auto', 'csi'):
            try:
                from pathlib import Path
                from picamera2 import Picamera2

                # Discover the actual CSI sensor before selecting a tuning file.
                # Beta 1.6 incorrectly hard-coded IMX462 tuning for every CSI camera.
                infos = list(Picamera2.global_camera_info() or [])
                selected_index = max(0, int(cam.get('device', 0)))
                info = infos[selected_index] if selected_index < len(infos) else (infos[0] if infos else {})
                sensor_name = str(info.get('Model') or info.get('model') or info.get('Id') or info.get('id') or '').strip()
                sensor_key = sensor_name.lower().replace(' ', '_')
                tuning_name = str(cam.get('tuning_profile', 'standard')).lower()
                tuning_file = ''
                tuning = None
                if tuning_name == 'custom':
                    configured = str(cam.get('custom_tuning_file', '')).strip()
                    candidate = Path(configured).expanduser() if configured else Path(__file__).resolve().parents[2] / 'data' / 'custom_tuning.json'
                    if candidate.exists():
                        tuning_file = str(candidate); tuning = Picamera2.load_tuning_file(tuning_file)
                    else:
                        self.logger.warning('Custom tuning file not found at %s; using system default', candidate); tuning_name='standard'
                elif tuning_name not in ('standard', 'default', ''):
                    # A sensor-specific profile is allowed only when such a file
                    # actually exists. IMX477 therefore uses libcamera defaults
                    # rather than an IMX462 profile.
                    candidate = Path(__file__).resolve().parents[1] / 'tuning' / f'{sensor_key}_{tuning_name}.json'
                    if sensor_key and candidate.exists():
                        tuning_file = str(candidate); tuning = Picamera2.load_tuning_file(tuning_file)
                    else:
                        self.logger.info('No %s tuning profile for %s; using libcamera system default', tuning_name, sensor_name or 'CSI camera')
                        tuning_name = 'standard'

                p = Picamera2(camera_num=selected_index, tuning=tuning) if tuning is not None else Picamera2(camera_num=selected_index)
                pixel_format = str(cam.get('pixel_format', 'RGB888')).upper()
                if pixel_format == 'BGR888':
                    pixel_format = 'RGB888'

                controls, profile, preset, target_fps, exposure_mode = self._camera_controls(cam, sensor_name)
                requested=(int(cam.get('width',1920)),int(cam.get('height',1080)))
                modes=list(getattr(p,'sensor_modes',[]) or [])
                sizes=[tuple(m.get('size',(0,0))) for m in modes if m.get('size')]
                max_sensor=max(sizes,key=lambda x:x[0]*x[1]) if sizes else requested
                binning=2 if int(cam.get('sensor_binning',1))==2 else 1
                if bool(cam.get('auto_max_resolution',True)):
                    requested=(max(2,max_sensor[0]//binning),max(2,max_sensor[1]//binning))
                    requested=(requested[0]-(requested[0]%2),requested[1]-(requested[1]%2))
                    cam['width'],cam['height']=requested
                cam['max_sensor_width'],cam['max_sensor_height']=max_sensor
                # Keep multiple requests queued.  Picamera2's still configuration
                # otherwise tends to use a very shallow buffer queue, which is fine
                # for one-shot photography but can create a capture/release bubble
                # between long exposures.  Three buffers let libcamera start the next
                # sensor request immediately while VIGILIS copies/publishes the last one.
                cfg = p.create_still_configuration(
                    main={'size': requested, 'format': pixel_format},
                    controls=controls,
                    buffer_count=3,
                )
                p.configure(cfg)
                self.picam = p
                # Use the completed-request callback as the single source of CSI
                # frames.  This removes the capture_array() consumer loop entirely,
                # so a 30 s exposure is published once per completed libcamera request
                # instead of potentially waiting through another request cycle.
                p.post_callback = self._on_picamera_request
                p.start()
                self.status.update(
                    backend='picamera2',
                    pixel_format=pixel_format,
                    profile=profile,
                    preset=preset,
                    image_enhancement=str(cam.get('image_enhancement', 'enhanced')),
                    tuning_profile=tuning_name,
                    tuning_file=tuning_file,
                    target_fps=target_fps,
                    exposure_mode=exposure_mode,
                    exposure_us=controls.get('ExposureTime'),
                    analogue_gain=controls.get('AnalogueGain'),
                    frame_duration_us=controls.get('FrameDurationLimits', (None, None))[0],
                    resolution={'width':requested[0],'height':requested[1]},
                    max_sensor_resolution={'width':max_sensor[0],'height':max_sensor[1]},
                    sensor_binning=binning,
                    uv_ir_filter=bool(cam.get('uv_ir_filter',True)),
                    white_balance_mode=getattr(self, '_effective_white_balance', {}).get('mode', str(cam.get('white_balance_mode','auto'))),
                    white_balance_red_gain=getattr(self, '_effective_white_balance', {}).get('red_gain'),
                    white_balance_blue_gain=getattr(self, '_effective_white_balance', {}).get('blue_gain'),
                    camera_name=sensor_name or 'CSI Camera',
                )
                self.logger.info(
                    'Camera opened: preset=%s profile=%s tuning=%s target_fps=%s controls=%s',
                    preset,
                    profile,
                    tuning_name,
                    target_fps,
                    controls,
                )
                return True
            except Exception as exc:
                self.logger.warning('Picamera2 unavailable: %s', exc)
                self.status['last_error'] = str(exc)
                if mode == 'csi':
                    return False

        source = cam.get('source') if mode == 'rtsp' else int(cam.get('device', 0))
        if mode == 'auto' and cam.get('source'):
            source = cam.get('source')
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG if isinstance(source, str) else cv2.CAP_ANY)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(cam['width']))
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(cam['height']))
        cap.set(cv2.CAP_PROP_FPS, float(cam.get('fps', 10)))
        if not cap.isOpened():
            self.status['last_error'] = f'cannot open camera: {source}'
            cap.release()
            return False
        self.cap = cap
        self.status.update(
            backend='opencv',
            pixel_format='BGR',
            profile=str(cam.get('profile', 'automatic')),
            preset=str(cam.get('preset', 'allsky_night')),
            image_enhancement=str(cam.get('image_enhancement', 'enhanced')),
            target_fps=float(cam.get('fps', 10)),
        )
        return True

    def _on_picamera_request(self, request):
        """Publish each completed Picamera2 request exactly once.

        The callback runs in Picamera2's request-completion path.  We make our
        own numpy copy immediately so the libcamera buffer can be recycled as
        soon as the callback returns.  Metadata therefore belongs atomically to
        the same exposure as the image.
        """
        if self.stop_event.is_set() or self.picam is None:
            return
        try:
            frame = request.make_array('main').copy()
            metadata = dict(request.get_metadata() or {})
            frame = self._transform(frame)
        except Exception as exc:
            self.status['last_error'] = f'Picamera2 request callback: {exc}'
            self.logger.exception('Picamera2 request callback failed')
            return

        now = time.time()
        with self.frame_condition:
            self.frame = frame
            self.frame_metadata = metadata
            self.seq += 1
            seq = self.seq
            self.frame_condition.notify_all()

        # Metadata is taken from the exact completed request instead of a later
        # capture_metadata() call.  This also fixes overlay/sidecar exposure and
        # gain races during auto-exposure changes.
        exposure = metadata.get('ExposureTime')
        gain = metadata.get('AnalogueGain')
        duration = metadata.get('FrameDuration')
        lux = metadata.get('Lux')
        self.status.update(
            running=True,
            camera_ok=True,
            frames=self.status['frames'] + 1,
            last_frame_at=now,
            last_error='',
            exposure_us=exposure if exposure is not None else self.status.get('exposure_us'),
            analogue_gain=round(float(gain), 3) if gain is not None else self.status.get('analogue_gain'),
            frame_duration_us=duration if duration is not None else self.status.get('frame_duration_us'),
            lux=round(float(lux), 3) if lux is not None else self.status.get('lux'),
        )
        # Callback cadence is the real CSI cadence.  Keep a small private history
        # rather than relying on the polling thread timing.
        hist = getattr(self, '_callback_times', None)
        if hist is None:
            hist = self._callback_times = deque(maxlen=60)
        hist.append(now)
        if len(hist) > 1 and hist[-1] > hist[0]:
            self.status['fps'] = round((len(hist)-1)/(hist[-1]-hist[0]), 3)
        self.status['last_request_sequence'] = seq

    def _close(self):
        try:
            if self.picam:
                self.picam.stop()
                self.picam.close()
        except Exception:
            pass
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        self.picam = None
        self.cap = None
        if self.zwo is not None:
            try:
                self.zwo.close()
            except Exception:
                pass
        self.zwo = None

    def _read(self):
        if self.zwo is not None:
            return self.zwo.read()
        if self.picam is not None:
            # This byte order is already correct for the OpenCV JPEG/video path
            # on the tested Raspberry Pi IMX462 pipeline. Do not swap channels.
            return True, self.picam.capture_array()
        if self.cap is not None:
            return self.cap.read()
        return False, None

    def _transform(self, frame):
        cam = self.config['camera']
        r = int(cam.get('rotate', 0))
        if r == 90:
            frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
        elif r == 180:
            frame = cv2.rotate(frame, cv2.ROTATE_180)
        elif r == 270:
            frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
        if cam.get('flip_horizontal'):
            frame = cv2.flip(frame, 1)
        if cam.get('flip_vertical'):
            frame = cv2.flip(frame, 0)
        return frame

    def _vision_settings(self):
        cam = self.config.get('camera', {})
        mode = str(cam.get('vision_mode', 'balanced')).lower().strip()
        if mode not in {'off', 'balanced', 'deep', 'custom'}:
            mode = 'balanced'
        presets = {
            'off': dict(target=18.0, max_gain=1.0, gamma=1.0, tnr='off', sharpen=0.0),
            'balanced': dict(target=34.0, max_gain=1.8, gamma=0.72, tnr='off', sharpen=0.05),
            'deep': dict(target=46.0, max_gain=2.5, gamma=0.60, tnr='low', sharpen=0.07),
        }
        params = presets.get(mode, presets['balanced']).copy()
        if mode == 'custom':
            params.update({
                'target': float(cam.get('vision_target_median', 38.0)),
                'max_gain': float(cam.get('vision_max_gain', 2.2)),
                'gamma': float(cam.get('vision_gamma_min', 0.68)),
                'tnr': str(cam.get('vision_tnr', 'off')).lower(),
                'sharpen': float(cam.get('vision_sharpen', 0.05)),
            })
        override_tnr = str(cam.get('vision_tnr', 'auto')).lower()
        if override_tnr != 'auto':
            params['tnr'] = override_tnr
        return mode, params

    @staticmethod
    def _luminance(frame):
        f = frame.astype(np.float32)
        return (0.114 * f[:, :, 0] + 0.587 * f[:, :, 1] + 0.299 * f[:, :, 2]).astype(np.uint8)

    def _temporal_denoise(self, frame, gray, level):
        # TNR is optional and intentionally conservative. It is disabled in the
        # default Balanced profile to preserve the requested camera frame rate.
        if level not in {'low', 'medium', 'high'}:
            self._tnr_accumulator = None
            return frame
        if self._tnr_accumulator is None or self._tnr_accumulator.shape != frame.shape:
            self._tnr_accumulator = frame.astype(np.float32)
            return frame
        weight = {'low': 0.80, 'medium': 0.65, 'high': 0.50}[level]
        # Build the motion mask from a tiny image, then scale it back. This is
        # much cheaper than full-resolution temporal analysis.
        small_now = cv2.resize(gray, (160, 90), interpolation=cv2.INTER_AREA)
        previous = cv2.convertScaleAbs(self._tnr_accumulator)
        small_prev = cv2.resize(self._luminance(previous), (160, 90), interpolation=cv2.INTER_AREA)
        mask = cv2.threshold(cv2.absdiff(small_now, small_prev), 10, 255, cv2.THRESH_BINARY)[1]
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
        mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST)
        cv2.accumulateWeighted(frame.astype(np.float32), self._tnr_accumulator, weight)
        filtered = cv2.convertScaleAbs(self._tnr_accumulator)
        filtered[mask > 0] = frame[mask > 0]
        return filtered

    def _enhance(self, frame):
        """VIGILIS Vision Engine 1.1 — lightweight night processing.

        No full-resolution histogram, percentile scan or CLAHE is performed.
        A 64x36 luminance sample supplies background, mean and bright-point
        statistics. A single scale and LUT are then applied to the frame.
        """
        mode, p = self._vision_settings()
        raw_gray = self._luminance(frame)
        sample = cv2.resize(raw_gray, (64, 36), interpolation=cv2.INTER_AREA)
        mean = float(sample.mean())
        median = float(np.median(sample))
        background = float(np.percentile(sample, 35))
        bright_points = int(np.count_nonzero(sample >= max(40, background + 18)))

        processed = self._temporal_denoise(frame, raw_gray, p['tnr'])
        scale = 1.0
        gamma = 1.0
        if mode != 'off':
            # Smooth global luminance gain; protects highlights and costs only
            # one optimized OpenCV operation per frame.
            scale = min(float(p['max_gain']), max(1.0, float(p['target']) / max(median, 1.0)))
            if scale > 1.01:
                processed = cv2.convertScaleAbs(processed, alpha=scale, beta=0)
            gamma = max(0.35, min(1.0, float(p['gamma'])))
            if gamma < 0.995:
                lut = np.array([((i / 255.0) ** gamma) * 255 for i in range(256)], dtype=np.uint8)
                processed = cv2.LUT(processed, lut)
            if p['sharpen'] > 0:
                blurred = cv2.GaussianBlur(processed, (0, 0), 0.8)
                processed = cv2.addWeighted(processed, 1.0 + p['sharpen'], blurred, -p['sharpen'], 0)

        self.status.update(
            vision_engine='Vision Engine 1.1',
            image_enhancement=mode,
            vision_gamma=round(gamma, 3),
            vision_mean=round(mean, 2),
            vision_median=round(median, 2),
            vision_background=round(background, 2),
            vision_bright_points=bright_points,
            vision_tnr=p['tnr'],
        )
        return processed

    def _run(self):
        window = deque(maxlen=60)
        while not self.stop_event.is_set():
            target_fps = max(0.01, float(self.runtime_target_fps if self.runtime_target_fps is not None else self.config['camera'].get('fps', 0.2)))
            period = 1.0 / target_fps
            if not (self.picam or self.cap or self.zwo):
                if not self._open():
                    time.sleep(float(self.config['camera'].get('reconnect_seconds', 3)))
                    continue
            # CSI frames arrive via _on_picamera_request().  Do not call
            # capture_array() here as a second consumer; that was the source of
            # the long-exposure cadence ambiguity.  The manager thread merely
            # supervises the open camera while libcamera drives the request queue.
            if self.picam is not None:
                time.sleep(0.25)
                continue

            started = time.time()
            try:
                ok, frame = self._read()
            except Exception as exc:
                ok, frame = False, None
                self.status['last_error'] = str(exc)
            if not ok or frame is None:
                self.status.update(camera_ok=False, running=False)
                self.status['dropped'] += 1
                self._close()
                time.sleep(1)
                continue
            # Publish a completed camera exposure immediately.  Full-resolution
            # Vision Engine processing is intentionally NOT done in this camera
            # acquisition thread: on a Raspberry Pi 4 it can take a substantial
            # fraction of a 12 MP frame period and used to turn a 30 s exposure
            # into ~60-65 s between published sequence IDs.
            #
            # Archive processing is performed by process_for_archive() in the
            # AllSky capture worker while the camera thread is already exposing
            # the next frame.  This keeps sequence cadence tied to the sensor.
            frame = self._transform(frame)
            with self.frame_condition:
                self.frame = frame
                self.seq += 1
                self.frame_condition.notify_all()
            now = time.time()
            window.append(now)
            fps = (len(window) - 1) / (window[-1] - window[0]) if len(window) > 1 and window[-1] > window[0] else 0
            self.status.update(
                running=True,
                camera_ok=True,
                fps=round(fps, 2),
                frames=self.status['frames'] + 1,
                last_frame_at=now,
                last_error='',
            )
            if self.picam is not None and self.status['frames'] % 10 == 0:
                try:
                    metadata = self.picam.capture_metadata()
                    if metadata:
                        self.status['exposure_us'] = metadata.get('ExposureTime', self.status.get('exposure_us'))
                        gain = metadata.get('AnalogueGain', self.status.get('analogue_gain'))
                        self.status['analogue_gain'] = round(float(gain), 2) if gain is not None else None
                        self.status['frame_duration_us'] = metadata.get('FrameDuration', self.status.get('frame_duration_us'))
                        lux = metadata.get('Lux')
                        self.status['lux'] = round(float(lux), 3) if lux is not None else None
                except Exception:
                    pass
            elif self.zwo is not None and self.status['frames'] % 10 == 0:
                try:
                    metadata = self.zwo.metadata()
                    self.status.update(metadata)
                    self.status['exposure_us'] = metadata.get('zwo_exposure_us_actual', self.status.get('exposure_us'))
                    self.status['analogue_gain'] = metadata.get('zwo_gain_actual', self.status.get('analogue_gain'))
                except Exception:
                    pass
            # Picamera2 and ZWO reads already block until the next completed
            # exposure/frame. Sleeping for the configured frame period again here
            # effectively doubled long-exposure cadence (e.g. ~30 s exposure
            # becoming ~60+ s between archived frames). Only throttle non-blocking
            # OpenCV/RTSP style sources explicitly.
            if self.picam is None and self.zwo is None:
                sleep = period - (time.time() - started)
                if sleep > 0:
                    time.sleep(sleep)


    def process_for_archive(self, frame):
        """Apply the Vision Engine outside the sensor acquisition thread.

        The camera worker must publish each completed exposure as soon as it is
        available.  Running 12 MP enhancement before seq++ made the capture
        cadence depend on CPU processing time.  The archive worker calls this
        method instead, allowing processing to overlap the next sensor exposure.
        """
        if frame is None:
            return frame
        return self._enhance(frame)


    def apply_white_balance(self) -> dict:
        """Apply the current UV/IR + WB setting immediately without a restart."""
        cam = self.config.setdefault('camera', {})
        sensor_name = str(self.status.get('camera_name') or '')
        # Re-use the same decision logic as camera startup, but only apply WB controls.
        _, _, _, _, _ = self._camera_controls(cam, sensor_name)
        wb = getattr(self, '_effective_white_balance', {})
        controls = {'AwbEnable': bool(wb.get('awb', False))}
        if not controls['AwbEnable']:
            controls['ColourGains'] = (float(wb.get('red_gain', 1.0)), float(wb.get('blue_gain', 1.0)))
        try:
            if self.picam is not None:
                self.picam.set_controls(controls)
            self.status.update(
                uv_ir_filter=bool(cam.get('uv_ir_filter', True)),
                white_balance_mode=str(wb.get('mode', cam.get('white_balance_mode', 'auto'))),
                white_balance_red_gain=wb.get('red_gain'),
                white_balance_blue_gain=wb.get('blue_gain'),
            )
            return {'ok': True, **self.status}
        except Exception as exc:
            self.status['last_error'] = f'white balance update: {exc}'
            return {'ok': False, 'error': str(exc)}

    def _exposure_time_limits_us(self) -> tuple[int, int]:
        """Return the active camera exposure limits in microseconds.

        Picamera2/libcamera exposes the real sensor limits after configuration.
        Daylight calibration must use those limits instead of VIGILIS imposing a
        100 us floor: with a fast lens in direct sun the IMX477 can require a
        substantially shorter exposure.  Fall back conservatively when a backend
        does not publish limits.
        """
        if self.picam is not None:
            try:
                limits = (getattr(self.picam, 'camera_controls', {}) or {}).get('ExposureTime')
                if isinstance(limits, (tuple, list)) and len(limits) >= 2:
                    minimum = max(1, int(limits[0]))
                    maximum = max(minimum, int(limits[1]))
                    return minimum, maximum
            except Exception:
                pass
        return 20, 120_000_000

    def apply_capture_controls(self, exposure_seconds: float, gain: float) -> None:
        """Apply exposure/gain and adapt the camera-manager cadence.

        Short daylight exposures use the sensor's real minimum exposure rather
        than an artificial 100 us floor; long night exposures keep the normal
        exposure-plus-readout cadence.
        """
        requested_us = max(1, int(round(float(exposure_seconds) * 1_000_000)))
        min_us, max_us = self._exposure_time_limits_us()
        exposure_us = max(min_us, min(max_us, requested_us))
        exposure_seconds = exposure_us / 1_000_000.0
        cam = self.config.setdefault('camera', {})
        cam['exposure_us'] = exposure_us
        cam['zwo_exposure_us'] = exposure_us
        cam['gain'] = float(gain)
        cam['zwo_gain'] = int(round(float(gain)))
        # Long-exposure cadence should be exposure + a small sensor/readout
        # margin, not exposure * 1.08.  At 30 s the old rule requested a 32.4 s
        # frame even before the user's delay.  A bounded margin keeps the sensor
        # legal while making 30 s + 1 s land close to a 31-32 s archive cadence.
        margin_s = max(0.02, min(0.50, exposure_seconds * 0.015))
        requested_period_s = max(0.125, exposure_seconds + margin_s)
        self.runtime_target_fps = max(0.02, min(8.0, 1.0 / requested_period_s))
        frame_us = max(exposure_us, int(round(requested_period_s * 1_000_000)))
        try:
            if self.picam is not None:
                self.picam.set_controls({'AeEnable': False, 'ExposureTime': exposure_us, 'AnalogueGain': float(gain), 'FrameDurationLimits': (frame_us, frame_us)})
            elif self.zwo is not None:
                self.zwo.set_exposure_gain(exposure_us, int(round(float(gain))))
            self.status.update(exposure_us=exposure_us, analogue_gain=float(gain), target_fps=round(self.runtime_target_fps,3), frame_duration_us=frame_us)
            return exposure_seconds
        except Exception as exc:
            self.status['last_error'] = f'control update: {exc}'
            raise

    def get_frame(self, copy=True):
        with self.lock:
            return (None, self.seq) if self.frame is None else (self.frame.copy() if copy else self.frame, self.seq)

    def get_frame_with_metadata(self, copy=True):
        with self.lock:
            if self.frame is None:
                return None, self.seq, {}
            return (self.frame.copy() if copy else self.frame), self.seq, dict(self.frame_metadata or {})

    def wait_for_frame(self, after_seq=-1, timeout=45.0, copy=True):
        """Wait for a genuinely newer camera frame without busy polling."""
        end=time.monotonic()+max(0.1,float(timeout))
        with self.frame_condition:
            while self.seq <= int(after_seq) and not self.stop_event.is_set():
                remaining=end-time.monotonic()
                if remaining<=0: return None,self.seq
                self.frame_condition.wait(timeout=min(remaining,1.0))
            if self.frame is None: return None,self.seq
            return (self.frame.copy() if copy else self.frame), self.seq

    def wait_for_frame_with_metadata(self, after_seq=-1, timeout=45.0, copy=True):
        """Wait for one completed request and return its matching metadata."""
        end=time.monotonic()+max(0.1,float(timeout))
        with self.frame_condition:
            while self.seq <= int(after_seq) and not self.stop_event.is_set():
                remaining=end-time.monotonic()
                if remaining<=0: return None,self.seq,{}
                self.frame_condition.wait(timeout=min(remaining,1.0))
            if self.frame is None: return None,self.seq,{}
            frame=self.frame.copy() if copy else self.frame
            return frame,self.seq,dict(self.frame_metadata or {})

    def jpeg(self, height):
        frame, _ = self.get_frame()
        if frame is None:
            return None
        if height and frame.shape[0] != height:
            w = int(frame.shape[1] * (height / frame.shape[0]))
            frame = cv2.resize(frame, (w, height), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode(
            '.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(self.config['camera'].get('jpeg_quality', 75))]
        )
        return b.tobytes() if ok else None
