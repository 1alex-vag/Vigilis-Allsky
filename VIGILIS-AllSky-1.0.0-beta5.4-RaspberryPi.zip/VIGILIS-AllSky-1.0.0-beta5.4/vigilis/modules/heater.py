from __future__ import annotations

import time
import math


class HeaterController:
    """Controls the 12 V heater MOSFET through GPIO24.

    The Raspberry Pi only drives the MOSFET gate; the heater itself remains on
    the external 12 V rail. ``time_window`` is the recommended low-frequency
    control method for resistive heater bands. ``pwm`` uses gpiozero's PWM
    output at 10 Hz.
    """

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.available = False
        self.state = False
        self.error = ''
        self.output_percent = 0.0
        self._window_started = time.monotonic()
        self._dew_on = False
        try:
            if config.get('heater', {}).get('installed', True) and config.get('gpio', {}).get('enabled', True):
                from gpiozero import PWMOutputDevice
                self.output = PWMOutputDevice(
                    int(config['gpio'].get('heater_pin', 24)),
                    active_high=True,
                    initial_value=0.0,
                    frequency=10,
                )
                self.available = True
        except Exception as exc:
            self.error = str(exc)

    def _write(self, value: float) -> None:
        value = max(0.0, min(1.0, float(value)))
        if not self.available:
            return
        self.output.value = value
        self.state = value > 0.001

    def set(self, on: bool):
        self.output_percent = 100.0 if on else 0.0
        self._write(1.0 if on else 0.0)
        if not self.available:
            return {'ok': False, 'error': self.error or 'unavailable'}
        return {'ok': True, 'state': 'on' if on else 'off'}

    def _automatic_output(self, sensor: dict) -> float:
        if not sensor.get('ok'):
            return 0.0
        heater = self.config.get('heater', {})
        temp = float(sensor.get('temperature_c', 99))
        humidity = float(sensor.get('humidity', 0))
        target = float(heater.get('target_temp_c', 4))
        humidity_trigger = float(heater.get('humidity_trigger_percent', 85))

        # Gentle proportional control: avoid unnecessary full-power heating.
        temp_request = max(0.0, (target - temp) * 20.0)
        humidity_request = max(0.0, (humidity - humidity_trigger) * 5.0)
        demand = max(temp_request, humidity_request)
        if 0 < demand < 15:
            demand = 15
        return max(0.0, min(100.0, demand))

    def update(self, sensor: dict) -> None:
        self._last_sensor = dict(sensor or {})
        heater = self.config.get('heater', {})
        mode = str(heater.get('mode', 'off')).lower()
        regulation = str(heater.get('regulation', 'time_window')).lower()

        if mode == 'off':
            self.output_percent = 0.0
            self._write(0.0)
            return
        if mode == 'dew':
            if not sensor.get('ok') or sensor.get('temperature_c') is None or sensor.get('humidity') is None:
                self.output_percent = 0.0
                self._dew_on = False
                self._write(0.0)
                return
            temp=float(sensor.get('temperature_c')); rh=max(1.0,min(100.0,float(sensor.get('humidity'))))
            a,b=17.62,243.12
            gamma=math.log(rh/100.0)+(a*temp)/(b+temp)
            dew=(b*gamma)/(a-gamma)
            margin=temp-dew
            on_margin=float(heater.get('dew_margin_on_c',3.0))
            off_margin=max(on_margin+0.5,float(heater.get('dew_margin_off_c',5.0)))
            if self._dew_on:
                if margin >= off_margin: self._dew_on=False
            elif margin <= on_margin:
                self._dew_on=True
            self.output_percent=100.0 if self._dew_on else 0.0
            self._write(1.0 if self._dew_on else 0.0)
            return
        # 'on' supplies a fixed user-selected output continuously. The legacy
        # value 'manual' remains accepted so older configurations migrate cleanly.
        if mode in {'on', 'manual'}:
            requested = float(heater.get('manual_output_percent', 100))
        else:
            requested = self._automatic_output(sensor)
        self.output_percent = max(0.0, min(100.0, requested))

        if regulation == 'pwm':
            self._write(self.output_percent / 100.0)
            return

        window = max(10.0, min(600.0, float(heater.get('window_seconds', 60))))
        now = time.monotonic()
        if now - self._window_started >= window:
            self._window_started = now
        phase = now - self._window_started
        on_seconds = window * self.output_percent / 100.0
        self._write(1.0 if phase < on_seconds and self.output_percent > 0 else 0.0)

    # Backwards-compatible name used by the application snapshot loop.
    def auto(self, sensor: dict) -> None:
        self.update(sensor)

    def _dew_point_value(self):
        try:
            s=getattr(self,'_last_sensor',None) or {}
            t=float(s.get('temperature_c')); rh=max(1.0,min(100.0,float(s.get('humidity'))))
            a,b=17.62,243.12; g=math.log(rh/100.0)+(a*t)/(b+t)
            return round((b*g)/(a-g),1)
        except Exception: return None

    def _dew_margin_value(self):
        try:
            s=getattr(self,'_last_sensor',None) or {}; d=self._dew_point_value()
            return None if d is None else round(float(s.get('temperature_c'))-d,1)
        except Exception: return None

    def status(self):
        heater = self.config.get('heater', {})
        window = max(10.0, min(600.0, float(heater.get('window_seconds', 60))))
        phase = (time.monotonic() - self._window_started) % window
        return {
            'available': self.available,
            'state': 'on' if self.state else 'off',
            'mode': heater.get('mode', 'off'),
            'regulation': heater.get('regulation', 'time_window'),
            'output_percent': round(self.output_percent, 1),
            'window_seconds': int(window),
            'cycle_seconds': round(phase, 1),
            'dew_point_c': self._dew_point_value(),
            'dew_margin_c': self._dew_margin_value(),
            'error': self.error,
        }
