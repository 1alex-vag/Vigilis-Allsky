from __future__ import annotations

import threading
import time

from .cover import CoverController


class LensCoverService:
    """AllSky facade around the unchanged Meteor Beta 5.7 cover controller.

    Hardware ownership stays entirely inside Meteor's CoverController.  This
    facade serializes AllSky/manual requests and provides blocking helpers for
    the capture state machine.  It never touches GPIO pins directly.
    """

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.controller = CoverController(config, logger)
        self._command_lock = threading.RLock()
        self._manual_generation = 0
        self._automation_generation = 0
        self._last_source = 'startup'
        self._last_command_at = None

    @property
    def available(self):
        return self.controller.available

    def status(self):
        status = dict(self.controller.status())
        status['command_source'] = self._last_source
        status['last_command_at_monotonic'] = self._last_command_at
        return status

    def move_to(self, target, source='manual'):
        if target not in {'open', 'closed'}:
            return {'ok': False, 'error': 'invalid target'}
        with self._command_lock:
            if source == 'manual':
                self._manual_generation += 1
            else:
                self._automation_generation += 1
            self._last_source = source
            self._last_command_at = time.monotonic()
            return self.controller.move_to(target)

    def stop(self, source='manual'):
        with self._command_lock:
            if source == 'manual':
                self._manual_generation += 1
            self._last_source = source
            self._last_command_at = time.monotonic()
            return self.controller.stop()

    def wait_for(self, target, timeout=None):
        expected = 'open' if target == 'open' else 'closed'
        cfg = self.config.get('cover', {})
        if timeout is None:
            key = 'opening_timeout_seconds' if expected == 'open' else 'closing_timeout_seconds'
            timeout = max(5.0, float(cfg.get(key, 20))) + 2.0
        deadline = time.monotonic() + float(timeout)
        while time.monotonic() < deadline:
            st = self.status()
            if st.get('state') == expected:
                return {'ok': True, 'state': expected}
            if st.get('state') == 'fault':
                return {'ok': False, 'state': 'fault', 'error': st.get('error') or 'lens cover fault'}
            time.sleep(0.05)
        return {'ok': False, 'state': self.status().get('state'), 'error': f'lens cover did not reach {expected} in time'}

    def ensure(self, target, source='automation'):
        expected = 'open' if target == 'open' else 'closed'
        st = self.status()
        if not st.get('installed', True) or not st.get('available', False):
            # An intentionally disabled cover must not block image capture.
            if not st.get('installed', True) or st.get('error') == 'disabled':
                return {'ok': True, 'state': 'disabled'}
            return {'ok': False, 'error': st.get('error') or 'GPIO unavailable'}
        if st.get('state') == expected:
            return {'ok': True, 'state': expected}
        if st.get('moving'):
            return self.wait_for(expected)
        result = self.move_to(expected, source=source)
        if not result.get('ok'):
            return result
        return self.wait_for(expected)
