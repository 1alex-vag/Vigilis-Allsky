from __future__ import annotations
from pathlib import Path
import copy, json, os, threading, time, cv2, numpy as np
from datetime import timedelta
from .image_processing import NoiseReducer
from .overlay import apply_overlay

class AllSkyCapture:
    """Single-camera AllSky capture state machine.

    Day: cover opens only for a calibrated image and closes afterwards.
    Sunset transition: cover remains open and images are captured at a shorter interval.
    Night: cover remains open continuously and long-exposure control is active.
    """
    def __init__(self,config,camera,schedule,root:Path,logger,exposure_controller=None,cover=None,sensor=None):
        self.config=config; self.camera=camera; self.schedule=schedule; self.root=root; self.logger=logger
        self.exposure_controller=exposure_controller; self.cover=cover; self.sensor=sensor
        self.noise_reducer=NoiseReducer(config)
        self.stop_event=threading.Event(); self.pause_event=threading.Event(); self.thread=None
        self._operation_lock=threading.RLock(); self._quick_thread=None
        self.status={'running':False,'state':'initializing','mode':'day','captures_total':0,'captures_today':0,'last_capture_at':None,'last_capture_path':None,'last_error':'','next_capture_in_seconds':None,'exposure_started_at':None,'exposure_target_seconds':None,'sequence':0,'last_frame_wait_seconds':None,'last_cycle_seconds':None,'cover_managed':bool(cover),'quick_capture':{'active':False,'state':'idle','message':'Ready','error':'','last_capture_at':None},'calibration':{'active':False,'step':0,'steps_total':6,'exposure_ms':None,'gain':None,'measured':None,'clipped_percent':None,'message':''}}
        self._day=self.schedule.now().strftime('%Y-%m-%d')
        self._last_mode=None
        self._day_cover_parked=False
        # Sequence of the last frame written to the archive.  The camera manager
        # continuously exposes in the background, so capture requests must wait
        # for a genuinely newer sequence instead of reusing the current frame.
        self._last_saved_sequence=-1
        self._mode_calibration_pending=None
        # Metadata belonging to the exact sensor request selected for the next archive write.
        # This is intentionally snapshotted before processing so a later camera request cannot
        # overwrite the sidecar/debug values while the Raspberry Pi is encoding the image.
        self._last_capture_metadata={}
    def start(self):
        if not self.thread or not self.thread.is_alive(): self.thread=threading.Thread(target=self._run,daemon=True,name='allsky-capture'); self.thread.start()
    def stop(self): self.stop_event.set()
    def pause(self): self.pause_event.set(); self.status.update(running=False,state='focus mode',next_capture_in_seconds=None)
    def resume(self): self.pause_event.clear()

    def quick_capture(self):
        """Start a one-shot capture without disturbing the normal schedule.

        The current lens-cover position and exposure-controller state are restored
        afterwards.  Auto mode performs a short four-frame daylight calibration.
        """
        if self._quick_thread and self._quick_thread.is_alive():
            return {'ok':False,'error':'Quick Capture is already running'}
        if self.pause_event.is_set():
            return {'ok':False,'error':'Quick Capture is unavailable while Focus mode is active'}
        self._quick_thread=threading.Thread(target=self._quick_capture_worker,daemon=True,name='quick-capture')
        self._quick_thread.start()
        return {'ok':True,'started':True}

    def _quick_capture_worker(self):
        qc=self.status['quick_capture']; qc.update(active=True,state='starting',message='Preparing Quick Capture',error='')
        was_paused=self.pause_event.is_set()
        self.pause_event.set()
        saved=None; final_seq=None
        try:
            with self._operation_lock:
                initial_cover=(self.cover.status().get('state') if self.cover else 'disabled')
                should_close=initial_cover=='closed'
                if self.cover and self.config.get('cover',{}).get('installed',True) and initial_cover!='open':
                    qc.update(state='opening_cover',message='Opening lens cover…')
                    if not self._cover_move('open'):
                        raise RuntimeError('Lens cover could not be opened')
                stabilization=max(0.0,min(5.0,float(self.config.get('cover',{}).get('stabilization_seconds',1))))
                if stabilization:
                    qc.update(state='stabilizing',message='Stabilizing…'); time.sleep(stabilization)

                if self.exposure_controller:
                    saved={
                        'states':copy.deepcopy(self.exposure_controller.states),
                        'mode':self.exposure_controller.mode,
                        'current':self.exposure_controller.current,
                        'current_gain':self.exposure_controller.current_gain,
                        'status':copy.deepcopy(self.exposure_controller.status),
                    }
                cap=self.config.get('capture',{})
                mode=str(cap.get('quick_capture_exposure_mode','auto')).lower()
                seq=int(getattr(self.camera,'seq',0))
                if mode=='auto' and self.exposure_controller:
                    qc.update(state='calibrating',message='Calibrating exposure…')
                    # IMPORTANT: exactly the same acquisition/calibration path as scheduled Day Capture.
                    frame,final_seq=self._capture_day_reference()
                    qc.update(state='capturing',message='Daylight frame ready')
                else:
                    seconds=max(.0001,min(5.0,float(cap.get('quick_capture_exposure_seconds',.05))))
                    gain=1.0
                    qc.update(state='calibrating',message=f'Preparing {seconds*1000:.1f} ms exposure…')
                    if self.exposure_controller:
                        self.exposure_controller.mode='day'; self.exposure_controller.current=seconds; self.exposure_controller.current_gain=gain
                        self.exposure_controller.status.update(mode='day',current_seconds=seconds,current_gain=gain)
                    self.camera.apply_capture_controls(seconds,gain)
                    # Discard one frame after changing controls so the saved frame is guaranteed to use them.
                    _,seq=self.camera.wait_for_frame(after_seq=seq,timeout=max(10,seconds+5),copy=False)
                    qc.update(state='capturing',message='Taking image…')
                    frame,final_seq=self._capture_frame(mode='day',after_seq=seq)

                qc.update(state='saving',message='Saving image…')
                self._store(frame,final_seq,'quick')
                self._last_saved_sequence=max(self._last_saved_sequence,int(final_seq))
                qc['last_capture_at']=self.status.get('last_capture_at')

                if should_close:
                    qc.update(state='closing_cover',message='Closing lens cover…')
                    if not self._cover_move('closed'):
                        raise RuntimeError('Image saved, but lens cover could not be closed')
                qc.update(state='done',message='Quick Capture complete ✓')
        except Exception as exc:
            qc.update(state='error',message='Quick Capture failed',error=str(exc)); self.logger.exception('Quick Capture failed')
        finally:
            if saved and self.exposure_controller:
                try:
                    self.exposure_controller.states=saved['states']; self.exposure_controller.mode=saved['mode']; self.exposure_controller.current=saved['current']; self.exposure_controller.current_gain=saved['current_gain']; self.exposure_controller.status=saved['status']
                    self.camera.apply_capture_controls(saved['current'],saved['current_gain'])
                except Exception:
                    self.logger.exception('Failed to restore exposure after Quick Capture')
            if not was_paused:
                self.pause_event.clear()
            qc['active']=False

    def _mode(self):
        st=self.schedule.status(); sun=st.get('sun_altitude'); c=self.config.get('capture',{})
        night_start=float(c.get('start_sun_altitude',-6))
        night_end=float(c.get('stop_sun_altitude',night_start))
        evening_transition=float(c.get('transition_start_sun_altitude',10))
        morning_end=float(c.get('morning_transition_end_sun_altitude',0))
        if sun is None: return 'day'
        # Evening and morning have independent night thresholds.  This allows,
        # for example, night start at -6° and night end at -4° while keeping
        # a separate morning transition limit.
        if self.schedule.now().hour < 12:
            if sun <= night_end: return 'night'
            return 'transition' if sun<=morning_end else 'day'
        if sun <= night_start: return 'night'
        return 'transition' if sun<=evening_transition else 'day'
    def _interval(self,mode):
        c=self.config.get('capture',{})
        if mode=='night':
            # Exposure time is already spent inside the continuously running
            # camera backend.  Waiting for exposure+delay here can make the
            # archive sample the same camera frame twice.  Only apply the user
            # delay; _capture_frame() waits for the next sequence itself.
            return max(0.0,float(c.get('delay_seconds',1)))
        if mode=='transition': return max(1,float(c.get('transition_interval_minutes',2))*60)
        return max(1,float(c.get('day_delay_minutes',20))*60)
    def _cover_move(self,target):
        """Request a cover position through the isolated LensCoverService only.

        AllSky never reads or writes STEP/DIR/ENABLE/Hall GPIOs itself.
        """
        if not self.cover or not self.config.get('cover',{}).get('installed',True):
            return True
        try:
            result=self.cover.ensure(target, source='allsky-capture')
            if result.get('ok',False):
                return True
            self.status['last_error']=str(result.get('error') or 'Lens cover movement failed')
            return False
        except Exception as exc:
            self.logger.exception('Lens cover request failed')
            self.status['last_error']=str(exc)
            return False
    def _capture_frame(self, calibrate=False, mode='night', after_seq=None):
        expected=float(self.exposure_controller.current if self.exposure_controller else self.config.get('capture',{}).get('manual_exposure_seconds',5))
        self.status['exposure_started_at']=self.schedule.now().isoformat()
        self.status['exposure_target_seconds']=round(max(0.001,expected),4)
        deadline=time.monotonic()+max(15,float(self.config.get('capture',{}).get('max_exposure_seconds',30))+10)
        threshold = -1 if after_seq is None else int(after_seq)
        wait_started=time.monotonic()
        try:
            remaining=max(0.1,deadline-time.monotonic())
            if hasattr(self.camera,'wait_for_frame_with_metadata'):
                frame,seq,meta=self.camera.wait_for_frame_with_metadata(after_seq=threshold,timeout=remaining,copy=True)
                self._last_capture_metadata=dict(meta or {})
            elif hasattr(self.camera,'wait_for_frame'):
                frame,seq=self.camera.wait_for_frame(after_seq=threshold,timeout=remaining,copy=True)
                self._last_capture_metadata={}
            else:
                frame,seq=self.camera.get_frame()
                self._last_capture_metadata={}
            if frame is None or seq<=threshold:
                raise RuntimeError('Camera did not provide a fresh frame in time')
            self.status['last_frame_wait_seconds']=round(time.monotonic()-wait_started,3)
            if calibrate and self.exposure_controller:
                self.exposure_controller.update(frame, mode=mode)
            return frame,seq
        finally:
            self.status['exposure_started_at']=None

    def _wait_for_stable_controls(self, mode, after_seq, max_frames=4):
        """Discard queued/stale CSI requests until metadata matches current controls.

        Picamera2/libcamera keeps several requests queued so the sensor can expose
        continuously.  After a large exposure/gain change one or more completed
        requests may still contain the *old* controls.  Those frames are useful
        neither for calibration nor for the archive, and were the source of the
        occasional 1 ms black twilight frame.
        """
        target_exp=float(self.exposure_controller.current if self.exposure_controller else 0.0)
        target_gain=float(self.exposure_controller.current_gain if self.exposure_controller else 1.0)
        seq=int(after_seq)
        frame=None
        for _ in range(max(1,12 if mode=='day' else int(max_frames))):
            deadline=time.monotonic()+max(15,float(self.config.get('capture',{}).get('max_exposure_seconds',30))+10)
            remaining=max(0.1,deadline-time.monotonic())
            if hasattr(self.camera,'wait_for_frame_with_metadata'):
                frame,seq,meta=self.camera.wait_for_frame_with_metadata(after_seq=seq,timeout=remaining,copy=True)
            else:
                frame,seq=self.camera.wait_for_frame(after_seq=seq,timeout=remaining,copy=True)
                meta={}
            if frame is None:
                continue
            actual_exp=float(meta.get('ExposureTime',target_exp*1e6) or 0)/1e6
            actual_gain=float(meta.get('AnalogueGain',target_gain) or target_gain)
            if mode == 'day':
                # The old 2 ms absolute tolerance was enormous for daylight:
                # a requested 110 us exposure could incorrectly accept a queued
                # 0.6-2.0 ms request as 'stable'. At noon that is several stops.
                exp_tol=max(0.000005,target_exp*0.12)   # 5 us or 12 %
                gain_tol=max(0.05,target_gain*0.06)
            else:
                exp_tol=max(0.002,target_exp*0.18)
                gain_tol=max(0.20,target_gain*0.22)
            exp_ok=(target_exp <= 0) or abs(actual_exp-target_exp) <= exp_tol
            gain_ok=abs(actual_gain-target_gain) <= gain_tol
            if exp_ok and gain_ok:
                self._last_capture_metadata=dict(meta or {})
                return frame,seq
            self.logger.info('Discarding stale control frame seq=%s mode=%s exp=%.6fs/%.6fs tol=%.6fs gain=%.2f/%.2f',seq,mode,actual_exp,target_exp,exp_tol,actual_gain,target_gain)
        # Never archive a daylight request whose metadata does not match the
        # calibrated controls. A later scheduler retry is safer than a blown frame.
        if mode == 'day':
            raise RuntimeError(f'Daylight controls did not settle near {target_exp*1e6:.0f} us / gain {target_gain:.2f}')
        return frame,seq

    @staticmethod
    def _daylight_metrics(frame):
        """Return highlight percentile and clipped-pixel percentage."""
        if frame is None:
            return 255.0, 100.0
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY) if frame.ndim==3 else frame
        small=cv2.resize(gray,(320,180),interpolation=cv2.INTER_AREA)
        p98=float(np.percentile(small,98))
        clipped=float(np.count_nonzero(small >= 250))/float(small.size)*100.0
        return p98, clipped

    def _wait_for_daylight_archive_ready(self, after_seq, max_rounds=6):
        """Return only a stable, highlight-safe daylight frame.

        A metadata match alone is not enough after a large day-AE step: queued
        requests can converge while the actual scene is still clipped.  Keep
        calibration frames internal, re-adjust from the *stable* frame, and only
        release a frame to the archive when both controls and highlights are sane.
        """
        seq=int(after_seq)
        frame=None
        cal=self.status['calibration']
        for round_no in range(1,max(1,int(max_rounds))+1):
            frame,seq=self._wait_for_stable_controls('day',seq,max_frames=6)
            if frame is None:
                continue
            p98,clipped=self._daylight_metrics(frame)
            cal.update(measured=round(p98,2),clipped_percent=round(clipped,3),message=f'Validating daylight frame {round_no}/{max_rounds}')
            # Preserve cloud texture and avoid the broad white solar bloom seen
            # in 3.8.  A tiny solar core may clip; the surrounding sky may not.
            if p98 <= 225.0 and clipped <= 0.50:
                cal['message']='Daylight frame ready'
                return frame,seq
            self.logger.info('Daylight frame still too bright seq=%s p98=%.1f clipped=%.3f%%; reducing exposure',seq,p98,clipped)
            before=float(self.exposure_controller.current)
            self.exposure_controller.update(frame,mode='day')
            after=float(self.exposure_controller.current)
            if after >= before * 0.995:
                # We are at the sensor minimum. Return the best physically
                # achievable frame instead of looping forever.
                self.logger.warning('Day exposure reached sensor minimum at %.3f ms (p98=%.1f clipped=%.3f%%)',after*1000,p98,clipped)
                return frame,seq
        return frame,seq

    @staticmethod
    def _transition_frame_implausibly_dark(frame):
        """Reject only obvious black/near-black twilight glitches.

        This guard is intentionally conservative and applies only during
        transition mode; real night frames are never brightness-filtered.
        """
        if frame is None:
            return True
        try:
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY) if frame.ndim==3 else frame
            small=cv2.resize(gray,(320,240),interpolation=cv2.INTER_AREA)
            p80=float(np.percentile(small,80))
            mean=float(np.mean(small))
            return p80 < 8.0 and mean < 5.0
        except Exception:
            return False

    def _calibrate_mode(self, mode, message, steps=5):
        """Fast exposure calibration for twilight/night; test frames are discarded.

        Unlike normal auto-exposure tracking this is intentionally aggressive.
        It is used before an archived transition/night frame so dark calibration
        frames never enter Gallery, Timelapse, Startrail or Keogram.
        """
        if not self.exposure_controller:
            return self._capture_frame(mode=mode, after_seq=self._last_saved_sequence)
        self.exposure_controller.enter_mode(mode)
        seq=max(int(getattr(self.camera,'seq',0)), int(self._last_saved_sequence))
        frame=None
        cal=self.status['calibration']; cal.update(active=True,step=0,steps_total=steps,message=message)
        try:
            for step in range(1,steps+1):
                cal.update(step=step,exposure_ms=round(float(self.exposure_controller.current)*1000,3),gain=round(float(self.exposure_controller.current_gain),2),message=message)
                frame,seq=self._capture_frame(mode=mode,after_seq=seq)
                before=float(self.exposure_controller.current)
                self.exposure_controller.update(frame,mode=mode,fast=True)
                measured=self.exposure_controller.status.get('measured_percentile')
                clipped=float(self.exposure_controller.status.get('clipped_percent') or 0)
                target=float(self.exposure_controller.status.get('target_percentile') or self.config.get('capture',{}).get('exposure_target',75))
                change=abs(float(self.exposure_controller.current)-before)/max(before,1e-6)
                cal.update(exposure_ms=round(float(self.exposure_controller.current)*1000,3),gain=round(float(self.exposure_controller.current_gain),2),measured=measured,clipped_percent=clipped)
                if measured is not None and target*.82 <= float(measured) <= target*1.18 and clipped < 1.5 and change < .28:
                    break
            cal['message']='Waiting for stable calibrated frame'
            # Requests can already be queued with the previous exposure/gain.
            # Discard them until the completed request metadata matches the final
            # calibrated controls.  Calibration/test frames are never archived.
            return self._wait_for_stable_controls(mode,seq,max_frames=4)
        finally:
            cal['active']=False

    def _capture_day_reference(self):
        """Canonical daylight capture path used by BOTH Scheduler and Quick Capture.

        Beta 4.1 deliberately removes the remaining duplicated daylight workflow.
        The trigger source may differ, but calibration, stable-request selection,
        highlight validation and the final archive frame are now literally the
        same code path.
        """
        return self._calibrate_day()

    def _calibrate_day(self, status_sink=None):
        """Fast closed-loop daylight calibration; calibration frames are never archived."""
        if not self.exposure_controller:
            return self._capture_frame(mode='day')
        self.exposure_controller.prepare_day()
        previous_seq = int(getattr(self.camera, 'seq', 0))
        frame = None
        seq = previous_seq
        cal=self.status['calibration']; cal.update(active=True,step=0,steps_total=6,message='Starting daylight calibration')
        sink=status_sink if isinstance(status_sink,dict) else None
        try:
            for step in range(1,7):
                cal.update(step=step,exposure_ms=round(float(self.exposure_controller.current)*1000,3),gain=round(float(self.exposure_controller.current_gain),2),message=f'Calibration {step}/6')
                if sink is not None:
                    sink.update(state='calibrating',message=f'Calibrating exposure {step}/6…')
                frame,seq = self._capture_frame(mode='day', after_seq=seq)
                before = float(self.exposure_controller.current)
                self.exposure_controller.update(frame, mode='day')
                measured = self.exposure_controller.status.get('measured_percentile')
                clipped = float(self.exposure_controller.status.get('clipped_percent') or 0)
                cal.update(exposure_ms=round(float(self.exposure_controller.current)*1000,3),gain=round(float(self.exposure_controller.current_gain),2),measured=measured,clipped_percent=clipped)
                change = abs(float(self.exposure_controller.current)-before)/max(before,1e-6)
                if measured is not None and 180 <= float(measured) <= 225 and clipped < 0.50 and change < 0.18:
                    cal['message']='Exposure calibrated'
                    break
            cal['message']='Waiting for stable daylight frame'
            return self._wait_for_daylight_archive_ready(seq,max_rounds=8)
        finally:
            # Keep the final values visible briefly through status polling, while
            # marking the calibration as complete.
            cal['active']=False

    def _paths(self,now,ext,mode):
        c=self.config.get('capture',{}); latest_dir=self.root/'data'/'allsky'; latest_dir.mkdir(parents=True,exist_ok=True); latest=latest_dir/f'latest.{ext}'
        if not c.get('archive_enabled',True): return latest,None,None
        folder='Nacht' if mode in {'night','transition'} else 'Tag'
        # An observing night is one session even when it crosses midnight.
        # The session is anchored to the date on which the evening started.
        session_day=now.date()-timedelta(days=1) if mode in {'night','transition'} and now.hour<12 else now.date()
        period=self.root/str(c.get('archive_path','allsky'))/session_day.strftime('%Y/%m/%d')/folder
        archive=period/'images'; archive.mkdir(parents=True,exist_ok=True)
        stem=now.strftime(f'{mode}_%Y%m%d_%H%M%S_%f')[:-3]
        return latest,archive/f'{stem}.{ext}',archive/f'{stem}.json'
    @staticmethod
    def _atomic(path,payload):
        tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_bytes(payload); os.replace(tmp,path)
    def _store(self,frame,seq,mode):
        # Keep the sensor acquisition thread lean: full-resolution Vision Engine
        # processing happens here so it can overlap the NEXT camera exposure.
        # Exposure calibration always sees the untouched camera frame.
        process_started=time.monotonic()
        if hasattr(self.camera,'process_for_archive'):
            frame=self.camera.process_for_archive(frame)
        frame=self.noise_reducer.apply(frame, mode=mode)
        self.status['archive_processing_seconds']=round(time.monotonic()-process_started,3)
        self.status['noise_reduction']=dict(self.noise_reducer.status)
        now=self.schedule.now()
        # Preserve an overlay-free copy of the exact same completed capture for
        # the Overlay Editor. Home continues to show latest.jpg/latest.png with
        # the rendered overlay; the editor re-renders onto this matching source
        # image and never asks the camera for a separate preview exposure.
        try:
            source_dir=self.root/'data'/'allsky'; source_dir.mkdir(parents=True,exist_ok=True)
            source_ok,source_data=cv2.imencode('.jpg',frame,[int(cv2.IMWRITE_JPEG_QUALITY),92])
            if source_ok:
                self._atomic(source_dir/'latest_source.jpg',source_data.tobytes())
        except Exception:
            self.logger.exception('Could not update overlay editor source image')
        frame=apply_overlay(frame,self.config,now,self.schedule,self.exposure_controller,self.camera,self.sensor,capture_metadata=dict(self._last_capture_metadata or {}))
        c=self.config.get('capture',{}); fmt=str(c.get('image_format','jpg')).lower(); fmt=fmt if fmt in {'jpg','png'} else 'jpg'
        args=[int(cv2.IMWRITE_PNG_COMPRESSION),int(c.get('png_compression',3))] if fmt=='png' else [int(cv2.IMWRITE_JPEG_QUALITY),int(c.get('jpeg_quality',95))]
        ok,data=cv2.imencode('.'+fmt,frame,args)
        if not ok: raise RuntimeError('Image encoding failed')
        latest,image,sidecar=self._paths(now,fmt,mode); payload=data.tobytes(); self._atomic(latest,payload)
        if image:self._atomic(image,payload)
        request_meta=dict(self._last_capture_metadata or {})
        camera_status=dict(getattr(self.camera,'status',{}) or {})
        exp_seconds=request_meta.get('ExposureTime')
        if exp_seconds is not None:
            try: exp_seconds=float(exp_seconds)/1_000_000.0
            except Exception: exp_seconds=None
        if exp_seconds is None:
            exp_seconds=getattr(self.exposure_controller,'current',None)
        gain=request_meta.get('AnalogueGain',camera_status.get('analogue_gain'))
        meta={
            'product':'VIGILIS AllSky',
            'captured_at':now.isoformat(),
            'mode':mode,
            'sequence':seq,
            'width':frame.shape[1],
            'height':frame.shape[0],
            'sun_altitude':self.schedule.sun_altitude(),
            'exposure_seconds':exp_seconds,
            'analogue_gain':gain,
            'request_metadata':{
                k:request_meta.get(k) for k in
                ('ExposureTime','AnalogueGain','DigitalGain','ColourGains','FrameDuration','Lux','ColourTemperature')
                if k in request_meta
            },
            'processing':{
                'pipeline':'shared-day-quick-v4.1' if mode in {'day','quick'} else 'night-transition',
                'image_enhancement':camera_status.get('image_enhancement'),
                'vision_gamma':camera_status.get('vision_gamma'),
                'vision_mean':camera_status.get('vision_mean'),
                'vision_median':camera_status.get('vision_median'),
                'vision_clipped_percent':camera_status.get('vision_clipped_percent'),
                'white_balance_red_gain':camera_status.get('white_balance_red_gain'),
                'white_balance_blue_gain':camera_status.get('white_balance_blue_gain'),
            },
        }
        if sidecar and c.get('metadata_sidecar',True): sidecar.write_text(json.dumps(meta,indent=2,ensure_ascii=False))
        day=now.strftime('%Y-%m-%d')
        if day!=self._day:self._day=day;self.status['captures_today']=0
        self.status.update(captures_total=self.status['captures_total']+1,captures_today=self.status['captures_today']+1,last_capture_at=meta['captured_at'],last_capture_path=str((image or latest).relative_to(self.root)),sequence=seq,last_error='',mode=mode)
    def _run(self):
        # Give the unchanged Meteor GPIO controller time to initialize and read
        # both Hall inputs before AllSky automation is allowed to command motion.
        self.status.update(running=False,state='hardware initialization',next_capture_in_seconds=None)
        for _ in range(20):
            if self.stop_event.is_set(): return
            time.sleep(.25)
        deadline=time.monotonic()
        cycle_started=None
        while not self.stop_event.is_set():
            if self.pause_event.is_set(): self.status.update(running=False,state='focus mode',next_capture_in_seconds=None); time.sleep(.25); deadline=time.monotonic(); continue
            mode=self._mode(); c=self.config.get('capture',{}); enabled=(mode!='day') or bool(c.get('day_capture_enabled',False))

            # Manage day/night transitions once.  The previous implementation
            # issued CLOSE every second while Day Capture was disabled.  That
            # continuously fought manual Home controls and could drive the
            # unchanged Meteor CoverController into fault.
            if mode!=self._last_mode:
                previous=self._last_mode
                self._last_mode=mode
                self._day_cover_parked=False
                if self.exposure_controller:
                    self.exposure_controller.enter_mode(mode)
                if mode == 'transition':
                    direction='morning' if previous=='night' else 'evening'
                    self._mode_calibration_pending=direction
                elif mode == 'night':
                    self._mode_calibration_pending='night'
                else:
                    self._mode_calibration_pending=None
                if mode in {'transition','night'}:
                    self.status['state']='opening lens cover'
                    if not self._cover_move('open'):
                        self.status.update(running=False,state='cover error',mode=mode)
                    else:
                        self.logger.info('Lens cover opened for %s mode (previous=%s)',mode,previous)
                elif mode=='day':
                    self.status['state']='closing lens cover'
                    self._day_cover_parked=self._cover_move('closed')
                    if self._day_cover_parked:
                        self.logger.info('Lens cover parked closed for day mode (previous=%s)',previous)

            if not enabled:
                # Day mode OFF: park the cover once on entry, then leave manual
                # Open/Close controls completely alone until the next mode change.
                self.status.update(running=False,state='day capture disabled',mode=mode,next_capture_in_seconds=None)
                time.sleep(1); deadline=time.monotonic(); continue
            rem=deadline-time.monotonic()
            if rem>0: self.status.update(running=True,state='waiting',mode=mode,next_capture_in_seconds=round(rem,1)); time.sleep(min(.5,rem)); continue
            try:
                cycle_started=time.monotonic()
                with self._operation_lock:
                    if not self._cover_move('open'): raise RuntimeError('Lens cover could not be opened')
                    if mode=='day':
                        self.status['state']='calibrating day exposure'
                        frame,seq=self._capture_day_reference()
                    elif mode=='transition' and self._mode_calibration_pending in {'morning','evening'}:
                        # Mode boundary: flush queued requests by calibrating on
                        # discarded test frames, then archive only a request whose
                        # metadata matches the final transition controls.
                        direction=str(self._mode_calibration_pending)
                        label=f'Calibrating {direction} transition…'
                        self.status['state']=label.lower()
                        frame,seq=self._calibrate_mode('transition',label,steps=4)
                        self._mode_calibration_pending=None
                    elif mode=='transition':
                        # Twilight can change by several stops during a five-minute
                        # interval.  A frame captured first and used to update AE
                        # afterwards is already stale for the archive.  Do a short
                        # two-frame preflight immediately before every transition
                        # archive capture.  These test frames are discarded; only
                        # the stable request after the adjustment is saved.
                        self.status['state']='adjusting transition exposure'
                        frame,seq=self._calibrate_mode('transition','Adjusting transition exposure…',steps=2)
                    elif self._mode_calibration_pending=='night':
                        self.status['state']='calibrating night exposure'
                        frame,seq=self._calibrate_mode('night','Calibrating night exposure…',steps=5)
                        self._mode_calibration_pending=None
                    else:
                        self.status['state']='capturing'
                        # Never archive the same camera frame twice. Sequence ID is
                        # only a duplicate guard; camera cadence itself is handled
                        # by the blocking camera backend.
                        frame,seq=self._capture_frame(calibrate=True, mode=mode, after_seq=self._last_saved_sequence)
                    # A queued request can very rarely survive a large AE
                    # step even after transition calibration. Never archive an
                    # obvious black/glitch frame. A single retry uses fresh
                    # discarded calibration requests before saving.
                    if mode=='transition' and self._transition_frame_implausibly_dark(frame):
                        self.logger.warning('Discarding implausibly dark transition frame seq=%s; recalibrating once',seq)
                        self.status['state']='recalibrating transition exposure'
                        frame,seq=self._calibrate_mode('transition','Recalibrating transition exposure…',steps=3)
                    self.status['state']='saving image'
                    self._store(frame,seq,mode)
                    self._last_saved_sequence=max(self._last_saved_sequence,int(seq))
                    if mode=='day' and not self._cover_move('closed'): raise RuntimeError('Lens cover could not be closed')
                self.status['last_cycle_seconds']=round(time.monotonic()-cycle_started,3) if cycle_started else None
                # Do not add exposure time a second time. The camera manager is
                # continuously exposing; after the user delay we wait only for
                # the next sequence newer than the archived frame.
                self.status['state']='waiting'; deadline=time.monotonic()+self._interval(mode)
            except Exception as exc:
                self.status.update(last_error=str(exc),state='capture error'); self.logger.exception('AllSky capture failed')
                if mode=='day': self._cover_move('closed')
                deadline=time.monotonic()+5
