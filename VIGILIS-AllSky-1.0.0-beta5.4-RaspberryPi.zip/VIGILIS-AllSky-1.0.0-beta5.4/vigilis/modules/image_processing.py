from __future__ import annotations

import time
import cv2
import numpy as np


class NoiseReducer:
    """Fast, star-preserving noise reduction for Raspberry Pi AllSky images.

    The primary target is chrominance noise.  Luminance is only touched very
    gently at Medium/High so stars and Milky Way structure stay crisp.  This
    intentionally avoids expensive full-resolution non-local-means filtering
    on a Raspberry Pi 4.
    """

    LEVELS = {"off", "low", "medium", "high"}

    def __init__(self, config: dict):
        self.config = config
        self.status = {
            "level": "medium",
            "last_processing_ms": 0.0,
            "last_applied": False,
            "last_mode": None,
        }

    def _level(self) -> str:
        level = str(self.config.get("processing", {}).get("noise_reduction", "medium")).lower()
        return level if level in self.LEVELS else "medium"

    @staticmethod
    def _blend_u8(a: np.ndarray, b: np.ndarray, amount: float) -> np.ndarray:
        if amount <= 0:
            return a
        return cv2.addWeighted(a, 1.0 - amount, b, amount, 0.0)

    def apply(self, frame: np.ndarray, mode: str = "night") -> np.ndarray:
        level = self._level()
        start = time.perf_counter()
        self.status.update(level=level, last_mode=mode, last_applied=False)

        # Daylight frames usually do not need denoising and keeping them raw
        # avoids unnecessary CPU use during daytime calibration/capture.
        if level == "off" or mode in {"day", "quick"} or frame is None:
            self.status["last_processing_ms"] = round((time.perf_counter() - start) * 1000.0, 1)
            return frame

        if frame.dtype != np.uint8:
            work = np.clip(frame, 0, 255).astype(np.uint8)
        else:
            work = frame

        # OpenCV camera frames are BGR/RGB-like 3-channel 8-bit images in this
        # pipeline.  YCrCb lets us smooth colour noise without blurring stars.
        ycc = cv2.cvtColor(work, cv2.COLOR_BGR2YCrCb)
        y, cr, cb = cv2.split(ycc)

        if level == "low":
            kernel, sigma, chroma_mix, luma_mix = 3, 0.8, 0.35, 0.0
        elif level == "high":
            kernel, sigma, chroma_mix, luma_mix = 7, 1.6, 0.72, 0.14
        else:  # medium
            kernel, sigma, chroma_mix, luma_mix = 5, 1.2, 0.55, 0.07

        cr_blur = cv2.GaussianBlur(cr, (kernel, kernel), sigmaX=sigma, sigmaY=sigma)
        cb_blur = cv2.GaussianBlur(cb, (kernel, kernel), sigmaX=sigma, sigmaY=sigma)
        cr = self._blend_u8(cr, cr_blur, chroma_mix)
        cb = self._blend_u8(cb, cb_blur, chroma_mix)

        if luma_mix > 0:
            y_med = cv2.medianBlur(y, 3)
            y_soft = self._blend_u8(y, y_med, luma_mix)

            # Preserve small bright high-frequency structures (stars).  Pixels
            # that stand clearly above their local 3x3 median retain original Y.
            detail = cv2.subtract(y, y_med)
            star_mask = (detail > 10) & (y > 48)
            if np.any(star_mask):
                y_soft[star_mask] = y[star_mask]
            y = y_soft

        result = cv2.cvtColor(cv2.merge((y, cr, cb)), cv2.COLOR_YCrCb2BGR)
        self.status.update(
            last_processing_ms=round((time.perf_counter() - start) * 1000.0, 1),
            last_applied=True,
        )
        return result
