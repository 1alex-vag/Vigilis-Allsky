from __future__ import annotations

import datetime as dt
import html
import json
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path


class TelegramNotifier:
    """Telegram 2.0 notification service.

    The class deliberately contains only transport and message formatting.
    Scheduling and hardware-state observation remain in ``app.py`` so the
    existing VIGILIS architecture stays unchanged.
    """

    def __init__(self, config, root: Path, logger):
        self.config = config
        self.root = Path(root)
        self.logger = logger
        self.lock = threading.Lock()
        self.last_sent = 0.0
        self.last_result = {"ok": False, "message": "No message sent yet", "sent_at": None}

    def _settings(self) -> dict:
        return self.config.get("telegram", {})

    def enabled(self) -> bool:
        c = self._settings()
        return bool(c.get("enabled") and str(c.get("bot_token", "")).strip() and str(c.get("chat_id", "")).strip())

    def identity(self) -> tuple[str, str, str]:
        c = self._settings()
        observer = str(c.get("observer_name") or "Observer").strip()
        station = str(c.get("station_name") or self.config.get("location", {}).get("name") or "VIGILIS Station").strip()
        location = str(c.get("station_location") or "").strip()
        return observer, station, location

    @staticmethod
    def _safe(value) -> str:
        return html.escape(str(value), quote=False)

    def _header(self, icon: str, title: str) -> list[str]:
        _, station, location = self.identity()
        lines = [f"{icon} <b>{self._safe(title)}</b>", "", f"<b>{self._safe(station)}</b>"]
        if location:
            lines.append(self._safe(location))
        return lines

    def send(self, text: str, force: bool = False, parse_mode: str = "HTML") -> dict:
        if not self.enabled():
            return {"ok": False, "error": "Telegram is not configured"}
        c = self._settings()
        cooldown = max(0, int(c.get("cooldown_seconds", 5)))
        with self.lock:
            if not force and time.time() - self.last_sent < cooldown:
                return {"ok": False, "queued": True, "error": "cooldown"}
            try:
                token = str(c["bot_token"]).strip()
                chat = str(c["chat_id"]).strip()
                data = urllib.parse.urlencode({
                    "chat_id": chat,
                    "text": text,
                    "parse_mode": parse_mode,
                    "disable_web_page_preview": "true",
                }).encode()
                req = urllib.request.Request(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    data=data,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=15) as response:
                    payload = json.loads(response.read().decode())
                if not payload.get("ok"):
                    raise RuntimeError(payload.get("description", "Telegram API error"))
                self.last_sent = time.time()
                self.last_result = {"ok": True, "message": "Message sent", "sent_at": dt.datetime.now().isoformat(timespec="seconds")}
                return dict(self.last_result)
            except Exception as exc:
                self.logger.warning("Telegram send failed: %s", exc)
                self.last_result = {"ok": False, "error": str(exc), "sent_at": dt.datetime.now().isoformat(timespec="seconds")}
                return dict(self.last_result)

    def test(self, status: dict | None = None) -> dict:
        observer, _, _ = self.identity()
        status = status or {}
        camera = status.get("camera", "Unknown")
        storage = status.get("storage", "Unknown")
        temperature = status.get("temperature", "—")
        humidity = status.get("humidity", "—")
        sun = status.get("sun_altitude", "—")
        lines = self._header("🚀", f"Hello {observer}!")
        lines += [
            "",
            "Telegram has been configured successfully.",
            "",
            "──────────────",
            f"📷 <b>Camera</b>\n{self._safe(camera)}",
            f"💾 <b>Storage</b>\n{self._safe(storage)}",
            f"🌡 <b>Temperature</b>\n{self._safe(temperature)}",
            f"💧 <b>Humidity</b>\n{self._safe(humidity)}",
            f"☀️ <b>Sun altitude</b>\n{self._safe(sun)}",
            "──────────────",
            "Have a clear sky! ✨",
        ]
        return self.send("\n".join(lines), force=True)

    def send_event(self, event: dict) -> dict:
        classification = str(event.get("classification") or "unknown").lower()
        icons = {"meteor": "☄️", "aircraft": "✈️", "unknown": "❓"}
        title = {"meteor": "Meteor detected", "aircraft": "Aircraft detected", "unknown": "Unknown event detected"}.get(classification, "Event detected")
        created = str(event.get("created_at") or "—").replace("T", " ")
        score = event.get("score", "—")
        duration = event.get("duration_seconds", "—")
        sequence = int(event.get("daily_sequence", 0) or 0)
        lines = self._header(icons.get(classification, "📡"), title)
        lines += ["", "──────────────", f"<b>Time</b>\n{self._safe(created)}"]
        if sequence:
            lines += [f"<b>Event</b>\n#{sequence:03d}"]
        lines += [
            f"<b>Classification</b>\n{self._safe(classification.title())}",
            f"<b>Score</b>\n{self._safe(score)}",
            f"<b>Duration</b>\n{self._safe(duration)} s",
            "──────────────",
            "VIGILIS",
        ]
        return self.send("\n".join(lines))

    def send_hourly_summary(self, counts: dict, start: dt.datetime, end: dt.datetime) -> dict:
        lines = self._header("🛰", "Hourly Event Summary")
        lines += [
            "",
            f"{start:%H:%M}–{end:%H:%M}",
            "",
            f"☄️ Meteors: <b>{int(counts.get('meteor', 0))}</b>",
            f"✈️ Aircraft: <b>{int(counts.get('aircraft', 0))}</b>",
            f"❓ Unknown: <b>{int(counts.get('unknown', 0))}</b>",
            "",
            "VIGILIS",
        ]
        return self.send("\n".join(lines), force=True)

    def send_daily_summary(self, counts: dict, summary_date: dt.date, extras: dict | None = None) -> dict:
        observer, _, _ = self.identity()
        extras = extras or {}
        lines = self._header("🌌", f"Good Morning {observer}!")
        lines += [
            "",
            f"<b>Daily Summary · {summary_date:%d %B %Y}</b>",
            "",
            f"☄️ Meteors: <b>{int(counts.get('meteor', 0))}</b>",
            f"✈️ Aircraft: <b>{int(counts.get('aircraft', 0))}</b>",
            f"❓ Unknown: <b>{int(counts.get('unknown', 0))}</b>",
        ]
        if extras.get("temperature") is not None:
            lines.append(f"🌡 Temperature: <b>{self._safe(extras['temperature'])}</b>")
        if extras.get("humidity") is not None:
            lines.append(f"💧 Humidity: <b>{self._safe(extras['humidity'])}</b>")
        if extras.get("storage"):
            lines.append(f"💾 Storage: <b>{self._safe(extras['storage'])}</b>")
        lines += ["", "Have a clear sky! ✨"]
        return self.send("\n".join(lines), force=True)

    def send_warning(self, warning_type: str, title: str, details: list[tuple[str, object]]) -> dict:
        lines = self._header("⚠️", title)
        lines += ["", "──────────────"]
        for label, value in details:
            lines.append(f"<b>{self._safe(label)}</b>\n{self._safe(value)}")
        lines += ["──────────────", "Please inspect the station."]
        return self.send("\n".join(lines), force=True)

    def send_media(self, path, caption: str = "") -> dict:
        path = Path(path)
        if not self.enabled() or not path.exists():
            return {"ok": False, "error": "Media file or Telegram configuration missing"}
        import uuid
        try:
            c = self._settings(); token=str(c["bot_token"]).strip(); chat=str(c["chat_id"]).strip()
            photo = path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}
            method = "sendPhoto" if photo else "sendDocument"; field = "photo" if photo else "document"
            boundary = "----VIGILIS" + uuid.uuid4().hex
            body=[]
            def add(name, value, filename=None):
                header=f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\""
                if filename: header += f"; filename=\"{filename}\""
                header += "\r\n"
                if filename: header += "Content-Type: application/octet-stream\r\n"
                body.extend([header.encode()+b"\r\n", value if isinstance(value,bytes) else str(value).encode(), b"\r\n"])
            add("chat_id",chat); add("caption",caption); add(field,path.read_bytes(),path.name); body.append(f"--{boundary}--\r\n".encode())
            req=urllib.request.Request(f"https://api.telegram.org/bot{token}/{method}",data=b"".join(body),headers={"Content-Type":f"multipart/form-data; boundary={boundary}"})
            with urllib.request.urlopen(req,timeout=120) as response: payload=json.loads(response.read().decode())
            if not payload.get("ok"): raise RuntimeError(payload.get("description","Telegram API error"))
            return {"ok":True}
        except Exception as exc:
            self.logger.warning("Telegram media send failed: %s",exc); return {"ok":False,"error":str(exc)}

    def restart_message(self) -> dict:
        observer, _, _ = self.identity()
        lines = self._header("✅", "VIGILIS restarted")
        lines += ["", f"Hello {self._safe(observer)},", "", "The VIGILIS service is online again.", "", "VIGILIS"]
        return self.send("\n".join(lines), force=True)
