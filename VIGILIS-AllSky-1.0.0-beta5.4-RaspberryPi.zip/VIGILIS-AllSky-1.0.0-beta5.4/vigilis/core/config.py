from __future__ import annotations
import copy
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
LEGACY_CONFIG_PATH = ROOT / "config.yaml"
CONFIG_PATH = ROOT / "data" / "user_config.yaml"
EXAMPLE_PATH = ROOT / "config.example.yaml"


def _merge(base: dict, override: dict) -> dict:
    result = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result


def _read_yaml(path: Path) -> dict:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def load_config() -> dict:
    """Load defaults plus the persistent user configuration.

    Since Beta 2.8 user settings live below data/, which is deliberately kept
    across application updates.  Older installations are imported once from
    the historical root-level config.yaml automatically.
    """
    base = _read_yaml(EXAMPLE_PATH)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    if CONFIG_PATH.exists():
        current = _read_yaml(CONFIG_PATH)
    elif LEGACY_CONFIG_PATH.exists():
        current = _read_yaml(LEGACY_CONFIG_PATH)
        # Import the last pre-2.8 configuration before the application starts
        # changing values. This includes Telegram credentials, camera profile,
        # cover direction/offsets, processing, overlay, location, etc.
        CONFIG_PATH.write_text(
            yaml.safe_dump(current, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
    else:
        current = {}
        CONFIG_PATH.write_text(
            yaml.safe_dump(base, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )

    return _merge(base, current)


def save_config(config: dict) -> None:
    """Persist user settings outside the replaceable application tree."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_suffix('.yaml.tmp')
    tmp.write_text(
        yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    tmp.replace(CONFIG_PATH)
