from pathlib import Path
import logging
from logging.handlers import RotatingFileHandler


def setup_logging(root: Path) -> logging.Logger:
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("vigilis")
    logger.setLevel(logging.INFO)
    if logger.handlers:
        return logger
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    user = RotatingFileHandler(log_dir / "user.log", maxBytes=1_000_000, backupCount=5)
    user.setLevel(logging.INFO)
    user.setFormatter(fmt)
    dev = RotatingFileHandler(log_dir / "developer.log", maxBytes=5_000_000, backupCount=5)
    dev.setLevel(logging.DEBUG)
    dev.setFormatter(fmt)
    logger.addHandler(user)
    logger.addHandler(dev)
    return logger
