from __future__ import annotations
from pathlib import Path
import copy, json, subprocess, threading, time, uuid, shutil, hashlib
import cv2
from datetime import datetime, timedelta
from flask import Flask, Response, jsonify, render_template, request, send_from_directory, send_file

from . import __version__
from .core.config import load_config, save_config
from .core.logging_setup import setup_logging
from .modules.camera import CameraManager
from .modules.zwo_camera import ZwoCameraBackend
from .modules.cover_service import LensCoverService
from .modules.heater import HeaterController
from .modules.schedule import SkySchedule
from .modules.allsky_capture import AllSkyCapture
from .modules.exposure_controller import ExposureController
from .modules.night_products import NightProducts
from .modules.focus_mode import FocusModeService
from .modules.sensor import SensorReader
from .modules.system_info import get_system_info
from .modules.telegram import TelegramNotifier
from .modules.lightning import LightningDetector
from .modules.overlay import apply_overlay

ROOT = Path(__file__).resolve().parents[1]
app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['MAX_CONTENT_LENGTH'] = 300 * 1024 * 1024
config = load_config(); logger = setup_logging(ROOT)
# Keep the same initialization order used by the known-good Meteor Beta 5.7
# hardware stack: camera -> cover -> sensor -> heater.  AllSky modules are
# started only after those controllers exist.
camera = CameraManager(config, logger); camera.start()
cover = LensCoverService(config, logger)
sensor = SensorReader(config, logger); sensor.start()
heater = HeaterController(config, logger)
schedule = SkySchedule(config)
exposure = ExposureController(config, camera, logger)
capture = AllSkyCapture(config, camera, schedule, ROOT, logger, exposure, cover=cover, sensor=sensor); capture.start()
focus = FocusModeService(config, camera, capture, exposure, logger)
products = NightProducts(config, ROOT, schedule, logger); products.start()
telegram = TelegramNotifier(config, ROOT, logger)
lightning = LightningDetector(config, ROOT, logger); lightning.start()


def _heater_worker():
    """Run the known-good Meteor heater controller independently of the WebUI.

    Meteor's controller logic is retained unchanged. AllSky drives its update
    method from a dedicated worker so time-window/PWM regulation continues even
    when no browser is connected and /api/status is not being polled.
    """
    while True:
        try:
            heater.auto(sensor.latest)
        except Exception:
            logger.exception('Heater regulation worker failed')
        time.sleep(0.25)

threading.Thread(target=_heater_worker, daemon=True, name='heater-regulation').start()


def _telegram_worker():
    state_path=ROOT/'data'/'telegram_state.json'; state={}
    try:
        if state_path.exists(): state=json.loads(state_path.read_text())
    except Exception: state={}
    last_camera_ok=None; alert_flags={}; time.sleep(5)
    while True:
        try:
            tg=config.get('telegram',{}); now=schedule.now(); camera_ok=bool(camera.status.get('camera_ok')); latest=ROOT/'data'/'allsky'/'latest.jpg'
            if tg.get('enabled'):
                if tg.get('send_camera_error',tg.get('send_camera_offline',True)) and last_camera_ok is True and not camera_ok: telegram.send('VIGILIS AllSky: Kamerafehler – Kamera offline.',True)
                hour_key=now.strftime('%Y-%m-%d-%H')
                if tg.get('send_hourly_image') and state.get('hourly')!=hour_key and latest.exists():
                    telegram.send_media(latest,f'Aktuelles AllSky-Bild – {now.strftime("%d.%m.%Y %H:%M")}'); state['hourly']=hour_key
                temp=sensor.latest.get('temperature_c'); hum=sensor.latest.get('humidity'); sys=get_system_info(ROOT); cpu=sys.get('cpu_percent')
                checks=[('temperature',temp,float(tg.get('temperature_high_c',45)),'Temperatur'),('humidity',hum,float(tg.get('humidity_high_percent',90)),'Luftfeuchtigkeit'),('cpu',cpu,float(tg.get('cpu_high_percent',90)),'CPU-Auslastung')]
                for key,val,limit,label in checks:
                    enabled=tg.get('send_environment_alert',True) if key in {'temperature','humidity'} else tg.get('send_cpu_alert',True)
                    high=val is not None and float(val)>=limit
                    if enabled and high and not alert_flags.get(key): telegram.send(f'VIGILIS Warnung: {label} zu hoch ({val}, Grenzwert {limit}).',True)
                    alert_flags[key]=high
                if tg.get('send_morning_products',True) and 5<=now.hour<=11:
                    yesterday=(now-timedelta(hours=12)).date(); day=ROOT/str(config.get('capture',{}).get('archive_path','allsky'))/yesterday.strftime('%Y/%m/%d')/'Nacht'; morning_key=yesterday.isoformat()
                    if state.get('morning')!=morning_key and day.exists():
                        product_dir=day/'products' if (day/'products').exists() else day
                        clean=product_dir/'startrail_clean.jpg'
                        if not clean.exists(): clean=product_dir/'startrail.jpg'
                        if clean.exists():
                            frames=_session_frames(yesterday)
                            frame_times=[]
                            for f in frames:
                                raw,_=_image_meta(f)
                                try: frame_times.append(datetime.fromisoformat(raw))
                                except Exception: pass
                            start=min(frame_times) if frame_times else None; end=max(frame_times) if frame_times else None
                            hist,_,_=sensor.history_range(yesterday,yesterday+timedelta(days=1),max_points=5000)
                            if start and end:
                                lo,hi=start.timestamp(),end.timestamp()
                                hist=[x for x in hist if lo <= float(x.get('timestamp',0) or 0) <= hi]
                            temps=[float((x.get('dome') or {}).get('temperature_c')) for x in hist if isinstance((x.get('dome') or {}).get('temperature_c'),(int,float))]
                            hums=[float((x.get('dome') or {}).get('humidity')) for x in hist if isinstance((x.get('dome') or {}).get('humidity'),(int,float))]
                            lines=['Good morning, observer. VIGILIS has prepared a summary of last night.','']
                            lines.append(f'Frames: {len(frames)}')
                            if start and end: lines.append(f'Start / End: {start.strftime("%H:%M")} – {end.strftime("%H:%M")}')
                            if temps: lines.append(f'Temperature: {min(temps):.1f}–{max(temps):.1f} °C')
                            if hums: lines.append(f'Max humidity: {max(hums):.1f} %')
                            result=telegram.send_media(clean,'\n'.join(lines))
                            if result.get('ok'): state['morning']=morning_key
                state_path.parent.mkdir(parents=True,exist_ok=True); state_path.write_text(json.dumps(state))
            last_camera_ok=camera_ok
        except Exception: logger.exception('Telegram status worker failed')
        time.sleep(30)

threading.Thread(target=_telegram_worker, daemon=True, name='telegram-worker').start()
if config.get('telegram', {}).get('enabled') and config.get('telegram', {}).get('send_restart', True):
    threading.Thread(target=lambda: (time.sleep(8), telegram.send('VIGILIS AllSky restarted.', force=True)), daemon=True).start()


def _lightning_telegram_worker():
    last_event_id=0; last_sent_at=0.0; last_sent_distance=None
    while True:
        try:
            st=lightning.latest; event_id=int(st.get('event_id') or 0)
            if event_id and event_id != last_event_id:
                last_event_id=event_id
                lc=config.get('lightning',{}) or {}; tg=config.get('telegram',{}) or {}
                mode=str(lc.get('notification_mode','off')).lower()
                distance=st.get('distance_km')
                threshold=float(lc.get('notify_distance_km',20))
                qualifies=distance is not None and float(distance) <= threshold
                if tg.get('enabled') and mode=='immediately' and qualifies:
                    now=time.time(); cooldown=max(0,float(lc.get('cooldown_minutes',5))*60)
                    drop=max(0,float(lc.get('override_distance_drop_km',10)))
                    critical=float(lc.get('override_critical_distance_km',5))
                    override=(distance is not None and float(distance)<=critical) or (
                        distance is not None and last_sent_distance is not None and float(last_sent_distance)-float(distance)>=drop)
                    if now-last_sent_at>=cooldown or override:
                        lines=['⚡ <b>Lightning detected</b>',f'Distance: <b>{float(distance):g} km</b>']
                        closest=st.get('closest_today_km')
                        if closest is not None: lines.append(f'Closest today: {float(closest):g} km')
                        if lc.get('include_relative_energy',True) and st.get('relative_energy') is not None:
                            lines.append(f'Relative energy: {st.get("relative_energy")}')
                        lines.append(f'Time: {datetime.fromtimestamp(float(st.get("last_strike_at") or now)).strftime("%H:%M:%S")}')
                        if override and now-last_sent_at<cooldown: lines.append('⚠️ Cooldown override: strike moved significantly closer')
                        result=telegram.send('\n'.join(lines),force=True)
                        if result.get('ok'):
                            last_sent_at=now; last_sent_distance=float(distance)
        except Exception:
            logger.exception('Lightning Telegram worker failed')
        time.sleep(1.0)

threading.Thread(target=_lightning_telegram_worker,daemon=True,name='lightning-telegram').start()



def _background_path():
    raw = str(config.get('ui', {}).get('background_image', '/static/background.jpg'))
    if raw.startswith('/static/'):
        return ROOT / 'vigilis' / 'static' / raw.removeprefix('/static/')
    return ROOT / raw.lstrip('/')


def _background_url():
    p = _background_path()
    if p.exists() and 'data/backgrounds' in p.as_posix():
        return f'/ui-background/{p.name}?v={int(p.stat().st_mtime)}'
    raw = str(config.get('ui', {}).get('background_image', '/static/background.jpg'))
    if raw.startswith('/static/'):
        return f'{raw}?v={int(p.stat().st_mtime) if p.exists() else 0}'
    return '/static/background.jpg'


def snapshot():
    try: heater.auto(sensor.latest)
    except Exception: pass
    cfg = dict(config); cfg['ui'] = dict(config.get('ui', {})); cfg['ui']['background_url'] = _background_url()
    return {
        'product': 'VIGILIS AllSky', 'version': __version__, 'schedule': schedule.status(),
        'capture': capture.status, 'exposure': exposure.status, 'focus': focus.snapshot(), 'products': products.status, 'camera': camera.status, 'cover': cover.status(),
        'sensor': sensor.latest, 'heater': heater.status(), 'lightning': lightning.latest, 'system': get_system_info(ROOT), 'config': cfg,
    }


@app.get('/')
def home(): return render_template('index.html', version=__version__, config=config, background_url=_background_url())
@app.get('/api/status')
def status(): return jsonify(snapshot())

@app.get('/api/environment/history')
def environment_history():
    range_key=str(request.args.get('range','7d')).lower()
    days={'24h':2,'1d':1,'7d':7,'30d':30,'6m':183,'1y':365}.get(range_key,7)
    end=schedule.now().date(); start=end-timedelta(days=days-1)
    samples,stats,total=sensor.history_range(start,end,max_points=1400)
    if range_key=='24h':
        cutoff=schedule.now().timestamp()-86400
        samples=[x for x in samples if float(x.get('timestamp',0) or 0)>=cutoff]
    return jsonify({'ok':True,'range':range_key,'start':start.isoformat(),'end':end.isoformat(),'samples':samples,'stats':stats,'raw_points':total})

@app.get('/api/lightning/history')
def lightning_history():
    return jsonify(lightning.history_range(str(request.args.get('range','24h')).lower()))


@app.get('/api/cameras')
@app.get('/api/camera/scan')
def cameras_discover():
    result = {'active': config.get('camera', {}).get('mode', 'auto'), 'csi': {'available': False}, 'zwo': ZwoCameraBackend.discover()}
    try:
        from picamera2 import Picamera2
        cams = Picamera2.global_camera_info(); result['csi'] = {'available': bool(cams), 'cameras': cams}
    except Exception as exc:
        result['csi'] = {'available': False, 'error': str(exc)}
    return jsonify(result)

@app.get('/api/camera/zwo/health')
def zwo_health():
    info = ZwoCameraBackend.discover(); return jsonify({'ok': bool(info.get('cameras')), 'zwo': info})

@app.get('/media/<path:name>')
def media(name): return send_from_directory(ROOT, name)
@app.get('/ui-background/<path:name>')
def ui_background(name): return send_from_directory(ROOT / 'data' / 'backgrounds', name, max_age=0)
@app.get('/allsky/latest')
def latest_allsky():
    folder = ROOT / 'data' / 'allsky'
    for name in ('latest.jpg', 'latest.png'):
        if (folder / name).exists():
            return send_from_directory(folder, name, max_age=0)
    # Before the first archived AllSky exposure, show the most recent camera
    # frame instead of an empty Home card. This fallback is never archived and
    # does not count as a Day Capture. With a closed lens cover it will,
    # naturally, show the covered camera.
    jpg = camera.jpeg(720)
    return Response(jpg, mimetype='image/jpeg', headers={'Cache-Control':'no-store'}) if jpg else ('', 204)

@app.get('/video_feed')
def video_feed():
    if not focus.active: return ('', 204)
    height=max(240,min(1080,int(request.args.get('height',720))))
    zoom=float(request.args.get('zoom',1)); crosshair=request.args.get('crosshair','0')=='1'
    def gen():
        while focus.active:
            jpg=focus.frame_jpeg(height,zoom,crosshair)
            if jpg: yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n'+jpg+b'\r\n'
            time.sleep(0.08)
    return Response(gen(),mimetype='multipart/x-mixed-replace; boundary=frame')

@app.post('/api/focus/start')
def focus_start():
    d=request.get_json(silent=True) or {}
    return jsonify({'ok':True,'focus':focus.start(d.get('exposure_ms',20),d.get('gain'))})

@app.post('/api/focus/update')
def focus_update():
    d=request.get_json(silent=True) or {}
    try: return jsonify({'ok':True,'focus':focus.update(d.get('exposure_ms'),d.get('gain'))})
    except Exception as exc: return jsonify({'ok':False,'error':str(exc)}),400

@app.post('/api/focus/heartbeat')
def focus_heartbeat():
    if focus.active: focus.heartbeat()
    return jsonify({'ok':True,'focus':focus.snapshot()})

@app.post('/api/focus/stop')
def focus_stop(): return jsonify({'ok':True,'focus':focus.stop('navigation')})

@app.post('/api/settings')
def settings():
    data = request.get_json(force=True) or {}
    allowed = {'app','location','camera','capture','gpio','cover','heater','sensor','telegram','storage','ui','updates','processing','focus','overlay','lightning'}

    # Compare GPIO values before mutating the live config. Merely submitting the
    # existing GPIO section must never force a restart. Only an actual pin change
    # requires reinitialising gpiozero/libcamera-owned hardware resources.
    old_gpio = dict(config.get('gpio', {}) or {})
    old_sensor = dict(config.get('sensor', {}) or {})
    old_lightning = dict(config.get('lightning', {}) or {})
    submitted_gpio = data.get('gpio') if isinstance(data.get('gpio'), dict) else {}
    gpio_changed = [
        key for key, value in submitted_gpio.items()
        if old_gpio.get(key) != value
    ]

    for section, values in data.items():
        if section in allowed and section in config and isinstance(values, dict) and isinstance(config[section], dict):
            config[section].update(values)
    save_config(config)
    # Environment/Heater uses the Meteor controller unchanged. Apply a new
    # heater setting immediately instead of waiting for the next UI refresh.
    if 'heater' in data:
        try:
            heater.auto(sensor.latest)
        except Exception:
            logger.exception('Failed to apply heater settings immediately')
    wb_result = None
    if 'camera' in data and any(k in data.get('camera', {}) for k in {'uv_ir_filter','white_balance_mode','awb_enabled','white_balance_red_gain','white_balance_blue_gain'}):
        wb_result = camera.apply_white_balance()
    # Normal Lens Cover parameters are read from the shared config at movement
    # time and therefore apply immediately. A restart is required only for
    # actual GPIO pin changes or camera properties that require reinitialisation.
    camera_restart_keys={'mode','device','auto_max_resolution','sensor_binning','zwo_bin','pixel_format','width','height'}
    camera_changed = bool(camera_restart_keys.intersection((data.get('camera') or {}).keys()))
    sensor_restart_keys={'dht22_enabled','dome_sensor_enabled','dome_sensor_type','dome_uart_port','dome_uart_baud','outdoor_dht22_enabled','outdoor_sensor_enabled','outdoor_sensor_type','outdoor_uart_port','outdoor_uart_baud'}
    submitted_sensor = data.get('sensor') if isinstance(data.get('sensor'), dict) else {}
    sensor_changed = any(key in sensor_restart_keys and old_sensor.get(key) != value for key, value in submitted_sensor.items())
    submitted_lightning = data.get('lightning') if isinstance(data.get('lightning'), dict) else {}
    lightning_restart_keys={'enabled','uart_port','uart_baud','sensor_type'}
    lightning_changed = any(key in lightning_restart_keys and old_lightning.get(key) != value for key, value in submitted_lightning.items())
    restart_required = bool(gpio_changed) or camera_changed or sensor_changed or lightning_changed
    restart_reason = 'gpio' if gpio_changed else ('camera' if camera_changed else ('sensor' if sensor_changed else ('lightning' if lightning_changed else None)))
    return jsonify({
        'ok': True,
        'restart_required': restart_required,
        'restart_type': 'service' if restart_required else None,
        'restart_reason': restart_reason,
        'gpio_changed': gpio_changed,
        'white_balance': wb_result,
    })

@app.post('/api/cover/<action>')
def cover_action(action):
    if action == 'open': return jsonify(cover.move_to('open', source='manual'))
    if action == 'close': return jsonify(cover.move_to('closed', source='manual'))
    if action == 'stop': return jsonify(cover.stop(source='manual'))
    return jsonify({'ok': False, 'error': 'unknown action'}), 400


@app.post('/api/quick-capture')
def quick_capture_action():
    result=capture.quick_capture()
    return jsonify(result), (200 if result.get('ok') else 409)

@app.post('/api/overlay/preview')
def overlay_preview_exact():
    """Render the editor preview with the exact same OpenCV renderer used for archives."""
    payload=request.get_json(silent=True) or {}
    overlay=payload.get('overlay') if isinstance(payload.get('overlay'),dict) else {}
    # Editor preview must use the same last captured image shown on Home.
    # Do NOT trigger/read a fresh camera frame merely by opening the editor.
    latest_folder=ROOT/'data'/'allsky'
    source_path=latest_folder/'latest_source.jpg'
    frame=cv2.imread(str(source_path),cv2.IMREAD_COLOR) if source_path.exists() else None
    if frame is None:
        # No separate camera exposure is started for the editor. The source file
        # appears automatically after the next real Day/Night/Quick Capture.
        return ('',204)
    preview_cfg=copy.deepcopy(config)
    preview_cfg['overlay']=overlay
    rendered=apply_overlay(frame,preview_cfg,schedule.now(),schedule,exposure,camera,sensor)
    max_width=max(480,min(1600,int(payload.get('max_width',1000) or 1000)))
    h,w=rendered.shape[:2]
    if w>max_width:
        scale=max_width/float(w); rendered=cv2.resize(rendered,(max_width,max(1,int(h*scale))),interpolation=cv2.INTER_AREA)
    ok,data=cv2.imencode('.jpg',rendered,[int(cv2.IMWRITE_JPEG_QUALITY),90])
    return Response(data.tobytes(),mimetype='image/jpeg',headers={'Cache-Control':'no-store'}) if ok else ('',500)

@app.post('/api/heater/<mode>')
def heater_action(mode):
    if mode not in {'on','off','auto'}: return jsonify({'ok': False}), 400
    config['heater']['mode'] = mode; save_config(config)
    if mode == 'auto':
        heater.auto(sensor.latest)
        return jsonify({'ok': True, 'mode': mode, **heater.status()})
    return jsonify({'ok': True, 'mode': mode, **heater.set(mode == 'on')})


@app.get('/api/overlay/assets')
def overlay_assets():
    folder=ROOT/'data'/'overlay_assets'; folder.mkdir(parents=True,exist_ok=True)
    items=[]
    for f in sorted(folder.glob('*.png')):
        items.append({'name':f.name,'url':f'/overlay-asset/{f.name}?v={int(f.stat().st_mtime)}'})
    return jsonify({'ok':True,'assets':items})

@app.get('/overlay-asset/<path:name>')
def overlay_asset(name):
    return send_from_directory(ROOT/'data'/'overlay_assets',Path(name).name,max_age=0)

@app.post('/api/overlay/assets')
def overlay_asset_upload():
    f=request.files.get('asset')
    if not f or not f.filename: return jsonify({'ok':False,'error':'PNG file required'}),400
    if Path(f.filename).suffix.lower()!='.png': return jsonify({'ok':False,'error':'Only PNG is supported for overlay images'}),400
    folder=ROOT/'data'/'overlay_assets'; folder.mkdir(parents=True,exist_ok=True)
    safe='overlay_'+uuid.uuid4().hex[:10]+'.png'; dest=folder/safe; f.save(dest)
    img=cv2.imread(str(dest),cv2.IMREAD_UNCHANGED)
    if img is None:
        dest.unlink(missing_ok=True); return jsonify({'ok':False,'error':'Invalid PNG'}),400
    return jsonify({'ok':True,'name':safe,'url':f'/overlay-asset/{safe}'})

@app.post('/api/ui/background')
def background():
    f = request.files.get('background')
    if not f: return jsonify({'ok': False, 'error': 'no file'}), 400
    ext = (f.filename.rsplit('.', 1)[-1] if '.' in f.filename else 'jpg').lower()
    if ext not in {'jpg','jpeg','png','webp'}: return jsonify({'ok': False, 'error': 'unsupported'}), 400
    folder = ROOT / 'data' / 'backgrounds'; folder.mkdir(parents=True, exist_ok=True)
    for old in folder.glob('background.*'):
        try: old.unlink()
        except OSError: pass
    dest = folder / f'background.{ext}'; f.save(dest)
    config['ui']['background_image'] = str(dest.relative_to(ROOT)); save_config(config)
    return jsonify({'ok': True, 'url': _background_url()})

@app.get('/api/logs/<kind>')
def logs(kind):
    p = ROOT / 'logs' / ('developer.log' if kind == 'developer' else 'user.log')
    return jsonify({'lines': p.read_text(errors='replace').splitlines()[-300:] if p.exists() else []})


def _delayed_system_command(command):
    def run():
        time.sleep(0.8)
        try: subprocess.Popen(command)
        except Exception: logger.exception('System command failed: %s', command)
    threading.Thread(target=run, daemon=True).start()

@app.post('/api/system/<action>')
def system_action(action):
    commands = {'restart-service':['sudo','systemctl','restart','vigilis.service'], 'reboot':['sudo','systemctl','reboot'], 'shutdown':['sudo','systemctl','poweroff']}
    if action not in commands: return jsonify({'ok': False, 'error': 'unknown system action'}), 400
    _delayed_system_command(commands[action]); return jsonify({'ok': True, 'action': action})

@app.post('/api/telegram/test')
def telegram_test(): return jsonify(telegram.test())

@app.post('/api/zwo/fix-permissions')
def zwo_fix_permissions():
    try:
        result = subprocess.run(['sudo','/usr/local/sbin/vigilis-zwo-permissions'], capture_output=True, text=True, timeout=30)
        if result.returncode != 0: raise RuntimeError((result.stderr or result.stdout or 'Permission helper failed').strip())
        return jsonify({'ok': True, 'message': 'ZWO USB permissions installed. Reconnect the camera once.'})
    except Exception as exc: return jsonify({'ok': False, 'error': str(exc)}), 400

@app.get('/api/update/developer-mode')
def developer_update_mode_status():
    try:
        result = subprocess.run(['sudo','/usr/local/sbin/vigilis-dev-update-mode','status'], capture_output=True, text=True, timeout=10, check=True)
        return jsonify(json.loads(result.stdout.strip()))
    except Exception as exc: return jsonify({'ok': False, 'enabled': False, 'error': str(exc)}), 500

@app.post('/api/update/developer-mode')
def developer_update_mode_set():
    enabled = bool((request.get_json(silent=True) or {}).get('enabled', False))
    try:
        result = subprocess.run(['sudo','/usr/local/sbin/vigilis-dev-update-mode','enable' if enabled else 'disable'], capture_output=True, text=True, timeout=10, check=True)
        config.setdefault('updates', {})['allow_unsigned_developer_updates'] = enabled; save_config(config)
        return jsonify(json.loads(result.stdout.strip()))
    except Exception as exc: return jsonify({'ok': False, 'error': str(exc)}), 400

@app.post('/api/update/upload')
def update_upload():
    f = request.files.get('update')
    if not f or not f.filename: return jsonify({'ok': False, 'error': 'No update package selected'}), 400
    if not f.filename.lower().endswith('.vup'): return jsonify({'ok': False, 'error': 'Only signed VIGILIS .vup packages are accepted'}), 400
    folder = ROOT / 'data' / 'updates' / 'incoming'; folder.mkdir(parents=True, exist_ok=True)
    dest = folder / f'{uuid.uuid4().hex}.vup'; f.save(dest)
    try:
        check = subprocess.run(['sudo','/usr/local/sbin/vigilis-update-helper','--verify-only',str(dest)], capture_output=True, text=True, timeout=60)
        if check.returncode != 0: raise RuntimeError((check.stderr or check.stdout or 'Package verification failed').strip())
        info = json.loads(check.stdout.strip().splitlines()[-1])
        subprocess.run(['sudo','/usr/local/sbin/vigilis-update-launcher',str(dest)], capture_output=True, text=True, timeout=20, check=True)
        return jsonify({'ok': True, 'version': info.get('version'), 'trust': info.get('trust','signed'), 'message': 'Installation started'})
    except Exception as exc:
        try: dest.unlink()
        except OSError: pass
        return jsonify({'ok': False, 'error': str(exc)}), 400


def _archive_base():
    return (ROOT/str(config.get('capture',{}).get('archive_path','allsky'))).resolve()


def _image_meta(path: Path):
    captured_at=None; exposure=None
    side=path.with_suffix('.json')
    if side.exists():
        try:
            meta=json.loads(side.read_text())
            captured_at=meta.get('captured_at'); exposure=meta.get('exposure_seconds')
        except Exception:
            pass
    if not captured_at:
        try: captured_at=datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat()
        except Exception: captured_at=''
    return captured_at, exposure


def _night_anchor(captured_at, fallback_day):
    try:
        dt=datetime.fromisoformat(captured_at)
        return dt.date()-timedelta(days=1) if dt.hour<12 else dt.date()
    except Exception:
        return fallback_day


def _session_frames(anchor_day):
    """Return all night frames belonging to one sunset->sunrise session.

    This also merges legacy Beta 2.1 files that were physically split at
    midnight into two calendar-day directories.
    """
    base=_archive_base(); out=[]
    if not base.exists(): return out
    for folder in base.glob('*/*/*/Nacht'):
        try: fallback=datetime.strptime('/'.join(folder.parts[-4:-1]),'%Y/%m/%d').date()
        except Exception: continue
        image_dir=folder/'images' if (folder/'images').exists() else folder
        for x in [*image_dir.glob('*.jpg'),*image_dir.glob('*.jpeg'),*image_dir.glob('*.png')]:
            if x.name in {'startrails.jpg','startrail.jpg','keogram.jpg'}: continue
            captured_at,_=_image_meta(x)
            if _night_anchor(captured_at,fallback)==anchor_day: out.append(x)
    def sort_key(path):
        captured,_=_image_meta(path)
        try: return datetime.fromisoformat(captured).timestamp()
        except Exception:
            try: return path.stat().st_mtime
            except Exception: return 0
    return sorted(out,key=sort_key)


@app.get('/api/gallery')
def gallery():
    base=_archive_base(); sessions={}; day_archives=[]
    if base.exists():
        # Night sessions are grouped by observation night, not midnight.
        for folder in base.glob('*/*/*/Nacht'):
            try: fallback=datetime.strptime('/'.join(folder.parts[-4:-1]),'%Y/%m/%d').date()
            except Exception: continue
            image_dir=folder/'images' if (folder/'images').exists() else folder
            for x in [*image_dir.glob('*.jpg'),*image_dir.glob('*.jpeg'),*image_dir.glob('*.png')]:
                if x.name in {'startrails.jpg','startrail.jpg','keogram.jpg'}: continue
                captured_at,exposure=_image_meta(x); anchor=_night_anchor(captured_at,fallback)
                entry=sessions.setdefault(anchor,{'image_count':0,'source_dirs':set()})
                entry['source_dirs'].add(folder)
                entry['image_count']+=1

        # Optional day captures remain normal calendar-day archives.
        for folder in sorted(base.glob('*/*/*/Tag'),reverse=True):
            image_dir=folder/'images' if (folder/'images').exists() else folder
            images=[x for x in [*image_dir.glob('*.jpg'),*image_dir.glob('*.jpeg'),*image_dir.glob('*.png')] if x.name not in {'startrails.jpg','startrail.jpg','keogram.jpg'}]
            if images:
                try: day=datetime.strptime('/'.join(folder.parts[-4:-1]),'%Y/%m/%d').date()
                except Exception: continue
                day_archives.append({'kind':'day','date':day.isoformat(),'label':day.strftime('%d.%m.%Y')+' · Tag','image_count':len(images)})

    result=[]
    aliases={
        'timelapse':('timelapse.mp4',),
        'keogram':('keogram.jpg',),
        'startrail_clean':('startrail_clean.jpg','startrail.jpg','startrails.jpg'),
        'startrail_full':('startrail_full.jpg','startrails_full.jpg'),
        'startrail':('startrail_clean.jpg','startrail.jpg','startrails.jpg'),
        'startrail_video':('startrail.mp4','startrails.mp4'),
    }
    for anchor,entry in sorted(sessions.items(),reverse=True):
        canonical=base/anchor.strftime('%Y/%m/%d')/'Nacht'
        search_dirs=[canonical/'products',canonical]
        for d in entry['source_dirs']:
            search_dirs.extend([d/'products',d])
        products_map={}
        for key,names in aliases.items():
            found=None
            for d in search_dirs:
                for name in names:
                    if (d/name).exists(): found=d/name; break
                if found: break
            products_map[key]={'exists':bool(found),'name':found.name if found else names[0],
                               'path':str(found.relative_to(base)) if found else None}
        result.append({'kind':'night','date':anchor.isoformat(),
                       'label':f'{anchor.strftime("%d.%m.%Y")}–{(anchor+timedelta(days=1)).strftime("%d.%m.%Y")}',
                       'image_count':entry['image_count'],'products':products_map})
    result.extend(day_archives)
    result.sort(key=lambda x:x['date'],reverse=True)
    return jsonify({'sessions':result[:120]})



@app.get('/api/gallery/images')
def gallery_images():
    """Return one small page of image metadata for a gallery session."""
    base=_archive_base()
    try:
        day=datetime.strptime(str(request.args.get('date','')),'%Y-%m-%d').date()
    except Exception:
        return jsonify({'ok':False,'error':'Invalid date'}),400
    kind=str(request.args.get('kind','night')).lower()
    try:
        offset=max(0,int(request.args.get('offset',0)))
        limit=max(1,min(100,int(request.args.get('limit',50))))
    except Exception:
        offset,limit=0,50
    if kind=='night':
        files=_session_frames(day)
    else:
        folder=products._period_dir(day,'Tag')
        src=folder/'images' if (folder/'images').exists() else folder
        files=[*src.glob('*.jpg'),*src.glob('*.jpeg'),*src.glob('*.png')] if src.exists() else []
        def day_sort_key(path):
            captured,_=_image_meta(path)
            try: return datetime.fromisoformat(captured).timestamp()
            except Exception:
                try: return path.stat().st_mtime
                except Exception: return 0
        files=sorted(files,key=day_sort_key)
    # newest first in the UI; night frames are already sorted by captured_at.
    files=list(reversed(files))
    chunk=files[offset:offset+limit]
    items=[]
    for x in chunk:
        captured_at,exposure=_image_meta(x)
        items.append({'name':x.name,'path':str(x.relative_to(base)),'captured_at':captured_at,'exposure_seconds':exposure})
    return jsonify({'ok':True,'images':items,'offset':offset,'limit':limit,'total':len(files),'has_more':offset+len(items)<len(files)})


def _safe_gallery_target(rel):
    base=_archive_base()
    target=(base/str(rel or '')).resolve()
    try:
        target.relative_to(base)
    except ValueError:
        return base, None
    return base, target


@app.get('/api/gallery/preview')
def gallery_preview():
    """Fast JPEG preview for gallery thumbnails and the mobile viewer.

    Full-resolution 4056x3040 files are deliberately not decoded by every
    browser thumbnail.  A cached, bounded preview also fixes Safari stalls on
    large night archives.
    """
    base,target=_safe_gallery_target(request.args.get('path',''))
    if target is None or not target.is_file(): return ('',404)
    try:
        max_px=max(240,min(2560,int(request.args.get('max',1800))))
    except Exception:
        max_px=1800
    stamp=f'{target}:{target.stat().st_mtime_ns}:{target.stat().st_size}:{max_px}'.encode()
    cache=ROOT/'data'/'gallery_cache'; cache.mkdir(parents=True,exist_ok=True)
    cached=cache/(hashlib.sha1(stamp).hexdigest()+'.jpg')
    if not cached.exists():
        img=cv2.imread(str(target),cv2.IMREAD_COLOR)
        if img is None: return ('',415)
        h,w=img.shape[:2]; scale=min(1.0,float(max_px)/max(w,h))
        if scale<1.0:
            img=cv2.resize(img,(max(1,int(w*scale)),max(1,int(h*scale))),interpolation=cv2.INTER_AREA)
        ok,data=cv2.imencode('.jpg',img,[int(cv2.IMWRITE_JPEG_QUALITY),88])
        if not ok: return ('',500)
        tmp=cached.with_suffix('.tmp'); tmp.write_bytes(data.tobytes()); tmp.replace(cached)
    return send_file(cached,mimetype='image/jpeg',conditional=True,max_age=86400)

@app.get('/api/gallery/file')
def gallery_file_query():
    base,target=_safe_gallery_target(request.args.get('path',''))
    if target is None or not target.is_file(): return ('',404)
    download=str(request.args.get('download','0')).lower() in {'1','true','yes'}
    mime='video/mp4' if target.suffix.lower()=='.mp4' else None
    response=send_file(target,mimetype=mime,conditional=True,max_age=0,as_attachment=download,download_name=target.name if download else None)
    response.headers['Accept-Ranges']='bytes'
    if not download: response.headers['Cache-Control']='no-store'
    return response


@app.get('/gallery/<path:subpath>')
def gallery_file(subpath):
    # Backward-compatible route for existing bookmarks.
    base=_archive_base(); target=(base/subpath).resolve()
    if base not in target.parents or not target.is_file(): return ('',403)
    return send_file(target,conditional=True,max_age=0)

@app.delete('/api/gallery/image')
def gallery_delete_image():
    base=(ROOT/str(config.get('capture',{}).get('archive_path','allsky'))).resolve(); rel=str((request.get_json(silent=True) or {}).get('path','')); target=(base/rel).resolve()
    if base not in target.parents or not target.is_file(): return jsonify({'ok':False,'error':'Invalid file'}),400
    side=target.with_suffix('.json'); target.unlink()
    if side.exists(): side.unlink()
    return jsonify({'ok':True})

@app.delete('/api/gallery/images')
def gallery_delete_images():
    payload=request.get_json(silent=True) or {}
    paths=payload.get('paths') or []
    if not isinstance(paths,list) or not paths: return jsonify({'ok':False,'error':'No images selected'}),400
    deleted=0
    for rel in paths[:500]:
        base,target=_safe_gallery_target(rel)
        if target is None or not target.is_file(): continue
        if target.suffix.lower() not in {'.jpg','.jpeg','.png'}: continue
        try:
            side=target.with_suffix('.json'); target.unlink(); deleted+=1
            if side.exists(): side.unlink()
        except OSError: pass
    return jsonify({'ok':True,'deleted':deleted})


@app.delete('/api/gallery/product')
def gallery_delete_product():
    base,target=_safe_gallery_target((request.get_json(silent=True) or {}).get('path',''))
    if target is None or not target.is_file(): return jsonify({'ok':False,'error':'Invalid product'}),400
    target.unlink()
    return jsonify({'ok':True})


@app.delete('/api/gallery/session')
def gallery_delete_session():
    payload=request.get_json(silent=True) or {}
    kind=str(payload.get('kind','night'))
    try: day=datetime.strptime(str(payload.get('date')),'%Y-%m-%d').date()
    except Exception: return jsonify({'ok':False,'error':'Invalid date'}),400
    if kind=='night':
        for frame in _session_frames(day):
            try:
                side=frame.with_suffix('.json'); frame.unlink()
                if side.exists(): side.unlink()
            except FileNotFoundError: pass
        canonical=products._night_dir(day)
        if (canonical/'products').exists(): shutil.rmtree(canonical/'products',ignore_errors=True)
        for name in ('timelapse.mp4','keogram.jpg','startrail.jpg','startrails.jpg','startrail.mp4','startrails.mp4'):
            try: (canonical/name).unlink()
            except FileNotFoundError: pass
        marker=ROOT/'data'/'products'/f'{day.isoformat()}-nacht.done'
        try: marker.unlink()
        except FileNotFoundError: pass
    else:
        d=products._period_dir(day,'Tag')
        shutil.rmtree(d,ignore_errors=True)
        marker=ROOT/'data'/'products'/f'{day.isoformat()}-tag.done'
        try: marker.unlink()
        except FileNotFoundError: pass
    return jsonify({'ok':True})


@app.delete('/api/gallery/folder')
def gallery_delete_folder():
    base=(ROOT/str(config.get('capture',{}).get('archive_path','allsky'))).resolve(); rel=str((request.get_json(silent=True) or {}).get('path','')); target=(base/rel).resolve()
    if base not in target.parents or not target.is_dir(): return jsonify({'ok':False,'error':'Invalid folder'}),400
    shutil.rmtree(target); return jsonify({'ok':True})

@app.post('/api/processing/run')
def processing_run():
    payload=request.get_json(silent=True) or {}
    if payload.get('session_date'):
        day=datetime.strptime(payload['session_date'],'%Y-%m-%d').date()
        d=products._night_dir(day); frames=_session_frames(day)
    else:
        rel=payload.get('path')
        if rel: d=ROOT/str(config.get('capture',{}).get('archive_path','allsky'))/rel
        else: d=products._night_dir(datetime.strptime(payload.get('date'),'%Y-%m-%d').date())
        frames=products._frames(d)
    if len(frames)<2:return jsonify({'ok':False,'error':'Not enough images'}),400
    if products.status.get('running'): return jsonify({'ok':False,'error':'Processing is already running'}),409
    only=payload.get('product')
    if only not in (None,'','timelapse','keogram','startrail','startrail_clean','startrail_full','startrail_video'):
        return jsonify({'ok':False,'error':'Invalid product'}),400
    threading.Thread(target=products.process,args=(d,frames,only or None),daemon=True).start();return jsonify({'ok':True,'product':only or 'all'})


def _cleanup_worker():
    while True:
        try:
            days=max(1,int(config.get('storage',{}).get('retention_days',7))); base=ROOT/str(config.get('capture',{}).get('archive_path','allsky')); cutoff=schedule.now().date()-timedelta(days=days)
            if base.exists():
                for d in [p for p in base.glob('*/*/*') if p.is_dir()]:
                    try:
                        date=datetime.strptime('-'.join(d.parts[-3:]),'%Y-%m-%d').date()
                        if date<cutoff: shutil.rmtree(d)
                    except Exception: pass
        except Exception: logger.exception('Retention cleanup failed')
        time.sleep(3600)
threading.Thread(target=_cleanup_worker,daemon=True,name='retention-cleanup').start()

def main(): app.run(host=config['app']['host'], port=int(config['app']['port']), debug=bool(config['app'].get('debug', False)), threaded=True)
if __name__ == '__main__': main()
