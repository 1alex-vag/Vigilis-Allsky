# VIGILIS 1.0 Beta 1

- Protected Favorites archive; favorites survive day deletion and automatic cleanup.
- Selectable recording location for internal storage, USB SSDs and HDDs.
- Multi-select and bulk event deletion.
- Delete complete day folders while preserving favorites.
- Automatic event cleanup after 1, 3, 7, 14 or 30 days.
- Configurable detection-overlay margin.
- VIGILIS Event Stack export for a complete observation night.
- Existing RC7 event grouping and overlay-video export retained.
