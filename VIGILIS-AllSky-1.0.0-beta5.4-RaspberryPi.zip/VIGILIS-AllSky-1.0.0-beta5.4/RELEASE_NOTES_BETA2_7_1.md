# VIGILIS AllSky 1.0.0 Beta 2.7.1

- Moved Night noise reduction from Automatic processing to Camera & Capture.
- Camera save now stores the selected night noise-reduction level together with the camera/capture settings.
- Automatic processing no longer owns or overwrites the noise-reduction control.
- No camera, cover, heater, Telegram, gallery, or product-processing behavior otherwise changed.
