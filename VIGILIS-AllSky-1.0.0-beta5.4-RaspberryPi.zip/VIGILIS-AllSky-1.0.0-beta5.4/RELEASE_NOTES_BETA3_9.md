# VIGILIS AllSky 1.0.0 Beta 3.9

## Daylight exposure stabilization

- Day Auto Exposure now uses the real libcamera sensor minimum exposure instead of an artificial 100 us floor.
- The final daylight frame is gated by both request metadata and highlight clipping before it can be archived.
- Stable day frames are checked at the 98th percentile and clipped-pixel ratio; over-bright frames remain internal calibration frames and trigger another exposure reduction.
- Quick Capture Auto uses the same final daylight validation path as scheduled Day Capture.
- Gain remains at the configured minimum during daylight calibration.
- If the physical sensor minimum is reached, VIGILIS logs that fact and returns the best physically achievable frame rather than looping indefinitely.

This build specifically targets the broad white solar/cloud clipping seen in Beta 3.8 daytime captures.
