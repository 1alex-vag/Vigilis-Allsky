# VIGILIS AllSky 1.0.0 Beta 4.4

## SHT31 + RP2040 UART environment sensor
- Adds an Outdoor sensor type selector: DHT22 or SHT31 via RP2040 (UART).
- Default UART device: `/dev/ttyAMA4`, 9600 baud.
- Parses the proven RP2040 packet format `VIGILIS,T=18.42,H=76.31`.
- Keeps existing climate history, Home values, overlay/environment use and alerts.
- Detects stale/missing UART packets and exposes warning/fault state instead of silently keeping old data forever.
- Sensor topology changes request a VIGILIS service restart; camera/capture code is untouched.

## Raspberry Pi UART note
For GPIO9 / RXD4 on Raspberry Pi 4, enable UART4 once in `/boot/firmware/config.txt`:

```
dtoverlay=uart4
```

Then reboot. The device should appear as `/dev/ttyAMA4`.

Gallery cleanup is intentionally deferred to the next UI-focused beta.
