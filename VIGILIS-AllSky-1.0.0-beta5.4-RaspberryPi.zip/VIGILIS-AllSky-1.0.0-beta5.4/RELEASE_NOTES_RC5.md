# VIGILIS 1.0.0 RC5

## Fixed

- Corrected Sun altitude calculations that could be shifted by one or two hours because a naive datetime was passed to Astral.
- Custom observation schedules now use the configured station timezone instead of the process-local implicit time.
- Version information now consistently reports RC5.

## Added

- Target FPS options: 20, 25 and 30 FPS in addition to every integer from 1 through 15 FPS.
- Astronomy diagnostics with local/UTC timestamps, timezone, coordinates, Sun altitude and Sun azimuth.
- Clear installer progress messages, especially while creating backups.

## Retained from RC4

- YUV420 capture for Raspberry CSI cameras in Astronomy Mono mode.
- Direct Y8 processing for Vision Engine, Detection Engine, preview and recorder.
- Full event archive pagination, Detection Engine diagnostics, heater modes, ZWO support and Liquid Glass UI.
