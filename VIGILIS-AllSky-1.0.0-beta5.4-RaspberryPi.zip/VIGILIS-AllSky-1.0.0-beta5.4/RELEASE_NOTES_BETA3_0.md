# VIGILIS AllSky 1.0.0 Beta 3.0

Beta 3.0 is a polish and architecture release built on Beta 2.9.

## Overlay WYSIWYG
- Overlay text size is now stored relative to image height instead of mixing browser pixels and OpenCV font scale.
- X/Y positions remain normalized to the image and render at the same relative location in preview and full-resolution archives.
- Left, center and right alignment use the same anchor semantics in preview and output.
- Text background padding scales with the image.
- Beta 2.9 overlay settings migrate automatically to the new relative-size model.
- Custom PNG, Compass and VIGILIS logo already use normalized position/size and remain compatible.

## Capture and scheduling retained from Beta 2.9
- Fresh-frame duplicate protection.
- Event-driven camera frame wait.
- Night start and night end are independent Sun-altitude thresholds.
- Transition interval offers 1/2/3/4/5 minutes plus Custom.

## Persistent settings
- User configuration remains in data/user_config.yaml and survives application updates.
- Overlay assets remain in data/overlay_assets.
