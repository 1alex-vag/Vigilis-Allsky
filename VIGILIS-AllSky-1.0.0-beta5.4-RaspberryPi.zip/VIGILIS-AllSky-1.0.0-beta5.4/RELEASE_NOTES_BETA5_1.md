# VIGILIS 1.0.0 Beta 5.1

## Fixed

- External recording locations are now validated before activation.
- VIGILIS creates the required storage folders automatically.
- Read/write verification is completed before the configuration is changed.
- Failed storage activation safely keeps the previous recording location.
- A disconnected or inaccessible drive no longer blanks System Health,
  Environment, Lens Cover, or other dashboard information.
- Storage information refreshes immediately after a successful switch.
- Changing the recording location no longer requires a service restart.

## Storage folders

The selected recording root is prepared with protected favorites, event stacks,
thumbnails, logs, and timelapse folders. Existing events remain at their original
location; only new recordings use the newly selected location.
