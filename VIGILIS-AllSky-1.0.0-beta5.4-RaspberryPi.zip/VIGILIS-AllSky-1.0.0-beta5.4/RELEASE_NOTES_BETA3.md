# VIGILIS 1.0 Beta 3

## Classification Engine 1.0

- Explainable meteor/aircraft candidate scoring based on duration, apparent speed, continuity, straightness and blinking gaps.
- New physical event folders: `date/meteor`, `date/aircraft`, and `date/unknown`.
- Automatic sorting can be enabled or disabled. Ambiguous events remain `unknown`.
- Aircraft and meteor score are stored in each event JSON file.
- Manual classification moves all associated event files to the selected folder.
- Day folders show meteor, aircraft and unknown counts.
- Quick archive views and per-day filters for meteors, aircraft and unknown events.
- Favorites remain protected and automatic cleanup behavior is unchanged.

The classifier is intentionally conservative. It never deletes events and may be corrected manually in the archive.
