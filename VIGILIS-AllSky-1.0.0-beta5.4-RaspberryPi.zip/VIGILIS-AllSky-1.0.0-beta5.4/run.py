from vigilis.app import main
main()
