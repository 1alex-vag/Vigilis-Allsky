# VIGILIS AllSky 1.0.0 Beta 1.2

- Restored the complete Lens Cover implementation from VIGILIS Meteor Beta 5.7 Climate Layout.
- Restored the original Lens Cover settings without additional AllSky-only cover options.
- Restored the proven A4988 STEP/DIR/ENABLE control and Hall sensor handling.
- Restored the original GPIO defaults: DHT22 GPIO4, Hall OPEN GPIO5, Hall CLOSED GPIO6, STEP GPIO17, ENABLE GPIO22, Heater GPIO24, DIR GPIO27.
- Preserved the AllSky capture, day/night scheduling and processing architecture.
