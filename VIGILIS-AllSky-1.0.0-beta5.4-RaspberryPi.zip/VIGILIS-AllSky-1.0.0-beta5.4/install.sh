#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${VIGILIS_DIR:-$HOME/vigilis}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE_NAME="vigilis.service"
OLD_CONFIG=""
CONFIG_BACKUP=""

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  echo "ERROR: Do not run this installer with sudo." >&2
  echo "Run it as your normal user instead: ./install.sh" >&2
  exit 1
fi

echo "VIGILIS AllSky 1.0.0 Beta 5.4 installer"
echo "Target: $APP_DIR"

# Stop an existing service before replacing code/hardware modules.
sudo systemctl stop "$SERVICE_NAME" 2>/dev/null || true

PERSISTENT_CONFIG="$APP_DIR/data/user_config.yaml"
LEGACY_CONFIG="$APP_DIR/config.yaml"
if [[ -f "$PERSISTENT_CONFIG" ]]; then
  CONFIG_BACKUP="$HOME/vigilis_config_backup_$(date +%Y%m%d_%H%M%S).yaml"
  echo "[1/6] Preserving persistent user configuration: $PERSISTENT_CONFIG"
  cp "$PERSISTENT_CONFIG" "$CONFIG_BACKUP"
  OLD_CONFIG="$(mktemp /tmp/vigilis-config.XXXXXX.yaml)"
  cp "$PERSISTENT_CONFIG" "$OLD_CONFIG"
elif [[ -f "$LEGACY_CONFIG" ]]; then
  CONFIG_BACKUP="$HOME/vigilis_config_backup_$(date +%Y%m%d_%H%M%S).yaml"
  echo "[1/6] Importing legacy configuration: $LEGACY_CONFIG"
  cp "$LEGACY_CONFIG" "$CONFIG_BACKUP"
  OLD_CONFIG="$(mktemp /tmp/vigilis-config.XXXXXX.yaml)"
  cp "$LEGACY_CONFIG" "$OLD_CONFIG"
else
  echo "[1/6] No previous configuration found. Clean installation."
fi

echo "[2/6] Installing application files..."
mkdir -p "$APP_DIR"
rsync -a --delete \
  --exclude '.venv/' \
  --exclude 'recordings/' \
  --exclude 'allsky/' \
  --exclude 'logs/' \
  --exclude 'data/' \
  --exclude 'backups/' \
  "$SRC_DIR/" "$APP_DIR/"
mkdir -p "$APP_DIR/recordings" "$APP_DIR/allsky" "$APP_DIR/logs" "$APP_DIR/data" "$APP_DIR/data/allsky" "$APP_DIR/backups" "$APP_DIR/vigilis/tuning"
find "$APP_DIR" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$APP_DIR" -type f -name '*.pyc' -delete 2>/dev/null || true

echo "[3/6] Checking system dependencies..."
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-numpy python3-opencv python3-picamera2 libusb-1.0-0 ffmpeg rsync curl util-linux parted e2fsprogs exfatprogs ntfs-3g

echo "[4/6] Updating Python environment and configuration..."
python3 -m venv --system-site-packages "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
if [[ -n "$OLD_CONFIG" && -f "$OLD_CONFIG" ]]; then
  # data/ survives rsync --delete, so all user settings are now physically
  # separate from replaceable application files.
  "$APP_DIR/.venv/bin/python" "$APP_DIR/tools/migrate_allsky_config.py" \
    --old "$OLD_CONFIG" \
    --defaults "$APP_DIR/config.example.yaml" \
    --output "$APP_DIR/data/user_config.yaml"
  rm -f "$OLD_CONFIG"
elif [[ ! -f "$APP_DIR/data/user_config.yaml" ]]; then
  cp "$APP_DIR/config.example.yaml" "$APP_DIR/data/user_config.yaml"
fi
"$APP_DIR/.venv/bin/python" "$APP_DIR/tools/generate_tuning_profiles.py"

sed -e "s|__USER__|$USER|g" -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis.service.in" | sudo tee "/etc/systemd/system/$SERVICE_NAME" >/dev/null

SUDOERS_FILE="/etc/sudoers.d/vigilis"
printf '%s\n' "$USER ALL=(root) NOPASSWD: /bin/systemctl restart vigilis.service, /bin/systemctl reboot, /bin/systemctl poweroff, /usr/bin/systemctl restart vigilis.service, /usr/bin/systemctl reboot, /usr/bin/systemctl poweroff" | sudo tee "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"

sudo install -d -m 0755 /etc/vigilis
sudo install -m 0644 "$APP_DIR/systemd/update_public.pem" /etc/vigilis/update_public.pem
sed -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis-update-helper.in" | sudo tee /usr/local/sbin/vigilis-update-helper >/dev/null
sudo chmod 0755 /usr/local/sbin/vigilis-update-helper
sed -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis-update-launcher.in" | sudo tee /usr/local/sbin/vigilis-update-launcher >/dev/null
sudo chmod 0755 /usr/local/sbin/vigilis-update-launcher
sudo install -m 0755 "$APP_DIR/systemd/vigilis-dev-update-mode" /usr/local/sbin/vigilis-dev-update-mode
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-dev-update-mode status, /usr/local/sbin/vigilis-dev-update-mode enable, /usr/local/sbin/vigilis-dev-update-mode disable" | sudo tee -a "$SUDOERS_FILE" >/dev/null
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-update-helper --verify-only *, /usr/local/sbin/vigilis-update-launcher *" | sudo tee -a "$SUDOERS_FILE" >/dev/null
sudo install -m 0755 "$APP_DIR/systemd/vigilis-storage-helper" /usr/local/sbin/vigilis-storage-helper
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-storage-helper *" | sudo tee -a "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"

sudo install -m 0755 "$APP_DIR/systemd/vigilis-zwo-permissions" /usr/local/sbin/vigilis-zwo-permissions
sudo /usr/local/sbin/vigilis-zwo-permissions || true

echo "[5/6] Installing and starting service..."
sudo systemctl daemon-reload
sudo systemctl enable --now "$SERVICE_NAME"

echo "[6/6] Running health checks..."
HEALTH_OK=0
for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:5000/api/status >/dev/null 2>&1; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done
if [[ "$HEALTH_OK" != "1" ]]; then
  echo "ERROR: VIGILIS health check failed." >&2
  sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
  sudo journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
  exit 1
fi

echo
echo "Installation complete."
echo "Open: http://$(hostname -I | awk '{print $1}'):5000"
echo "Lens Cover hardware reference: GPIO5 OPEN / GPIO6 CLOSED / GPIO17 STEP / GPIO22 ENABLE / GPIO27 DIR"
if [[ -n "$CONFIG_BACKUP" ]]; then
  echo "Previous configuration backup: $CONFIG_BACKUP"
fi
