# VIGILIS AllSky 1.0.0 Beta 4.0

## Day capture pipeline unification

- Normal scheduled Day Capture and Quick Capture now use the same post-sensor processing path.
- Day Capture no longer applies a separate extra-brightening path after exposure calibration.
- Day frames use the same white balance, color processing, overlay rendering, JPEG/PNG encoding and archive processing stages as Quick Capture.
- The selected Day exposure is taken from the calibrated sensor request metadata and preserved through the archive path.
- Day exposure overlays use human-readable units for short exposures: microseconds below 1 ms, milliseconds below 1 s, seconds otherwise.
- Existing night processing and the stable 30-second long-exposure capture path are unchanged.
