# VIGILIS AllSky 1.0.0 Beta 2.3

- Fixed mobile gallery viewer by serving archive media through a dedicated range-capable endpoint.
- Gallery now groups observing nights across midnight, e.g. 08.08.2026–09.08.2026.
- Night gallery sections: Pictures, Timelapse, Keogram, Startrail, Startrail video. Missing products offer Reprocess.
- Legacy Beta 2.1 midnight-split archives are merged virtually using capture timestamps.
- Product output names standardized to startrail.jpg and startrail.mp4 while legacy names remain readable.
- Lower CPU video encoding: one ffmpeg/x265 thread by default, nice priority, single filter thread.
- Product image loop is lightly throttled to keep the Pi responsive.
- Separate morning transition end Sun altitude setting; default 0°.
- Transition frames are stored with the observing-night archive.
- Automatic processing waits until the morning transition has ended.
