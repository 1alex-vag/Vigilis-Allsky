# VIGILIS AllSky 1.0.0 Beta 1.3

VIGILIS AllSky is a single-camera AllSky platform for Raspberry Pi 4, based on the reliable VIGILIS Meteor 1.0.0 Beta 5.7 Climate Layout hardware, Telegram, OTA, storage, heater, DHT22 and lens-cover foundation.

## Install
```bash
chmod +x install.sh
./install.sh
```
Open `http://<RASPBERRY-IP>:5000`.

## Beta 1 scope
- CSI camera discovery with IMX477 as the primary test camera
- ZWO ASI support
- maximum sensor resolution and 1x1 / 2x2 binning
- automatic exposure and gain limits
- day, sunset-transition and night capture modes
- automatic Hall-sensor lens-cover control
- manual lens-cover controls on Home
- focus mode with 0.5 s, 1 s, 2 s and 3 s exposures
- separate Day/Night archives
- Timelapse, Startrail, Startrail video and Keogram processing
- Telegram schedules and hardware alerts
- OTA update and SSD storage support

Hardware testing is required before release-candidate status.
