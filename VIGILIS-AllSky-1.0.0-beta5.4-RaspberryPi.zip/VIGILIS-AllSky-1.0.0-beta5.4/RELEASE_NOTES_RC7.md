# VIGILIS 1.0.0 RC7

## Event Archive 2.0
- Events are grouped into collapsible date folders in the Web UI.
- Each date folder shows its event count and loads its contents only when opened.
- Large days remain paginated in batches of 50 events.
- Existing flat/legacy event metadata remains readable.

## Overlay MP4 export
- Events with stored detector coordinates show a new **MP4 + Overlay** button.
- VIGILIS renders the green detector rectangle into a separate MP4 on demand.
- The original video is never modified.
- Rendered overlay videos are cached and reused until the source or metadata changes.
- Deleting an event also removes its generated overlay export.

## Compatibility
- All RC6 camera, detector, recorder, mask, deletion and YUV420/Y8 features remain unchanged.
