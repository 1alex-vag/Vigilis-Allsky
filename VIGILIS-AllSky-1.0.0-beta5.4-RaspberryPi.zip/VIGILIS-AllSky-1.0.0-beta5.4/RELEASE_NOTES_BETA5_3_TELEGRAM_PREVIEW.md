# VIGILIS 1.0.0 Beta 5.3 – Telegram 2.0 Preview

## Added
- Separate event, critical and daily-summary notification settings.
- Event filters for meteors, aircraft, unknown and all events.
- Immediate and hourly event delivery.
- Configurable observer, station and location names.
- Temperature and humidity warning thresholds.
- Personalized preview, event, warning, hourly and daily message templates.

## Preview limitations
- Temperature and humidity chart attachments are UI placeholders until Diagnostics 2.0 is implemented.
- Storage and generic system-warning triggers are exposed in settings but are not yet emitted by all subsystems.
- This build must be tested on Raspberry Pi hardware before release use.
