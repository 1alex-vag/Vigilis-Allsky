# VIGILIS AllSky 1.0.0 Beta 1

First independent AllSky release. Meteor detection, event recording, classification and event browsing were removed. The proven Meteor Beta 5.7 Climate Layout hardware services remain the foundation.
