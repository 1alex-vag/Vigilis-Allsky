# VIGILIS AllSky 1.0.0 Beta 1.7

- Fixed DHT22 humidity display on Home and Telegram environment checks (`sensor.humidity`).
- Added fast daylight auto-exposure calibration before a stored Day image.
- Day calibration frames are internal only and are never archived.
- Day and transition/night exposure states are separated so daylight calibration cannot reset night exposure.
- Day calibration starts at minimum gain and millisecond-range exposure and converges over multiple fresh frames.
- Camera-manager cadence now follows the active exposure, allowing rapid daylight calibration and efficient long night exposures.
- CSI sensor name is read from Picamera2 discovery and shown in camera status.
- Removed the hard-coded IMX462 tuning-file selection for non-IMX462 CSI sensors. IMX477 uses the libcamera system tuning unless a matching sensor-specific/custom profile exists.
- Home image endpoint falls back to the latest in-memory camera frame before the first archived AllSky image exists.
- Lens Cover hardware/controller logic is unchanged from Beta 1.6.
- Installer now preserves validated Lens Cover/GPIO user settings during upgrades (including inverted direction and offsets); Meteor defaults are used only for clean installations.
