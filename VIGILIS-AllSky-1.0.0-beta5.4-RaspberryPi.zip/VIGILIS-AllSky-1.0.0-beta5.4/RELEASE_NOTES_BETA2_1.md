# VIGILIS AllSky 1.0.0 Beta 2.1

## Night image noise reduction

- Adds Off / Low / Medium / High night noise reduction.
- Medium is the default and recommended setting.
- Processing targets chrominance noise first to reduce coloured speckle.
- Luminance processing is intentionally mild to preserve stars and Milky Way structure.
- Bright point detail is protected from luma smoothing.
- Day images are not denoised to avoid unnecessary Raspberry Pi CPU load.
- Exposure calibration continues to analyse untouched camera frames.
- Diagnostics expose the applied level and processing time.

Lens Cover, heater, Environment, camera capture and Telegram behaviour are unchanged from Beta 2.0.
