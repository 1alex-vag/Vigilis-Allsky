#!/usr/bin/env bash
set -euo pipefail
# Safely disables known old service names. It does not delete recordings.
for svc in meteorcam.service meteorcam vigilis-old.service; do
  sudo systemctl disable --now "$svc" 2>/dev/null || true
done
echo "Old known services disabled. Review old folders manually before deletion:"
find "$HOME" -maxdepth 2 -type d \( -iname '*meteorcam*' -o -iname '*vigilis*' \) -print
