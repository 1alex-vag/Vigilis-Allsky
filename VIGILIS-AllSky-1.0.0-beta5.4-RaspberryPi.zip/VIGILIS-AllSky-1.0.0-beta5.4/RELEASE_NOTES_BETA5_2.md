# VIGILIS 1.0.0 Beta 5.2

## Event archive performance

- Added a local SQLite event catalogue at `data/events.db` on the Raspberry Pi system storage.
- Existing events are indexed once in the background instead of recursively scanning the SSD on every page refresh.
- Thumbnail and video requests resolve directly through the event catalogue.
- New MP4 files are remuxed with `faststart` metadata for quicker browser playback.
- Added paginated event loading.
- Rebuilt the archive navigation as **Day → Meteors → Aircraft → Unknown → All Events**.
- Meteors are the default and first classification.
- Added a manual **Rebuild index** action for existing archives.

## Event naming

New recordings use the sortable daily sequence format:

`event_YYYYMMDD_HHMMSS_NNN`

The sequence is persistent in SQLite and continues across restarts and SD/SSD fallback. Existing recordings are not renamed.

## Optional lens cover

- Added a **Lens Cover installed** setting.
- When enabled, the cover opens by default 0.5° before the configured detection Sun altitude.
- Detection remains gated until the OPEN endstop is confirmed and the stabilization delay has elapsed.
- The detector ring buffer, tracking state and background model are reset before detection begins.
- When disabled, all cover movement and Hall-sensor logic is ignored; the detector is still reset before the observation starts.

## Home and responsive UI

- Sun altitude, date and time remain visible on phones in portrait and landscape orientation.
- Added a next-action message for cover opening and detection start.

## Storage safety

- If a configured external drive is absent during startup, VIGILIS uses the internal recordings directory without overwriting the preferred SSD path.
- Recursive archive indexing runs in a background thread and does not block the web interface.

## Testing note

This beta passed Python compilation, JavaScript syntax validation, event-index tests and ZIP integrity validation. Raspberry Pi camera, GPIO, Hall-sensor and real SSD behavior must still be verified on hardware. Keep Beta 5.1 available as a rollback.
