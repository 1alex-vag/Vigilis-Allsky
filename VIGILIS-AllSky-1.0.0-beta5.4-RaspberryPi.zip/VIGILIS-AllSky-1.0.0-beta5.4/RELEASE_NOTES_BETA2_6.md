# VIGILIS AllSky 1.0.0 Beta 2.6

- Gallery viewer now displays the already-loaded thumbnail immediately, then upgrades safely to a larger preview.
- Viewer date/exposure metadata is centered below the image.
- Timelapse and startrail video default to browser-compatible H.264 MP4 with fast-start metadata.
- Explicit MP4 MIME type and byte-range headers for inline playback.
- Download buttons for timelapse, keogram, startrail and startrail video.
- Keogram generation rebuilt around a configurable rotated fisheye diameter; default 90 degrees avoids the obstructed vertical slice on the current installation.
- Keogram rotation is configurable in Processing settings.
- Existing hardware, Lens Cover, heater and Telegram settings are preserved during upgrade.
