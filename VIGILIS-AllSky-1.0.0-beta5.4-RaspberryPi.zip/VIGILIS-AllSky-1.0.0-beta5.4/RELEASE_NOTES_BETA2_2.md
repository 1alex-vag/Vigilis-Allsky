# VIGILIS AllSky 1.0.0 Beta 2.2

## Stability / memory
- Fixed the Beta 2.1 OOM restart loop during keogram generation. The old code kept NumPy views into every full-resolution source frame, retaining the complete IMX477 frame allocations in RAM.
- Night product generation now processes source images one-by-one with bounded memory.
- Added a minimum available-RAM guard before product generation.
- Startrail-video intermediate frames are resized before being written.
- Timelapse and startrail-video encoding uses an ordered ffmpeg concat list and supports mixed JPEG/PNG archives.
- Manual processing refuses a second concurrent processing job.

## Night sessions and archive
- A night that crosses midnight is stored as one observing session, anchored to the date on which the evening began.
- New archive structure: `YYYY/MM/DD/Nacht/images/` and `YYYY/MM/DD/Nacht/products/` (same structure for day periods).
- Generated products are kept in `products/`: timelapse, startrail image, startrail video and keogram.
- Existing Beta 2.1 archive folders remain readable for compatibility.
- Telegram morning-product delivery supports the new `products/` folder.

## Gallery
- Newest nights and newest images are shown first.
- Date/night sections are collapsible.
- Image thumbnails show capture date/time underneath.
- Images open inside an integrated fullscreen viewer instead of a new browser tab.
- Viewer supports previous/next, keyboard arrows, Escape and mobile swipe.
- Products are grouped separately from individual images.

## Home / UI
- Added exposure progress indicator on Home while a frame is being captured.
- All System/Settings sections start collapsed.
- Brighter, more transparent Liquid Glass styling.
- Completed a German/English UI consistency pass. Incomplete FR/ES/ZH choices are temporarily hidden instead of presenting mixed-language pages.

## Overlay editor
- Added first functional overlay editor with live preview and drag/touch positioning.
- Optional fields: date, time, location, temperature, humidity, Sun altitude, exposure, gain and custom text.
- Adjustable font size and background opacity.
- Overlay is burned into stored/current AllSky images so generated products inherit it naturally.

## Processing controls
- Added separate 1080p/2K timelapse resolution setting.
- Startrail video retains its separate 1080p/2K setting.
