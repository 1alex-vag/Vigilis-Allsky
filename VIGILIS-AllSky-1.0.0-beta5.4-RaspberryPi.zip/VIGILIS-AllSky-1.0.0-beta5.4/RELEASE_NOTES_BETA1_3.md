# VIGILIS AllSky 1.0.0 Beta 1.3

## Lens Cover integration fix

- Keeps the proven VIGILIS Meteor Beta 5.7 `CoverController` unchanged.
- Fixes an AllSky-only integration bug that repeatedly issued CLOSE commands every second while Day Capture was disabled.
- Manual Open / Close / Stop on Home are no longer fought by the AllSky capture worker.
- Automatic cover moves now wait for the Hall-confirmed OPEN/CLOSED state before capture continues.
- Day mode parks the cover once when entering day mode instead of continuously commanding it closed.
- Sunset transition and night mode open the cover once on mode entry and keep it open.
- No new Lens Cover settings were added.
