# VIGILIS AllSky 1.0.0 Beta 2.8

## Fixed: duplicate night frames
- Archive capture now tracks the camera frame sequence and will never save the same camera sequence twice.
- Night cadence waits for a genuinely fresh frame and applies only the configured post-capture delay.
- Fixes the A,A,B,B frame pattern and the resulting stutter in timelapses.

## Fixed: settings survive updates
- User configuration is now stored persistently in `data/user_config.yaml`.
- `data/` is preserved by the installer and is not replaced by application updates.
- Existing pre-2.8 `config.yaml` is imported automatically on first update.
- Telegram credentials, camera setup, WB/gain/exposure, Lens Cover, heater/environment, location, processing/FPS/Keogram, overlay, storage and UI preferences are retained.
