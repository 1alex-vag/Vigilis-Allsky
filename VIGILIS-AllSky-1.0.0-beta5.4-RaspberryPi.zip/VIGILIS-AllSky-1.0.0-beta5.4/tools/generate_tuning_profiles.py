#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = APP_ROOT / "vigilis" / "tuning"
BASE_CANDIDATES = [
    Path("/usr/share/libcamera/ipa/rpi/vc4/imx290.json"),
    Path("/usr/share/libcamera/ipa/raspberrypi/imx290.json"),
    Path("/usr/share/libcamera/ipa/rpi/pisp/imx290.json"),
]

PROFILES = {
    "meteor": {
        "speed": 0.10,
        "shutter": [100, 5000, 20000, 50000, 100000, 150000, 195000],
        "gain": [1.0, 1.0, 1.5, 2.0, 4.0, 10.0, 31.62],
        "target": 0.20,
    },
    "dark_sky": {
        "speed": 0.08,
        "shutter": [100, 10000, 30000, 70000, 120000, 170000, 195000],
        "gain": [1.0, 1.0, 1.2, 1.8, 3.0, 8.0, 31.62],
        "target": 0.24,
    },
    "city": {
        "speed": 0.15,
        "shutter": [100, 3000, 10000, 30000, 60000, 90000, 100000],
        "gain": [1.0, 1.0, 1.5, 2.5, 5.0, 10.0, 16.0],
        "target": 0.18,
    },
    "moon": {
        "speed": 0.18,
        "shutter": [100, 1000, 3000, 8000, 16000, 25000, 33000],
        "gain": [1.0, 1.0, 1.5, 2.0, 3.0, 5.0, 8.0],
        "target": 0.16,
    },
}


def find_agc(data: dict) -> dict:
    for algorithm in data.get("algorithms", []):
        if "rpi.agc" in algorithm:
            return algorithm["rpi.agc"]
    raise RuntimeError("rpi.agc section not found in base tuning file")


def patch_profile(base: dict, spec: dict) -> dict:
    data = copy.deepcopy(base)
    agc = find_agc(data)
    agc["speed"] = spec["speed"]
    modes = agc.setdefault("exposure_modes", {})
    # Replace the default mode because Picamera2/libcamera selects it without
    # requiring a custom AeExposureMode enum.
    modes["normal"] = {
        "shutter": spec["shutter"],
        "gain": spec["gain"],
    }
    # Keep long mode in sync for applications that select it explicitly.
    modes["long"] = {
        "shutter": spec["shutter"],
        "gain": spec["gain"],
    }
    agc["y_target"] = [0, spec["target"], 1000, spec["target"], 10000, spec["target"]]
    return data


def main() -> int:
    base_path = next((p for p in BASE_CANDIDATES if p.exists()), None)
    if base_path is None:
        print("WARNING: no system imx290 tuning file found; custom profiles were not generated")
        return 0
    base = json.loads(base_path.read_text(encoding="utf-8"))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for name, spec in PROFILES.items():
        target = OUT_DIR / f"imx462_{name}.json"
        target.write_text(json.dumps(patch_profile(base, spec), indent=4), encoding="utf-8")
        print(f"Generated {target} from {base_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
