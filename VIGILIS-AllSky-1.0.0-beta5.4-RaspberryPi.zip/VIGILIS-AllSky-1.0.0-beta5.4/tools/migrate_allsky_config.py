#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import yaml

parser = argparse.ArgumentParser()
parser.add_argument('--old', default='')
parser.add_argument('--defaults', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()

def load(path):
    p = Path(path)
    if not path or not p.exists():
        return {}
    return yaml.safe_load(p.read_text()) or {}

def deep_merge(dst, src):
    for key, value in (src or {}).items():
        if isinstance(value, dict) and isinstance(dst.get(key), dict):
            deep_merge(dst[key], value)
        else:
            dst[key] = value

base = load(args.defaults)
old = load(args.old)
# Beta 1.7 preserves every existing user setting, including the now-validated
# Lens Cover direction/offsets and GPIO mapping. Clean installs still use the
# known-good Meteor defaults from config.example.yaml. Missing new keys are
# supplied by the defaults through the deep merge.
deep_merge(base, old)
# Beta 2.6 deliberately migrates generated videos to H.264. Previous Betas
# defaulted to HEVC/H.265, which is not reliably playable in embedded browser
# players across Safari/Chrome/Firefox. Existing files are left untouched; new
# or reprocessed products use browser-compatible H.264.
base.setdefault('processing', {})['video_codec'] = 'libx264'
Path(args.output).write_text(yaml.safe_dump(base, sort_keys=False, allow_unicode=True))
print('Configuration migrated; existing Lens Cover/GPIO settings preserved.')
