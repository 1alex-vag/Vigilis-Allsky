#!/usr/bin/env python3
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[1]
config_path=ROOT/'config.yaml'
default_path=ROOT/'config.example.yaml'
if not config_path.exists() or not default_path.exists():
    raise SystemExit(0)
cfg=yaml.safe_load(config_path.read_text()) or {}
defaults=yaml.safe_load(default_path.read_text()) or {}
# These sections are intentionally normalized to the known-good Meteor Beta 5.7 hardware stack.
# They contain the exact GPIO mapping and Hall/A4988 semantics validated on the user's hardware.
for section in ('gpio','cover'):
    cfg[section]=dict(defaults.get(section,{}) or {})
# Preserve sensor/heater user behavior where possible, but fill all known-good defaults.
for section in ('sensor','heater'):
    merged=dict(defaults.get(section,{}) or {})
    merged.update(cfg.get(section,{}) or {})
    cfg[section]=merged
config_path.write_text(yaml.safe_dump(cfg,sort_keys=False,allow_unicode=True))
print('Meteor Beta 5.7 hardware GPIO/Cover configuration synchronized.')
