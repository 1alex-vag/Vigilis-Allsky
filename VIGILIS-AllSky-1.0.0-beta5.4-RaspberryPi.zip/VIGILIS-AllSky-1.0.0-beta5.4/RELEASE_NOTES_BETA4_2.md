# VIGILIS AllSky 1.0.0 Beta 4.2

## Transition capture
- Morning/evening transition now performs a short two-frame AE preflight immediately before every archived transition frame.
- Preflight frames are discarded and never enter Gallery, Timelapse, Startrail or Keogram.
- Mode-entry calibration still flushes queued requests, preventing black transition-boundary frames.
- The configured transition interval remains unchanged; the preflight only prepares the next scheduled archive frame.

## Overlay editor
- Compass preset size range increased up to 95% of image width.
- Dragging uses requestAnimationFrame and no longer requests a server-rendered full preview for every pointer movement.
- Sliders update locally first and refresh the exact server preview after a short debounce.
- Exposure unit is selectable: seconds, milliseconds, microseconds or automatic.
- Default exposure unit is seconds for consistent Day/Transition/Night overlays.
