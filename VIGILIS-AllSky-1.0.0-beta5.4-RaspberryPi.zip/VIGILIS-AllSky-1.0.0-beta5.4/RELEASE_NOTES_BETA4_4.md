# VIGILIS AllSky 1.0.0 Beta 4.4

## Environment sensor correction
- Indoor / Dome sensor is now configurable as either DHT22 or SHT31 via RP2040 (UART).
- SHT31/RP2040 defaults to `/dev/ttyAMA4` at 9600 baud.
- Outdoor sensor remains a separate optional channel and can independently use DHT22 or SHT31 via RP2040.
- Existing DHT22 configuration remains backward compatible.
- No camera, capture, transition, gallery, cover, or processing logic was changed in this build.
