# VIGILIS AllSky 1.0.0 Beta 3.1

- Added Home **Quick Capture** one-shot workflow.
  - Opens the Lens Cover only when required.
  - Auto mode performs a short 4-frame exposure calibration.
  - Saves exactly one image, then restores the previous exposure state and Lens Cover position.
  - Fixed exposure presets and a custom exposure are also available.
- Reworked Overlay Editor preview to be true WYSIWYG.
  - Preview is now rendered server-side by the exact same OpenCV renderer used for archived images.
  - Browser overlay layer is used only for draggable position handles.
  - Text, image, compass and VIGILIS-logo scale/position therefore share one renderer and one geometry model.
- Beta 2.9/3.0 scheduling, duplicate-frame protection, persistent settings and product processing remain intact.
