# VIGILIS 1.0 RC6

## Event review
- Events store normalized detector boxes and timing in their JSON metadata.
- The event player can display a lightweight green rectangle over the detected target.
- The overlay can be disabled without modifying the original MP4.
- New thumbnails are generated from the trigger frame and marked with the first detector box.
- Existing RC5 and older events remain playable, but do not have overlay metadata.

## Event archive
- Events remain organized under `recordings/YYYY-MM-DD/unknown/`.
- The complete archive is loaded in pages instead of being limited to the latest items.
- Events can be deleted in the web UI after confirmation; video, thumbnail and metadata are removed together.

## Detection masks
- A new `Ignore bottom of image` control can exclude 0-80% of the lower frame, useful for roads and buildings.
- Advanced users can upload a binary mask. White areas are ignored by the detector.

## Preserved RC5 features
- timezone-aware astronomy calculations
- YUV420/Y8 mono processing
- target frame rates 1-15, 20, 25 and 30 FPS
