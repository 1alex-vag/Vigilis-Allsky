# VIGILIS AllSky 1.0.0 Beta 2.5

- Gallery picture lists are paginated: 50 images initially, Load 50 more on demand.
- Multi-select image deletion added.
- Mobile image viewer now uses the original media route directly, avoiding the failed large-preview path on Safari.
- Reprocess can target only Timelapse, Keogram, Startrail, or Startrail Video; Reprocess All remains available.
- Processing performance rebalanced for Raspberry Pi 4: two threads/two CPU cores by default, lower nice value, faster x265 preset, shorter frame-yield pause.
- Keogram samples and averages a narrow centre band into one column per frame to reduce single-column artefacts and downscale aliasing; time axis retained.
- Stronger Liquid Glass styling across panels, buttons, gallery, viewer and progress bars.
- Existing configuration, archive data, lens-cover direction, Telegram and hardware settings remain migrated/preserved by the installer.
