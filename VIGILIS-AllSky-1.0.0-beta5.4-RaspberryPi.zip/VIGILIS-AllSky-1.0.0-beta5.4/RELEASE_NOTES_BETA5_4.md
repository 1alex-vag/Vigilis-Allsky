# VIGILIS 1.0.0 Beta 5.4

## Telegram 2.0

- Reorganized Telegram settings into Event Notifications, Critical Notifications and Daily Summary.
- Added selectable event classes: meteors, aircraft, unknown and all events.
- Added immediate, hourly-summary and disabled event delivery modes.
- Added critical alerts for camera offline, lens-cover fault, high temperature, high humidity, storage warning, system warning and VIGILIS restart.
- Added configurable temperature, humidity and storage warning thresholds.
- Added observer name, station name and station location fields.
- Added personalized preview, restart, event, warning, hourly-summary and daily-summary messages.
- Added scheduled daily summaries with event counts and current environment/storage information.

## Fixed

- Fixed the Telegram preview HTTP 500 error caused by reading the non-existent `sensor.status` attribute.
- Updated Telegram environment access to use `SensorReader.latest` and the correct `humidity` field.
- Added error logging and meaningful API responses for failed preview messages.
- Improved browser-side error display for Telegram preview failures.

## Scope

This is a complete installer based on Beta 5.2 plus Telegram 2.0. It is not a patch and does not depend on an earlier preview build.

Temperature and humidity chart attachments are still reserved for the later Diagnostics update; the options remain visible but do not send chart images yet.
