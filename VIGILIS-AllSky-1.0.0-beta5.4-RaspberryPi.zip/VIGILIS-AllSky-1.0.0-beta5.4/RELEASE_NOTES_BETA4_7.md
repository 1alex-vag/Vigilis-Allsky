# VIGILIS AllSky 1.0.0 Beta 4.7

UI refinement release. Stable camera, capture, transition, gallery, startrail,
SHT31/RP2040, lens-cover and processing logic are intentionally unchanged.

## Home
- AllSky preview expands to the full width of its glass card.
- Camera Online/Offline, Day/Night/Transition and Sun altitude use compact status pills.
- Camera Online is highlighted green.
- Environment and System are combined into one glass card.
- Lens Cover and Quick Capture are combined into one glass card.
- Main glass surfaces are substantially more transparent so more of the background is visible.
- Home/Gallery/System/Diagnostics navigation is an equal-width centered four-column grid.

## Diagnostics climate chart
- 24 hours is now the default view.
- Indoor temperature is green.
- Indoor humidity is blue.
- Optional Show Outdoor checkbox appears; it is disabled when no Outdoor sensor is configured.
- Outdoor temperature uses a yellow/orange-green line.
- Outdoor humidity uses light blue.
- Outdoor series are dashed to make IN/OUT easier to distinguish.
