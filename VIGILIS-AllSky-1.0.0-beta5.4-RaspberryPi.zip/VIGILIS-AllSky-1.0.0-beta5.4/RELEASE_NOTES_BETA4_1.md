# VIGILIS AllSky 1.0.0 Beta 4.1

## Day / Quick Capture parity

- Quick Capture Auto now calls the exact same `_calibrate_day()` function as scheduled Day Capture.
- Fixed the daylight stable-control gate: the former 2 ms absolute tolerance could accept a queued 0.6–2 ms libcamera request for a requested 110 µs frame.
- Daylight requests now require tight ExposureTime and AnalogueGain agreement before they may be archived.
- If daylight controls never settle, VIGILIS rejects the frame and retries later instead of saving an incorrectly exposed image.
- Sidecar JSON records the exact completed libcamera request metadata (ExposureTime, AnalogueGain, DigitalGain, ColourGains, FrameDuration, Lux, ColourTemperature) plus processing diagnostics.
- Overlay Exposure/Gain are taken from the exact saved request. Short exposures are displayed as µs/ms instead of `0.000 s`.
- Night capture cadence and night processing are unchanged.
