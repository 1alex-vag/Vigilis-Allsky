# VIGILIS AllSky 1.0.0 Beta 4.9

Final transparency refinement.

- Glass fill reduced to near-zero opacity.
- Backdrop blur reduced again so the background remains more visible.
- Shadows and borders made lighter and more subtle.
- Buttons and status pills made more transparent.
- Internal separators softened.

No camera, capture, transition, processing, gallery, Telegram, sensor or hardware logic was changed.
