# VIGILIS 1.0 Beta 2

## Changes

- Lens cover mode: Automatic (sunset/sunrise observation state) or Manual.
- Event Stack 2.0: clean stack, green-overlay stack, or both downloads.
- Event stacks now extract representative frames from the original videos, so the clean stack does not inherit thumbnail boxes.
- Overlay margin options expanded through 500%.
- Existing Beta 1 storage, favorites, cleanup, multi-delete and Event Stack features remain available.
