# VIGILIS AllSky 1.0.0 Beta 4.5

## Diagnostics
- Renamed Processing / Diagnostics to Diagnostics.
- Added an always-visible temperature + humidity history chart.
- Range selectors: 24h, 7d, 30d, 6 months, 1 year.
- Camera, Capture Cycle and Developer Log are collapsed sections.

## Gallery
- Added Day / Night filter tabs.
- Mobile gallery now shows four thumbnails per row.
- Pagination reduced to 20 images per load.
- Image ordering uses captured_at metadata instead of filename order.

## Startrails
- Added Clean Startrail (`startrail_clean.jpg`) with conservative global overexposure rejection.
- Added Full Startrail (`startrail_full.jpg`) using every valid frame.
- Legacy `startrail.jpg` now mirrors the clean result.
- Startrail video is generated from accepted clean frames.
- Bright narrow events such as meteors are intentionally not rejected by the global exposure gate.

## Telegram
- Morning delivery no longer attempts to send large timelapse/startrail videos.
- Morning summary sends the Clean Startrail image with:
  - frame count
  - start/end time
  - min/max dome temperature
  - maximum dome humidity
- Message starts with: `Good morning, observer. VIGILIS has prepared a summary of last night.`

## Stability
- Camera capture, Day/Night timing, lens cover and SHT31/RP2040 UART paths were left unchanged.
