# VIGILIS AllSky 1.0.0 Beta 5.2

- Home status row fixed: Camera / Status / Sun altitude are three equal columns on one line.
- Gallery product rows aligned: title left, image count / Available status right.
- Session date and total image count remain unchanged.
- No capture, sensor, heater, lightning or hardware logic changes.
