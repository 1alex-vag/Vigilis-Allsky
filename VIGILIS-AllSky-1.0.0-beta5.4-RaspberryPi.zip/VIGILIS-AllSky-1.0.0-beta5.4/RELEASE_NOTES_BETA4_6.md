# VIGILIS AllSky 1.0.0 Beta 4.6

Home/frontpage refinement only. Stable capture, transition, gallery, processing,
sensor and hardware paths are intentionally left unchanged.

## Home
- Uses the supplied transparent SVG VIGILIS AllSky logo, centered in the header.
- Removes the global AllSky status bar.
- Moves Camera status, Day/Night status and Sun altitude into the live-image card.
- Combines Pictures today and Next capture into one compact card with the exposure progress bar below.
- Environment now shows Indoor and Outdoor temperature/humidity side by side plus heater state.
- System card keeps CPU load, CPU temperature, RAM and storage.
- Lens cover and Quick Capture cards are vertically condensed.
- Quick Capture helper text removed.
- Last capture is collapsed by default.
- Footer reduced to one line with a clickable @ag_astrophotography link.

No AS3935/lightning or additional diagnostics changes are included in this beta.
