# VIGILIS AllSky 1.0.0 Beta 3.8

- Daylight auto exposure is now highlight-aware (98th percentile + clipping guard) and keeps daylight gain at minimum.
- Daylight minimum exposure was extended down to 20 µs for bright sun.
- Quick Capture and scheduled Day Capture now use the same daylight calibration behaviour and wait for a stable sensor request before saving.
- Settings are reorganized into Camera / Hardware & User / System flow. Focus mode is integrated into Camera Manager.
- Overlay Editor now uses the exact last captured AllSky image (same source as Home) and no longer reads a new live camera frame just for editing.
- Beta 3.7 live GPIO/restart logic and all existing user settings remain preserved.
