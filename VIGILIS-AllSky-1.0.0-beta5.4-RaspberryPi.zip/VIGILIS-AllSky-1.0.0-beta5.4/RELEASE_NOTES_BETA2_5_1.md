# VIGILIS AllSky 1.0.0 Beta 2.5.1

## Gallery viewer hotfix
- The in-app gallery viewer now loads the same bounded/cached JPEG preview pipeline that already powers the working gallery thumbnails.
- Viewer preview is limited to 2200 px on the long edge to avoid iOS/Safari full-resolution decode stalls.
- The Original button continues to open the untouched full-resolution archive image.
- No hardware, capture, lens-cover, heater, Telegram, processing, or configuration behavior changed.
