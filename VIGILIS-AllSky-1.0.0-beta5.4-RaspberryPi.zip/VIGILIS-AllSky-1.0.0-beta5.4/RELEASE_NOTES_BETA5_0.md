# VIGILIS AllSky 1.0.0 Beta 5.0

Ultra-transparent final Liquid Glass pass.

- Panel fill reduced to essentially transparent.
- Backdrop blur reduced to a very light glass effect.
- Shadows, borders and internal separators softened again.
- Buttons remain slightly stronger than panels for usability.
- Status pills retain color coding but with minimal fill opacity.

No camera, capture, transition, processing, gallery, sensor, Telegram or hardware logic was changed.
