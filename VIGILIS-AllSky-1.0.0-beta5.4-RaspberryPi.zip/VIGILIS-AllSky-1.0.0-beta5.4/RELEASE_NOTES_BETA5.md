# VIGILIS 1.0.0 Beta 5

- Responsive Event Archive header and mobile 2x2 archive navigation.
- Storage Manager 2.0 based on lsblk instead of mount-folder scanning.
- Detects USB disks without partitions and offers safe GPT + EXT4 initialization.
- Detects unmounted partitions and can mount them as VIGILIS recording storage.
- Meteor Event Stack now uses only events classified as meteor.
- Meteor trails are extracted only around stored detector tracks; aircraft and unknown events are excluded.
- Improved stack progress text and meteor counts.
