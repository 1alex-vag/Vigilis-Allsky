# VIGILIS AllSky 1.0.0 Beta 2.7

- Centered gallery viewer on mobile and desktop; centered close/navigation controls and metadata.
- Responsive product controls: Open / Download / Reprocess / Delete align as 4 columns on wide screens and 2x2 on phones.
- Separate selectable FPS for Timelapse and Startrail Video (10/15/20/25/30/50/60).
- Keogram Line Editor with live AllSky preview, draggable line center and configurable rotation.
- Keogram generation now honours configurable center X/Y and samples the full in-frame line segment.
- Existing Beta 2.6 H.264 browser-compatible video pipeline, gallery paging, hardware, Telegram, heater and lens-cover settings retained.
